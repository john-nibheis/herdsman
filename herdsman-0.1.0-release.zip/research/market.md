# BUACHAILLE: market and regulatory research brief

Prepared 7 November 2026 for the launch of BUACHAILLE (working name), an independent statistical referee for AI data-analyst and AI-scientist agents, sold under the Nibheis brand.

**How to read this.** Every factual statement carries a link and the source's date. Where a page is undated, the access date (7 Nov 2026) is given. **UNVERIFIED** marks anything I could not confirm from a source I actually read in this session, including items seen only in search-result titles and secondary summaries whose primary source I could not open. Paragraphs headed *Assessment* are my analysis, not sourced fact. Derived numbers (annualisations, sums, false-positive-risk checks) were computed in Python and are listed in the appendix.

**Limitations.** The session's web-search budget (200 queries) ran out before the end of the work. Several primary sites could not be fetched from this environment: gartner.com (June 2025 release only), science.org, nature.com's main policy page, the UK IPO, EUIPO TMview, the WIPO Brand Database, the Companies House search page, and domain RDAP/DNS. The affected items rest on reputable secondary reports and are flagged.

**Headline findings.**
1. Demand is visible but trust is low. Analytics agents are now mainstream platform features: Databricks reported 4,000+ Genie preview customers, and Snowflake had almost 2,500 accounts using Intelligence weekly. Yet only 19% of senior data leaders are "very confident" in AI-generated analysis, and only 19% of IT application leaders trust their vendor's hallucination protection.
2. The failure mode BUACHAILLE targets is documented, including by the AI-scientist vendors themselves. Recent research locates the risk in selective exploration and inference rather than coding errors.
3. Across this session's searches (the shared 200-query budget ran out) I found no funded company selling sealed-holdout, online-FDR control for agents. The funded "verification" start-ups check SQL, lineage or formal logic. The nearest overlap is open-source (MethodSeal, MIT licence, July 2026) or academic. The main substitute threat is experimentation platforms that already expose experiments to agents through MCP: Statsig (now owned by OpenAI) and GrowthBook.
4. The regulatory hooks are weaker than the brief assumed:
   - SR 26-2 (17 Apr 2026) replaced SR 11-7 and puts generative and agentic AI out of scope.
   - The FDA's AI credibility guidance is still a draft and excludes drug discovery.
   - EU high-risk obligations now start on 2 Dec 2027 and do not normally reach internal analytics agents.
   - PRA SS1/23's independent-validation principle is the strongest hook, but it binds only banks with internal-model approval.
5. The name is clear in software registries (PyPI, npm), but there are three conflicts to resolve: the GitHub handle `buachaille` is held by an individual, a US class 9 registration exists for the near-identical "BUACHAILL", and a UK company called BUACHAILLE HOLDINGS LIMITED exists. UK and EU trade mark registers were not searchable here.

---

## 1. Adoption

### 1.1 AI data-analyst agents in the enterprise

- **Databricks Genie.** Databricks made AI/BI Genie generally available and said "over 4000 customers adopted AI/BI Genie during its preview". It named HP, 7-Eleven, SEGA Europe, Premier, Magic Orange, The AA and Casas Bahia as customers ([Databricks blog, 12 Jun 2025](https://www.databricks.com/blog/aibi-genie-now-generally-available)).
  - In February 2026 it reported a US$5.4bn revenue run-rate growing over 65% a year, an AI-products run-rate above US$1.4bn, and about US$5bn of equity raised at a US$134bn valuation. It gave no Genie user counts ([Databricks, 9 Feb 2026](https://databricks.com/company/newsroom/press-releases/databricks-grows-65-yoy-surpasses-5-4-billion-revenue-run-rate)).
  - In June 2026 it launched Genie One, an agentic "coworker", and said Genie One would move from SaaS licensing to pay-as-you-go pricing on tokens consumed ([SiliconANGLE, 16 Jun 2026](https://siliconangle.com/2026/06/16/databricks-new-agentic-coworker-genie-one-brings-ai-automation-every-part-business/)).
- **Snowflake Intelligence.** It became generally available to more than 12,000 customers, and Snowflake said more than 1,000 customers had deployed over 15,000 AI agents ([Investing.com, 4 Nov 2025](https://ng.investing.com/news/company-news/snowflake-intelligence-now-available-to-over-12000-customers-93CH-2184284)).
  - In its FY2026 results, Snowflake said Intelligence became "an essential capability for almost 2,500" accounts in three months. That figure counts weekly users, averaged over the last four weeks of the quarter. Over 9,100 accounts use Snowflake AI features, and Snowflake has more than 13,300 customers ([Snowflake 8-K, 25 Feb 2026](https://www.sec.gov/Archives/edgar/data/1640147/000162828026011631/fy2026q4earnings.htm)). The weekly users are therefore at most about 18.8% of customers (computed).
  - The GA release-note page is now titled "Snowflake CoWork (General availability)", which suggests a rename. **UNVERIFIED** ([Snowflake docs, 4 Nov 2025](https://docs.snowflake.com/release-notes/2025/other/2025-11-04-snowflake-intelligence)).
- **Hex.** Hex raised a US$70m Series C led by Avra, with a16z, Amplify, Box Group, Redpoint, Sequoia and Snowflake Ventures ([Business Wire, 28 May 2025](https://www.businesswire.com/news/home/20250528505112/en/Hex-Lands-%2470M-to-Transform-Data-Science-and-Analytics-With-AI)). It then raised a US$100m Series D at a US$1.2bn valuation, co-led by PeakXV and 137 Ventures, and now calls itself "an AI analytics platform for humans and agents" ([Cooley, 27 Oct 2026](https://www.cooley.com/news/coverage/2026/2026-10-30-hex-raises-100-million-series-d-at-1-2b-valuation)).
- **Julius AI.** It raised a US$10m seed led by Bessemer and reported more than 2 million users and more than 10 million visualisations generated ([TechCrunch, 28 Jul 2025](https://www.techcrunch.com/2025/07/28/ai-data-analyst-startup-julius-nabs-10m-seed-round/)).
- **ThoughtSpot Spotter.** Spotter launched in November 2024 ([ThoughtSpot, 13 Nov 2024](https://www.thoughtspot.com/press-releases/thoughtspot-launches-spotter-the-autonomous-agent-for-analytics)). By fiscal year-end ThoughtSpot reported 133% year-on-year usage growth, with 52% of customers actively using Spotter ([IT Brief UK, 30 Oct 2025](https://itbrief.co.uk/story/thoughtspot-sees-133-usage-surge-as-enterprises-embrace-ai-analytics)).
- **Amplitude.** Its AI Agents monitor data, form hypotheses, run experiments and ship changes, at an autonomy level the customer sets. No agent adoption figures were given; Amplitude has over 4,900 customers overall ([Amplitude, 10 Jun 2025](https://amplitude.com/press/ai-agents)).
- **Tableau.** Salesforce announced Tableau Next with agent skills (Data Pro, Concierge, Inspector). Concierge and Data Pro were due in June 2025 ([Salesforce, 15 Apr 2025](https://www.salesforce.com/news/press-releases/2025/04/15/tableau-next-announcement/)).
- **Power BI.** Microsoft's cross-item "standalone" Copilot in Power BI is still marked "This feature is in preview". The documentation warns that answers "might be limited or inaccurate" when data are not prepared for AI ([Microsoft Learn, updated 27 Aug 2026](https://learn.microsoft.com/en-ie/power-bi/create-reports/copilot-chat-with-data-standalone)).
- **Agents now run A/B tests themselves.**
  - Optimizely says users of its Opal agents run 78.7% more experiments and see 9.3% higher win rates. This is a vendor benchmark of 47,000 interactions across nearly 900 adopters ([Optimizely, 30 Sep 2025](https://www.optimizely.com/company/press/opal-turns-2)).
  - Statsig's MCP server gives agents such as Claude Code and Cursor an `experiment_create` tool ([Statsig docs, undated, accessed 7 Nov 2026](https://docs.statsig.com/integrations/mcp)).
  - GrowthBook's MCP server documentation shows agents reading experiment results and recommending whether to ship a winner ([GrowthBook docs, undated, accessed 7 Nov 2026](https://docs.growthbook.io/integrations/mcp)).

### 1.2 AI-scientist agents

- **FutureHouse / Edison Scientific.** FutureHouse spun out Edison Scientific to commercialise its AI Scientist. It said VP- or C-level executives from 6 of the top 10 pharma companies had made inbound enquiries ([FutureHouse, 5 Nov 2025](https://www.futurehouse.org/news/announcing-edison-scientific)).
  - Edison launched Kosmos at US$200 per run and says "79.4% of its conclusions are accurate". The page does not explain how that figure was measured.
  - Edison also warns that Kosmos "often goes down rabbit holes or chases statistically significant yet scientifically irrelevant findings", and that "the longer the Kosmos run, the more likely it is that Kosmos descends down a rabbit hole, chasing spurious statistical correlations" ([Edison, 5 Nov 2025](https://edisonscientific.com/news/announcing-kosmos)).
  - Edison then raised a US$70m seed from Triatomic Capital, Spark Capital and an unnamed US institutional biotech investor ([Edison, 18 Dec 2025](https://edisonscientific.com/news/we-raised-70m-to-accelerate-science)).
- **Periodic Labs.** It raised a US$300m seed. TechCrunch reports that a16z led and Felicis wrote the first check; an aggregator headline seen only in search results names Felicis as lead, so lead attribution varies. Other investors include DST, NVentures and Accel, with angels including Jeff Bezos, Eric Schmidt and Jeff Dean. No valuation was disclosed ([TechCrunch, 20 Oct 2025](https://techcrunch.com/2025/10/20/top-openai-google-brain-researchers-set-off-a-300m-vc-frenzy-for-their-startup-periodic-labs)).
- **Lila Sciences.** It raised a US$115m extension at a valuation above US$1.3bn, taking total funding to about US$550m ([Reuters via Yahoo Finance, 14 Oct 2025](https://finance.yahoo.com/news/exclusive-ai-lab-lila-sciences-101645837.html)). Bloomberg reported talks to raise about US$2bn at about US$8.5bn pre-money ([Bloomberg Government, 3 Jun 2026](https://news.bgov.com/private-equity/lila-sciences-said-in-talks-for-funds-at-8-5-billion-valuation)). Whether that round closed is **UNVERIFIED**.
- **Sakana AI.** Its AI Scientist paper appeared in *Nature* on 25 March 2026. One of three fully AI-generated submissions was accepted at an ICLR 2025 workshop. I read the paper through a reader mirror ([Nature 651, 914–919, 25 Mar 2026](https://www.nature.com/articles/s41586-026-10265-5)).
  - The authors write that "The AI Scientist cannot yet meet the standards of top-tier publications".
  - They list failure modes including incorrect implementations, weak methodological rigour, experimental errors and hallucinated citations.
  - They warn that "Such challenges could persist and would prevent us from reliably trusting the outputs of systems like The AI Scientist".
  - Sakana raised ¥20bn (about US$135m) at a valuation of about US$2.6bn ([AI Business, 18 Nov 2025](https://aibusiness.com/foundation-models/japan-ai-model-maker-ups-valuation-latest-funding-round)).
- **Google AI co-scientist.** This Gemini 2.0 multi-agent system was announced with three validations: AML drug-repurposing candidates tested in vitro, liver-fibrosis targets tested in organoids (p < 0.01), and an independent rediscovery of a cf-PICI mechanism. Access is through a Trusted Tester Programme ([Google Research, 19 Feb 2025](https://research.google/blog/accelerating-scientific-breakthroughs-with-an-ai-co-scientist/)).
- **Recursion.** It halted two mid-stage programmes (CCM and NF2), paused a third, and extended its cash runway to mid-2027. It reported a 2024 net loss of about US$464m ([BioPharma Dive, 5 May 2025](https://www.biopharmadive.com/news/recursion-pipeline-cuts-first-quarter-earnings/747119/)).
- **Isomorphic Labs.** It raised US$600m in its first external round, led by Thrive ([Isomorphic Labs, 31 Mar 2025](https://isomorphiclabs.com/articles/isomorphic-labs-announces-600m-external-investment-round)). It then raised a US$2.1bn Series B led by Thrive, with Alphabet, GV, CapitalG, Temasek, MGX and the UK Sovereign AI Fund. No valuation was stated ([YourStory, 12 May 2026](https://yourstory.com/ai-story/isomorphic-labs-ai-drug-discovery-series-b-2026)).
- **Agents4Science.** This was a conference where AI agents were lead authors and first-round reviewers. Of 314 papers, 48 were accepted, and Science News reports that agents "struggled with accuracy and judgment" ([Science News, 24 Oct 2025](https://www.sciencenews.org/article/science-conference-test-ai-agents)).

### 1.3 Surveys on adoption, trust and accuracy

- **Gartner survey of IT application leaders.** The survey covered 360 leaders in May–June 2025 ([Gartner, 30 Sep 2025](https://www.gartner.com/en/newsroom/press-releases/2025-09-30-gartner-survey-finds-just-15-percent-of-it-application-leaders-are-considering-piloting-or-deploying-fully-autonomous-ai-agents)).
  - 75% are piloting or deploying some form of AI agent, and 15% are considering, piloting or deploying fully autonomous agents.
  - 19% have high or complete trust in their vendor's hallucination protection.
  - 13% strongly agree they have the right governance structures in place.
  - 64% rank analytics and BI among the top three domains for agent impact.
- **Gartner predictions.** More than 40% of agentic AI projects will be cancelled by the end of 2027, and only about 130 of the thousands of "agentic" vendors are genuine. I read this in Reuters' report; the primary Gartner page could not be fetched ([Reuters via The Star, 25 Jun 2025](https://www.thestar.com.my/tech/tech-news/2025/06/25/over-40-of-agentic-ai-projects-will-be-scrapped-by-2027-gartner-says)). Gartner also predicts that by 2027, 50% of business decisions will be augmented or automated by AI agents; this page is undated ([Computer Weekly, undated](https://www.computerweekly.com/news/366626700/Gartner-Build-trust-in-data-before-betting-the-business-on-AI)).
- **McKinsey State of AI 2025.** The survey had 1,993 participants and was fielded 25 Jun–29 Jul 2025. 88% of organisations use AI, but only 7% say it is fully scaled ([McKinsey, 10 Dec 2025](https://www.mckinsey.com/featured-insights/week-in-charts/ai-at-work-but-not-at-scale)). Further results reported by IT Brief ([IT Brief UK, 11 Nov 2025](https://itbrief.co.uk/story/mckinsey-report-shows-ai-interest-but-slow-scaling)):
  - 62% are at least experimenting with agents, and 23% are scaling an agentic system.
  - 39% report any effect on enterprise-level EBIT.
  - More than half experienced at least one negative consequence of AI, and inaccuracy was the most commonly cited negative consequence and risk.
- **MIT NANDA, "The GenAI Divide".** Based on about 150 interviews, a 350-employee survey and 300 public deployments. About 5% of AI pilots achieve rapid revenue acceleration. Bought solutions succeed about 67% of the time; internal builds succeed about a third as often ([Fortune, 18 Aug 2025](https://fortune.com/2025/08/18/mit-report-95-percent-generative-ai-pilots-at-companies-failing-cfo/)).
- **a16z CIO survey.** 100 CIOs across 15 industries expect LLM spend to grow about 75%. Innovation budgets fell from about 25% to 7% of LLM spend. Data analysis is named among use cases with steady adoption, but no figure is given ([a16z, 10 Jun 2025](https://a16z.com/ai-enterprise-2025/)).
- **WisdomAI survey.** 201 senior data leaders at North American companies with at least US$1bn revenue ([GovInfoSecurity, 21 Aug 2026](https://www.govinfosecurity.com/ai-analytics-hits-trust-barrier-a-32632)).
  - 19% are very confident in AI-generated analysis, 46% somewhat confident, and 35% not very or not at all confident.
  - 56% have AI analytics in production.
  - 48% say visibility into how AI analysis is generated would improve accuracy.
- **insightsoftware survey.** 114 data and analytics leaders ([insightsoftware, 10 Jun 2026](https://www.insightsoftware.com/blog/why-dont-data-leaders-trust-ai-and-other-insights-from-our-2026-ai-survey/)).
  - 51% trust AI-generated insights.
  - 26% have suffered negative consequences from hallucinations or unreliable AI.
  - 53% prioritise audit trails for AI answers, and 51% prioritise verifiable, deterministic outputs.
  - 31% cite inability to verify results.
- **Hex.** In a survey of 65+ data leaders in December 2025, 31% named data trust and accuracy as their top AI concern ([Hex, State of Data Teams 2026, undated, accessed 7 Nov 2026](https://hex.tech/state-of-data-teams/)).
- **UK financial services.** 75% of firms already use AI and a further 10% plan to within three years. 46% report only partial understanding of the AI they use ([Bank of England and FCA, 21 Nov 2024](https://www.bankofengland.co.uk/report/2024/artificial-intelligence-in-uk-financial-services-2024)).
- **Market size forecasts.**
  - Gartner: AI governance platform spending of US$492m in 2026, rising past US$1bn by 2030. Organisations with such platforms are 3.4 times more likely to achieve high governance effectiveness ([Gartner, 17 Feb 2026](https://www.gartner.com/en/newsroom/press-releases/2026-02-17-gartner-global-ai-regulations-fuel-billion-dollar-market-for-ai-governance-platforms)).
  - Forrester: US$15.8bn of AI governance software spend by 2030 ([Forrester, 13 Nov 2024](https://www.forrester.com/blogs/ai-governance-software-spend-will-see-30-cagr-from-2024-to-2030)).
  - The two forecasts use very different market definitions, so do not quote them side by side.

### 1.4 Research evidence that agents mishandle inference

- **Luo, Kasirzadeh & Shah.** They identify four failure modes in AI-scientist systems: inappropriate benchmark selection, data leakage, metric misuse and post-hoc selection bias. Trace logs and code reveal these failures far better than the final paper does, and the authors recommend that venues require trace logs and code ([arXiv 2509.08713, 10 Sep 2025; v2 20 Dec 2025](https://arxiv.org/abs/2509.08713)).
- **Miao, Pritchard & Zou, "The Agentic Garden of Forking Paths"** ([arXiv 2607.01507, 1 Jul 2026](https://www.alphaxiv.org/abs/2607.01507)).
  - Agents given opposing personas reported divergent conclusions from the same data. They reproduced 72% of the ideological gap seen among 42 human research teams.
  - 86% of the agents' reports passed independent AI methodological review, so the authors place the risk in "selective exploration and reporting" rather than in flawed analyses.
  - They propose an "m-value" and an "Agentic Bootstrap" to measure it.
- **Thomas, Gligorić & Shah.** They describe p-hacking by tuning LLM configurations, and a "preregister for the next LLM" protocol that would have blocked 73.9% and 72.7% of successful hacks in two tasks ([arXiv 2606.27687, 26 Jun 2026](https://arxiv.org/abs/2606.27687)).
- **Miao, Mu, Chen & Zou (Fisher-R1).** Agents "frequently make subtle inferential errors that lead to incorrect conclusions" even when their code runs. Their P-Bench benchmark has 425 hypothesis-testing tasks ([Hugging Face Papers, 11 Aug 2026](https://huggingface.co/papers/2608.07437)). A NeurIPS 2026 oral listing appeared in search results only: **UNVERIFIED**.
- **BixBench (FutureHouse).** On bioinformatics analysis tasks, open-answer accuracy was 17% for Claude 3.5 Sonnet and 9% for GPT-4o ([FutureHouse, 4 Mar 2025](https://www.futurehouse.org/research/bixbench)).
- **Text-to-SQL.** Google's Gemini-SQL2 leads the BIRD benchmark at 80.04%, against a 92.96% human-expert baseline ([AI Weekly, 13 Jun 2026](https://aiweekly.co/alerts/googles-gemini-sql2-tops-bird-text-to-sql-at-8004)).
- **POPPER (Huang et al.).** Agents design falsification experiments under "a novel sequential testing framework" that "ensures strict Type-I error control". The authors report results comparable to human scientists with a ten-fold time reduction ([ICML 2025 poster](https://icml.cc/virtual/2025/poster/44356); [arXiv 2502.09858, 14 Feb 2025](https://arxiv.org/abs/2502.09858)). Whether POPPER uses e-values is **UNVERIFIED**; the abstract does not say.

*Assessment.* Analytics agents are now default features of the main data platforms. AI-scientist companies are funded at unicorn scale and are selling to pharma. Two things matter most for BUACHAILLE:
- Measured confidence in agent output is low, and buyers are asking for audit trails and verifiability.
- The best evidence on agent failure is about forking paths and selective reporting, not syntax. Agents pass methodological review and still mislead. That is the gap a sealed-fold, FDR-controlled referee addresses, and the vendors' own caveats (Edison, Sakana) make the point for you.

---

## 2. Competitive and adjacent landscape

### 2(a) Experimentation platforms and their statistical safeguards

| Platform | Ownership (date, source) | Safeguards (source) | Public pricing (source) |
|---|---|---|---|
| Statsig | Bought by OpenAI for US$1.1bn in an all-stock deal, announced 2–3 Sep 2025. Founder Vijaye Raji became OpenAI's CTO of Applications, and Statsig is to "continue to operate independently" from Seattle ([TechRepublic, 3 Sep 2025](https://www.techrepublic.com/article/news-openai-statsig-acquisition/)). | **Sequential testing** since 4 Oct 2022: p-values adjusted for interim looks, which requires a target duration ([Statsig, 4 Oct 2022](https://statsig.com/updates/update/sequential-testing-capabilities)). **Benjamini–Hochberg** is optional, per experiment or set org-wide as a policy, and covers top-line metrics only ([Statsig docs, accessed 7 Nov 2026](https://docs.statsig.com/experiments/statistical-methods/methodologies/benjamini-hochberg-procedure)). CUPED details **UNVERIFIED**. An MCP server lets agents create experiments. | Pro: US$150/month including 5m events, plus US$50 per extra million events ([Statsig FAQ, accessed 7 Nov 2026](https://statsig.com/faq/is-the-pro-tier-priced-at-usd150-per-month-for-unlimited-users)). |
| Eppo | Acquired by Datadog. The press release ([5 May 2025](https://business.mammothtimes.com/mammothtimes/article/gnwcq-2025-5-5-datadog-acquires-eppo-to-expand-its-ai-product-analytics-experimentation-and-feature-flag-capabilities)) gives no price; US$220m was reported ([AIM Research, c. 1 May 2025](https://aimresearch.co/market-industry/datadog-enters-the-experimentation-space-with-220-million-eppo-deal)). | **CUPED++**, which fits ridge regressions on pre-period data and assignment properties ([Eppo docs](https://docs.geteppo.com/statistics/cuped/)). **"Sequential analysis (always valid)"** and Bayesian analysis ([Eppo docs, accessed 7 Nov 2026](https://docs.geteppo.com/statistics/)). Eppo has a multiple-testing correction, but the method is **UNVERIFIED**. | No list price. Vendr median US$45,000/yr, range US$15,900–94,000 ([Vendr, updated Feb 2026](https://www.vendr.com/marketplace/eppo)). |
| GrowthBook | Independent, with an open-source core. | Bayesian and frequentist analysis and "Multiple Testing Corrections" (methods not named) in all tiers. Sequential testing, CUPED and bandits in Pro and Enterprise; post-stratification in Enterprise only ([GrowthBook pricing, accessed 7 Nov 2026](https://growthbook.io/pricing)). MCP server. | Self-hosted open source: free (1 project). Cloud Starter: free (3 users). Pro: US$40/seat/month (up to 30 users). Enterprise: custom (same source). |
| Optimizely | Independent; Opal agents. | Stats Engine (since Jan 2015) runs sequential tests that "can be stopped any time with valid results" and "reports winners and losers with low false discovery rate instead of low false positive rate" ([Optimizely, 20 Jan 2015](https://www.optimizely.com/insights/blog/statistics-for-the-internet-age-the-story-behind-optimizelys-new-stats-engine/)). | No list price. Vendr median US$81,447/yr, range US$26,460–261,075, from 126 purchases ([Vendr, updated Feb 2026](https://vendr.com/marketplace/optimizely)). |
| LaunchDarkly | Independent. | Bayesian or frequentist (fixed-horizon or sequential) analysis. CUPED for mean metrics. A multiple-comparison correction toggle per experiment, sample-ratio-mismatch detection and stratified sampling ([LaunchDarkly docs, accessed 7 Nov 2026](https://launchdarkly.com/docs/home/experimentation/analyze)). | According to a competitor's article: Developer plan includes 100k experimentation MAU; Foundation is US$3 per 1,000 experimentation MAU/month ([GrowthBook blog, 14 Jun 2026](https://www.growthbook.io/insights/launchdarkly-pricing)). **UNVERIFIED** against LaunchDarkly's own pricing page. |

*Assessment.* Every safeguard above works inside a pre-declared experiment: it corrects error rates for the metrics and variants of that one test. None of the pages read describes hiding confirmation data from the analyst, or metering false discovery rate across an agent's open-ended stream of exploratory claims. Two of the five vendors now belong to companies with agent strategies (OpenAI, Datadog), and Statsig and GrowthBook already expose experiments to agents through MCP. These platforms are both the most natural integration point (BUACHAILLE as the referee behind their MCP tools) and the most plausible fast followers.

### 2(b) AI analytics vendors positioning on trust or verification

- **QueryStory.** Emerged from stealth with a US$6m seed raised in late 2025 at a reported US$60m valuation, from Brightmind Partners and New York Life Ventures ([TechCrunch, 26 Aug 2026](https://techcrunch.com/2026/08/26/querystory-wants-you-to-believe-what-ai-is-telling-you/)).
  - Agents attach a confidence indicator to each analysis, the SQL behind it appears automatically, and users can flag analyses for human review, which is recorded.
  - Pricing is undisclosed.
- **Summation.** Founded by Ian Wong (former Opendoor CTO) and RC Ramarathinam. It has raised US$35m: Benchmark led the seed and Kleiner Perkins led the A. It calls itself a "decision-grade AI platform" ([GeekWire, 2025, exact date not shown](https://www.geekwire.com/2025/opendoor-co-founder-brings-seattle-area-startup-summation-out-of-stealth-with-35m-in-funding/)).
  - It launched a self-serve "$60 plan" for an AI analyst that "promises to check its work". The method and billing period are not described ([RuntimeWire, 10 Sep 2026](https://runtimewire.com/article/summation-launches-60-ai-analyst-ian-wong)).
- **Solid.** Raised a US$20m seed from Team8 and SignalFire to automate a semantic layer, so that AI agents and dashboards share one definition of business terms ([The AI Insider, 24 Feb 2026](https://theaiinsider.tech/2026/02/24/solid-launches-with-20m-in-seed-funding-to-make-enterprise-ai-reliable-at-scale/)).
- **DataKid AI.** An "automated AI data analyst" for CSV uploads of up to 50MB, offered on a free trial. It makes no verification claims, and the listing itself warns that it "may produce inaccurate information" ([AIPure, updated 8 Mar 2026](https://aipure.ai/products/datakid-ai)). No funding found.
- **Probably.** Raised a US$9m seed led by a16z. It pairs an LLM with a deterministic validator that checks outputs against structured data, adds citations and audit trails, and targets 99.99% accuracy ([Pulse aggregator, 16 Jun 2026](https://www.pulse.bot/ai/deals/probably-secures-9m-seed-round-led-by-andreessen-horowitz-c6314ca4-3629-4cf5-b031-e120c286387c/)). This is from an aggregator, so treat it as moderately reliable.
- **Pramaana Labs.** Raised a US$27m seed led by Khosla Ventures to build formal verification of AI reasoning against tax, legal, clinical and safety rules. The round date was not given ([Crypto Briefing, around Jun 2026](https://cryptobriefing.com/pramaana-labs-27m-seed-ai-verification/)).
- **Axiomatic AI.** Raised a US$18m seed led by Engine Ventures, with Kleiner Perkins participating, for formal and physics-based verification of AI in engineering and science ([Business Wire, 9 Mar 2026](https://www.businesswire.com/news/home/20260309009285/en/Axiomatic-AI-Raises-$18M-to-Build-the-Intelligence-Infrastructure-for-Verified-Science-Engineering)).
- **Helical.** A London company that raised a US$10m seed led by redalpine for a "compounding evidence layer" making pharma AI predictions checkable and repeatable ([BriefGlance, 14 Apr 2026](https://briefglance.com/articles/helical-raises-10m-to-fix-pharmas-ai-reproducibility-problem)).

*Assessment.* This group verifies computation, lineage, semantics or formal logic. None of the material read claims multiplicity control across many tests, or confirmation on held-out data. These companies are complements and potential channel partners: a QueryStory or Summation finding could carry a BUACHAILLE certificate. They also show investors will fund "trust in AI analysis" at seed sizes of US$6m–35m.

### 2(c) Model validation, AI governance and model risk tools

| Vendor | Latest funding and positioning (source) | Public pricing or ACV (source) |
|---|---|---|
| ValidMind | US$8.1m seed led by Point72 Ventures ([Finextra](https://www.finextra.com/newsarticle/43914/validmind--raises-81m-for-ai-risk-management-platform)). The date is not shown on that page; the Business Wire URL indicates 27 Mar 2024. The Python library is on PyPI, dual-licensed AGPL-3.0 or commercial, v2.15.0 ([PyPI, accessed 7 Nov 2026](https://pypi.org/project/validmind/)). The documentation lists SR 26-2, SS1/23, E-23 and EU AI Act use cases ([ValidMind docs, accessed 7 Nov 2026](https://docs.validmind.ai/about/overview.html)). | Four tiers, all "Contact us" ([Toolradar, confirmed 3 Nov 2026](https://toolradar.com/tools/validmind/pricing)). No public figure. |
| Monitaur | US$6m Series A led by Cultivation Capital ([WilmerHale, 21 May 2024](https://www.wilmerhale.com/en/insights/news/20240521-monitaur-a-leading-model-governance-platform-for-highly-regulated-industries-raises-6m-series)). | AWS Marketplace public offer: Govern US$500,000 per 36 months; Automate US$100,000 per 36 months; extra usage US$0.10 per unit ([AWS Marketplace, accessed 7 Nov 2026](https://aws.amazon.com/marketplace/pp/prodview-pkxt75dzzqu3e)). That annualises to about US$166,667 and US$33,333 a year (computed). |
| Fiddler | US$30m Series C led by RPS Ventures, US$100m raised in total. Positions itself as a "control plane" for AI agents ([CIO Influence, 27 Jan 2026](https://cioinfluence.com/security/fiddler-raises-30m-series-c-to-power-the-control-plane-for-ai-agents)). | Free and Developer tiers at US$0, Enterprise custom. The same page's FAQ quotes "$0.002 per trace", which conflicts ([Toolradar, Nov 2026](https://toolradar.com/tools/fiddler-ai/calculator)). |
| Arthur | Open-sourced the Arthur Engine for real-time evaluation. Has raised more than US$60m since 2019 ([VKTR, 31 Mar 2025](https://www.vktr.com/the-wire/arthur-open-sources-first-real-time-ai-evaluation-engine/)). | No public figure found. |
| Credo AI | US$21m of new capital, US$41.3m in total ([Business Wire via SDxCentral](https://www.sdxcentral.com/press-releases/credo-ai-announces-21-million-in-new-capital-grows-leadership-team-to-match-the-rapid-pace-of-ai-innovation-emerges-as-the-standard-of-responsible-ai-governance/)). The page is undated; the syndication URL implies 30 Jul 2024. | No public figure found. |
| Holistic AI | Named a Challenger in Gartner's first Magic Quadrant for AI Governance Platforms, 2026 ([Holistic AI, undated](https://www.holisticai.com/blog/holistic-ai-named-a-challenger-in-gartner-magic-quadrant)). A "US$300m" funding claim on Signalbase cites no primary source: **UNVERIFIED** and likely unreliable ([Signalbase](https://www.trysignalbase.com/news/funding/revolutionizing-ai-governance-holistic-ai-secures-300-million-in-funding)). | No public figure found. |
| Yields.io | A €1.25m round was reported in January 2018, from a headline only ([tech.eu, 9 Jan 2018](https://tech.eu/2018/01/09/yields-io-funding/)): **UNVERIFIED**. | No public figure found. |
| SAS Model Risk Management | Not researched in depth. | No public figure found. |

*Assessment.* These tools inventory models, document them, run validation test suites and monitor drift. None adjudicates a stream of agent-generated claims on sealed data. ValidMind is the most important adjacency: it has an open-source Python library, AGPL dual licensing, and explicit SS1/23 and SR 26-2 positioning, so a BUACHAILLE certificate could feed its evidence store. It is also the most likely incumbent to add an "agent claims" module.

### 2(d) Anyone doing statistical validity, FDR control or pre-registration enforcement for AI agents

- **MethodSeal.** Built by Jamey Kistner (OSINTelligence LLC) and published on OSF in July 2026, MIT-licensed and written in pure Python with no dependencies ([HackerNoon, 18 Aug 2026](https://hackernoon.com/methodseal-earns-an-8979-proof-of-usefulness-score-for-enforcing-reproducible-experiments)).
  - It hash-seals hypotheses, thresholds and the analysis plan, and a pre-tool-use hook blocks edits unless they are logged: "There is no bypass flag".
  - It explicitly targets autonomous AI agents. This is the closest overlap with BUACHAILLE's pre-registration and ledger features. It has no sealed folds or FDR control in the article read.
- **SDCP (Scientific Discovery Control Plane).** A self-funded, one-person prototype that pre-registers by hash and seals forecasts. It was seeking US$5,000 on Manifund, and reports calibrated false-discovery rates on null worlds without giving numbers. The post is dated 9 October; the year is not shown, **UNVERIFIED** ([EA Forum](https://forum.effectivealtruism.org/posts/kLi7afPWBW78jJYc3/measuring-how-often-an-ai-research-agent-fools-itself-an)).
- **Brain Researcher (Poldrack and colleagues).** An agentic neuroimaging platform with a "commitment card" written before analysis and "sealed with a content hash", FDR q-values, Holm adjustments and audit bundles. It is academic, not a product ([arXiv 2608.19902, 2026](https://arxiv.org/pdf/2608.19902)).
- **Google Science One.** An experimental prototype that builds chains of evidence and includes a code-rerun audit. The blog post mentions no holdouts and no multiple-testing control ([Google Research, 30 Jul 2026](https://research.google/blog/science-one-framework-a-verifiable-autonomous-research-framework-via-chain-of-evidence/)).
- **Academic methods.** POPPER (sequential Type-I control, ICML 2025), the m-value and Agentic Bootstrap (Jul 2026), preregistering for the next LLM (Jun 2026) and Fisher-R1 (Aug 2026) are all cited in §1.4.
- **Open-source building blocks on PyPI** (all accessed 7 Nov 2026):
  - [online-fdr](https://pypi.org/project/online-fdr/), v1.0.0, first released 2 Jul 2025, latest 19 Oct 2026.
  - [expectation](https://pypi.org/project/expectation/), v0.6.1 (e-values, confidence sequences), latest 2 Sep 2026.
  - [confseq](https://pypi.org/project/confseq/), v0.0.11, latest Jan 2023.
  - [savvi](https://pypi.org/project/savvi/), v0.3.1, MIT licence, Oct 2024.
- **Theory.** "Online multiple testing with e-values" ([PMLR v238, 2024](https://proceedings.mlr.press/v238/xu24a.html)) and "Improving online FDR procedures via online analogs of e-closure and compound e-values" ([PMLR v337, 2026](https://proceedings.mlr.press/v337/xu26a.html)). Only the titles were seen; content **UNVERIFIED**.

*Assessment.* Across this session's searches I found no funded company selling the combination of a tamper-evident exploration ledger, sealed rotating confirmation folds, online FDR control with e-values, and signed certificates for agents. This is absence of evidence, and my confidence in it is moderate. The idea is clearly in the air in late 2026: MethodSeal, SDCP, and the Stanford and CMU papers all appeared between June and August 2026. The groups of James Zou (Stanford), Nihar Shah (CMU) and Candès/Leskovec could be collaborators, advisers or spin-out competitors. The defensible ground is the combination, packaged for regulated buyers, plus the certificate format. No single primitive is defensible on its own.

---

## 3. Cost of false discoveries

### 3(a) Drug discovery: following up a spurious lead

- **Cost per stage.** In the Paul et al. productivity model, out-of-pocket cost per candidate (per work-in-progress unit) is US$2.5m at hit-to-lead, US$10m at lead optimisation, US$5m preclinical, US$15m in Phase I, US$40m in Phase II and US$150m in Phase III. Phase II has a 34% probability of technical success, and the capitalised cost per new molecular entity launched is US$1,778m ([Paul et al., Nat Rev Drug Discov 9:203–214, 19 Feb 2010](https://doi.org/10.1038/nrd3078); [PDF](https://www.Gwern.net/doc/statistics/decision/2010-paul.pdf)). Summing these, one spurious candidate carried from hit-to-lead through Phase II consumes US$72.5m out of pocket (computed; 2010 model, not inflation-adjusted).
- **Cost per new drug.** Using 63 of the 355 drugs approved in the US from 2009 to 2018, the median R&D cost per new drug was US$985m and the mean US$1.3bn ([LSE on Wouters et al., JAMA, 3 Mar 2020](https://www.lse.ac.uk/news/latest-news-from-lse/c-march-20/average-cost-of-developing-a-new-drug-could-be-up-to-1.5-billion-less-than-pharmaceutical-industry-claims)).
- **Cost per pivotal trial.** Across 138 trials, pivotal trials had a median cost of US$19m, with half costing between US$12m and US$33m ([Outsourcing-Pharma on Moore et al., JAMA Intern Med, 26 Sep 2018](https://www.outsourcing-pharma.com/Article/2018/09/26/Clinical-trial-cost-is-a-fraction-of-the-drug-development-bill)).
- **Success rates, 2011–2020.** Phase II to Phase III: 28.9%. Likelihood of approval from Phase I: 7.9% ([BIO / Informa / QLS, Feb 2021](https://www.cphi-online.com/46/resourcefile/11/36/30/2021%20Clinical%20Development%20Success%20Rates%202011-2020%20v17.pdf)).
- **Reproducibility of the starting evidence.** Amgen confirmed only 6 of 53 "landmark" preclinical cancer studies (11.3%, computed), and Bayer reproduced about 25% ([MedicalXpress on Begley & Ellis, Nature 483:531–533, 29 Mar 2012](https://medicalxpress.com/news/2012-03-duo-preclinical-cancer-results-plain.html)).
- **Waste in US preclinical research.** More than 50% of preclinical research is irreproducible, costing about US$28bn a year in the US alone. Biological reagents account for 36% of that spend and study design for 28% ([Newswise on Freedman, Cockburn & Simcoe, PLOS Biol, 9 Jun 2015](https://www.newswise.com/articles/new-study-on-research-reproducibility-proposes-fixes-for-28-billion-problem); [DOI](https://doi.org/10.1371/journal.pbio.1002165)). The share attributed to "data analysis and reporting" is not in the text I read: **UNVERIFIED**.
- **Cost per validation experiment.** The Reproducibility Project: Cancer Biology had a US$1.6m budget. Its estimated cost per replicated study rose from US$25,000–35,000 to about US$40,000 ([Nature News, 2015 per URL](https://www.nature.com/articles/nature.2015.18938); [The Scientist](https://www.the-scientist.com/reproducibility-initiative-shrinks-34390)). Only 50 of 193 planned experiments were completed. Each replication took a mean of 197 weeks ([eLife, 7 Dec 2021](https://elifesciences.org/articles/67995)). Replication effects had a median 85% smaller than the originals, and 40% of positive effects replicated on three or more criteria ([eLife, 2021](https://elifesciences.org/articles/75830)).
- **Cost of a spurious AI-generated lead specifically.** No public figure exists. The closest real-world signal is Recursion halting mid-stage programmes in its AI-derived pipeline while running a 2024 net loss of about US$464m (§1.2).

### 3(b) Product decisions and A/B tests

- **Success rates in practice.** At Google and Bing, "only about 10% to 20% of experiments generate positive results". At Microsoft, a third are positive, a third neutral and a third negative. In Bing's headline example, one untested idea raised revenue 12%, worth more than US$100m a year in the US ([Kohavi & Thomke, HBR, Sep–Oct 2017](https://web-docs.stern.nyu.edu/executive/The%20Surprising%20Power%20of%20Online%20Experiments.pdf)).
- **False-positive risk.** With a one-sided p-value threshold of 0.025 and 80% power, the share of significant results that are false positives rises as success rates fall ([Kohavi, Deng & Vermeer, "A/B Testing Intuition Busters", KDD 2022](https://airbnb.tech/wp-content/uploads/sites/19/2025/10/ABTestingIntuitionBusters.pdf); [abstract](https://exp-platform.com/abtestingintuitionbusters/)). All five figures were recomputed and match (appendix).
  - Microsoft: 33% success rate, 5.9% false-positive risk.
  - Bing: 15% success, 15.0% false-positive risk.
  - Booking.com, Google Ads and Netflix: 10% success, 22.0% false-positive risk.
  - Airbnb Search: 8% success, 26.4% false-positive risk.
- **Most ideas fail.** "60-90% of ideas do not improve the metric(s) they were designed to improve" ([Kohavi, ACM RecSys slides, Sep 2012](https://ai.stanford.edu/%7Eronnyk/2012-09ACMRecSysNR.pdf)).
- **Twyman's law.** "Any figure that looks interesting or different is usually wrong", attributed to Tony Twyman ([Wikipedia, accessed 7 Nov 2026](https://en.wikipedia.org/wiki/Twyman%27s_law)). Kohavi, Tang & Xu's *Trustworthy Online Controlled Experiments* has a chapter titled "Twyman's Law and Experimentation Trustworthiness" ([Cambridge Core listing](https://www.cambridge.org/core/books/trustworthy-online-controlled-experiments/twymans-law-and-experimentation-trustworthiness/886425EC1B92BD23A0DC5E6817785190)). The chapter title was seen in a search listing; the page fetch failed, and the publication year is **UNVERIFIED** this session.
- **Aggregate cost of wrong product decisions.** No public figure was found.

### 3(c) Bank and finance model failures linked to overfitting or data mining

- **No direct precedent.** No public regulator fine was found that attributes a bank's loss to data mining or overfitting as such. The nearest public cases concern backtests, unaddressed model flaws and model governance.
- **SEC v F-Squared.** A US$35m penalty, with the firm admitting wrongdoing, for marketing hypothetical backtested AlphaSector performance as real. The algorithm did not exist during the period claimed, and a calculation error inflated hypothetical results by about 350% ([ThinkAdvisor, 22 Dec 2014](https://thinkadvisor.com/2014/12/22/f-squared-pays-sec-35m-fine-to-sec-for-misleading)).
- **SEC v Two Sigma.** US$90m in penalties. Model vulnerabilities identified by March 2019 were not fixed until August 2023, and an employee made unauthorised changes to "more than a dozen" models. Two Sigma repaid US$165m to funds ([SEC via Newsfile, 16 Jan 2025](https://www.newsfilecorp.com/release/237517/SEC-Charges-Two-Sigma-for-Failing-to-Address-Known-Vulnerabilities-in-its-Investment-Models)).
- **JPMorgan "London Whale".** About US$920m in fines: OCC US$300m, Federal Reserve US$200m, SEC US$200m and FCA £137.6m. The trading loss was US$6.2bn ([The Global Treasurer, 19 Sep 2013](https://www.theglobaltreasurer.com/2013/09/19/jp-morgan-fined-us920m-for-london-whale-episode/)). The bank's task force found its VaR model "badly flawed, understating risk" ([Harvard Law School Forum, 24 Jan 2013](https://corpgov.law.harvard.edu/2013/01/24/the-jp-morgan-whale-report-and-the-ghosts-of-the-financial-crisis)).
- **ECB TRIM.** The ECB's review of internal models produced "over 5,000 findings" and "a 12% increase, or about €275 billion, of risk-weighted assets" across 65 banks ([ECB, 19 Apr 2021](https://www.bankingsupervision.europa.eu/press/pr/date/2021/html/ssm.pr210419~94c010eb9d.en.html)).
- **OCC v Citibank.** A US$400m civil money penalty for risk-management, data-governance and internal-control failures ([OCC, 7 Oct 2020](https://occ.gov/news-issuances/news-releases/2020/nr-occ-2020-132.html)).
- **Academic evidence on data mining in finance.**
  - New factors need a t-ratio "greater than 3.0", and "most claimed research findings in financial economics are likely false" ([Harvey, Liu & Zhu, NBER WP 20592, Oct 2014; RFS 29(1), 2016](https://nber.org/papers/w20592)).
  - Across 888 trading algorithms, the backtest Sharpe ratio offered "little value in predicting out of sample performance (R² < 0.025)". Moreover, "the more backtesting a quant has done for a strategy, the larger the discrepancy" ([Quantpedia on Wiecki et al., 4 May 2016](https://quantpedia.com/quantopians-academic-paper-about-in-vs-out-of-sample-performance-of-trading-alg/)).

*Assessment.* Drug discovery has the strongest money-at-risk story: tens of millions of dollars per false lead carried into the clinic, and a validation experiment costs tens of thousands of dollars and takes years. Product analytics has the clearest statistical story, because low base rates turn a fifth to a quarter of "wins" into false positives. Banking has no clean data-mining fine to point to. Its story is governance and effective challenge (Two Sigma, TRIM), so do not overclaim a regulatory-penalty case.

---

## 4. Regulatory hooks

### 4.1 PRA SS1/23, Model risk management principles for banks

- **Dates.** Published with PS6/23 in May 2023. Paragraph 1.5: "The policy comes into effect on Friday 17 May 2024" ([SS1/23 PDF, May 2023, via Deloitte mirror](https://www.deloitte.com/content/dam/assets-zone2/se/sv/docs/services/risk-advisory/2024/ss123.pdf)).
- **April 2026 amendment.** Published and effective 23 April 2026 under LIAF01/26. It clarifies that the expectations are "not conditions for internal model approval", and gives firms receiving their first internal-model permission 12 months to comply ([Bank of England, 23 Apr 2026](https://www.bankofengland.co.uk/prudential-regulation/publication/2026/april/low-impact-amendments-finalisation-april-2026); [SS1/23 page](https://www.bankofengland.co.uk/prudential-regulation/publication/2023/may/model-risk-management-principles-for-banks-ss)).
- **Scope (paragraph 1.2).** "This SS is relevant to all regulated United Kingdom (UK)-incorporated banks, building societies" … "PRA-designated investment firms with internal model approval to calculate regulatory capital requirements".
  - Firms without such permission: "The expectations in this SS do not apply to firms which do not have permission to use internal models … However, the PRA considers that those firms may find the proposed principles useful, and are welcome to consider them."
  - Paragraph 1.3 covers "all models, developed in-house or externally, including vendor models".
  - Source: the SS1/23 PDF above.
- **Definition of model risk (paragraph 2.6).** "Model risk is the potential for adverse consequences from model errors or the inappropriate use of modelled outputs to inform business decisions."
- **AI and machine learning.** The SS text itself does not use the words "artificial intelligence" or "machine learning"; I checked both the Bank of England PDF and the mirror. The Bank's publication page does list, among the SS's scope, "identifying and managing the risks associated with the use of artificial intelligence in modelling techniques such as machine learning to the extent that it applies to the use of models more generally" ([SS1/23 page, accessed 7 Nov 2026](https://www.bankofengland.co.uk/prudential-regulation/publication/2023/may/model-risk-management-principles-for-banks-ss)). The relevant SS text is technology-neutral ([PRA Rulebook, 17 May 2024 version](https://prarulebook.co.uk/guidance/supervisory-statements/ss01-23--model-risk-management-principles-for-banks/4---model-risk-management-principles-for--banks/17-05-2024)):
  - Principle 1.3(c) asks for "measures of a model's interpretability, explainability, transparency, and the potential for designer or data bias".
  - Principle 3.3(c) covers "dynamic models (ie models able to adapt, recalibrate, or otherwise change autonomously in response to new inputs)". Footnote 19 adds: "Including where parameters and/or hyperparameters are automatically recalculated over time."
- **Model inventory and definition (Principle 1).** From the same Rulebook version:
  - 1.1(a): "A model is a quantitative method, system, or approach that applies statistical, economic, financial, or mathematical theories, techniques, and assumptions…"
  - 1.2: "A comprehensive model inventory should be maintained to enable firms to: identify the sources of model risk…"
  - 1.2(c): the inventory should capture purpose and use, assumptions and limitations, validation findings, and governance details.
- **Independent validation (Principle 4).** The principle requires "a validation process that provides ongoing, independent, and effective challenge".
  - 4.1(a): "a validation function to provide an objective, unbiased, and critical opinion on…" model suitability, soundness, and the accuracy of data and outputs.
  - 4.1(d): "The validation function should operate independently from the model development process and from model owners."
  - 4.2(a): "All models should be subject to an independent review to ensure that models are suitable for their intended use."
  - 4.2(a)(ii): the review should "assess the conceptual soundness of the underlying theory of the model".
  - 4.3: process verification (inputs representative; code and calculations accurate and auditable).
  - Source: PRA Rulebook version above.

### 4.2 US: SR 11-7 has been replaced by SR 26-2

- **Replacement.** SR 26-2, "Revised Guidance on Model Risk Management", was issued by the Federal Reserve, OCC and FDIC on 17 April 2026. It "supersedes and replaces SR letter 11-7" (Guidance on Model Risk Management, 4 April 2011) and SR 21-8 (9 April 2021). It "is expected to be most relevant to banking organizations with over $30 billion in total assets regulated by the Federal Reserve" ([Federal Reserve, 17 Apr 2026](https://www.federalreserve.gov/supervisionreg/srletters/sr2602.htm)).
- **OCC version.** The OCC's Bulletin 2026-13 rescinds OCC Bulletin 2011-12 and the Comptroller's Handbook booklet, and states: "This guidance is applicable to all community banks, subject to the limitations discussed in the guidance" ([OCC, 17 Apr 2026](https://www.occ.gov/news-issuances/bulletins/2026/bulletin-2026-13.html)).
- **Generative and agentic AI are out of scope** (page 3, footnote 3): "Generative AI and agentic AI models are novel and rapidly evolving. As such, they are not within the scope of this guidance." ([SR 26-2 attachment](https://www.federalreserve.gov/supervisionreg/srletters/SR2602a1.pdf); footnote location per [Sullivan & Cromwell, Apr 2026](https://www.sullcrom.com/insights/memo/2026/April/OCC-Fed-FDIC-Issue-Revised-Guidance-Model-Risk-Management)).
  - The agencies "plan to issue in the near future" a request for information on model risk management, including banks' use of generative, agentic and AI-based models (OCC bulletin above).
- **Definition of a model** (Section II): "the term 'model' refers to a complex quantitative method, system, or approach that applies statistical, economic, or financial theories to process input data into quantitative estimates."
- **Effective challenge** (Section III): "Effective challenge is performed by individuals with the appropriate expertise to conduct a critical and objective challenge", with "sufficient independence to maintain objectivity".
- **Validation** (Section V): conceptual soundness; "Outcomes analysis compares model outputs to corresponding real-world outcomes"; ongoing monitoring.
- **Model inventory** (Section VI): "an effective model inventory includes sufficient information to understand model risks". Quotes in this and the two items above are from the SR 26-2 attachment.
- **Effective date.** None is stated in the attachment.
- **Other changes, per Orrick** ([Orrick, Apr 2026](https://www.orrick.com/en/Insights/2026/04/Agencies-Overhaul-Model-Risk-Management-Guidance-for-Banks-Heres-What-Changed)):
  - Non-compliance with the guidance will not of itself lead to supervisory criticism.
  - The definition of "model" is narrowed.
  - The independence of validation is de-emphasised in favour of "the rigor and effectiveness of the review".
- **SR 11-7 text.** I did not re-read the original SR 11-7 (fetch blocked).

### 4.3 FCA statements and AI Live Testing

- **AI Live Testing launch.** The feedback statement FS25/5 says: "We are launching AI Live Testing, where firms can work directly with our regulatory and technical teams". The FCA will explore "output-driven validation and other methods to evaluate the impact of AI system use", and "We will publish an evaluation report on AI Live Testing in Q1 2027" ([FCA FS25/5, 9 Sep 2025; updated 16 Mar 2026](https://www.fca.org.uk/publications/feedback-statements/fs25-5-ai-live-testing)).
- **First cohort.** Gain Credit, Homeprotect, NatWest, Monzo, Santander, Scottish Widows and Snorkl. The FCA said "AI testing is helping firms to address key questions around evaluation frameworks". Its technical partner Advai specialises in "automated testing, evaluation and assurance of AI systems" ([FCA, 3 Dec 2025](https://www.fca.org.uk/news/press-releases/fca-helps-firms-test-ai-safely)).
- **Second cohort.** Aereve, Coadjute, Barclays, Experian, GoCardless, Lloyds Banking Group (Scottish Widows), UBS and Palindrome. Testing runs from April to the end of 2026 ([FCA, 21 Apr 2026](https://www.fca.org.uk/news/press-releases/fca-announces-second-cohort-ai-live-testing)).
- **AI Lab.** It comprises AI Live Testing, the Supercharged Sandbox, AI Spotlight (applications open) and the AI Input Zone (open 14 May–19 June 2026). Examples of good and poor practice are due "later in 2026" ([FCA AI Lab, updated 3 Jul 2026](https://www.fca.org.uk/firms/ai-lab)).
- **No new AI rules.** The FCA will not introduce AI-specific rules and will rely on the Consumer Duty, SM&CR and existing governance expectations. Examples covering "AI governance, model testing, customer fairness and explainability" are due later in 2026. This is secondary reporting of an FCA blog I could not open ([FCA blog](https://www.fca.org.uk/news/blogs/ai-financial-services-approach); [Resultsense, 9 Jun 2026](https://www.resultsense.com/news/2026-06-09-fca-ai-financial-services-approach/); [Plenitude, 15 Jun 2026](https://www.plenitudeconsulting.com/news-insights/fca-outlines-ai-strategy-shaped-by-industry-engagement)). The exact FCA wording is **UNVERIFIED**.
- **Mills Review.** Seven recommendations, including "Monitor the transition to autonomous models" and "Enable the foundations for agentic finance" ([FCA, 6 Jul 2026](https://www.fca.org.uk/publications/corporate-documents/mills-review)).
- **Treasury Committee.** It criticised regulators' "wait-and-see" approach and recommended FCA guidance on SM&CR accountability for harm caused through AI, plus AI-specific stress testing ([HFW on Treasury Committee report, 20 Jan 2026](https://www.hfw.com/insights/ai-in-financial-services-treasury-committee-criticises-regulators-for-wait-and-see-approach/)).
- **Rathi at Mansion House.** He warned that rule-making alone means "chasing yesterday's market" and flagged growing autonomy of AI agents ([Resultsense on FCA speech, 22 Oct 2026](https://www.resultsense.com/news/2026-10-26-fca-rathi-mansion-house-ai-market-integrity/)).

### 4.4 EU AI Act: Articles 12, 15, 17 and the omnibus delay

Quotations are from the European Commission's AI Act Service Desk (accessed 7 Nov 2026) and euaiact.com.

- **Article 12(1)** ([Service Desk](https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-12)): "High-risk AI systems shall technically allow for the automatic recording of events (logs) over the lifetime of the system."
- **Article 12(2)** (same source): "In order to ensure a level of traceability of the functioning of a high-risk AI system that is appropriate to the intended purpose of the system, logging capabilities shall enable the recording of events relevant for: (a) identifying situations that may result in the high-risk AI system presenting a risk within the meaning of Article 79(1) or in a substantial modification; (b) facilitating the post-market monitoring referred to in Article 72; and (c) monitoring the operation of high-risk AI systems referred to in Article 26(5)."
- **Article 15(1)** ([Service Desk](https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-15)): "High-risk AI systems shall be designed and developed in such a way that they achieve an appropriate level of accuracy, robustness, and cybersecurity, and that they perform consistently in those respects throughout their lifecycle."
- **Article 15(3):** "The levels of accuracy and the relevant accuracy metrics of high-risk AI systems shall be declared in the accompanying instructions of use."
- **Article 15(4)**, on systems that keep learning, must "eliminate or reduce as far as possible the risk of possibly biased outputs influencing input for future operations (feedback loops)".
- **Article 17(1)** ([Service Desk](https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-17); [euaiact.com](https://www.euaiact.com/article/17)): "Providers of high-risk AI systems shall put a quality management system in place…". Its listed elements include:
  - point (d): "examination, test and validation procedures to be carried out before, during and after the development of the high-risk AI system, and the frequency with which they have to be carried out;"
  - point (f): "systems and procedures for data management, including data acquisition, data collection…"
  - point (k): "systems and procedures for record-keeping of all relevant documentation and information;"
- **Annex III 5(b)**, the main lending hook ([Service Desk](https://ai-act-service-desk.ec.europa.eu/en/ai-act/annex-3)): "AI systems intended to be used to evaluate the creditworthiness of natural persons or establish their credit score, with the exception of AI systems used for the purpose of detecting financial fraud".
- **Application dates after the Digital Omnibus on AI.** The Omnibus is Regulation (EU) 2026/1744, amending Regulation (EU) 2024/1689. It was published in the Official Journal on 24 July 2026 and entered into force on 27 July 2026 ([Cuatrecasas, Jul 2026](https://www.cuatrecasas.com/en/spain/intellectual-property/art/digital-omnibus-ai-has-been-published); [Hunton](https://www.hunton.com/privacy-and-cybersecurity-law-blog/eu-digital-omnibus-on-ai-enters-into-force)).
  - High-risk obligations for Annex III stand-alone systems now apply from **2 December 2027**.
  - Those for Annex I systems embedded in regulated products apply from **2 August 2028**.
  - The provisional agreement was reached on 6 May 2026 ([Gibson Dunn, 27 May 2026](https://www.gibsondunn.com/eu-ai-act-omnibus-agreement-postponed-high-risk-deadlines-and-other-key-changes/)).
  - The original Annex III date of 2 August 2026 is from my prior knowledge and was not re-verified: **UNVERIFIED**.

### 4.5 FDA: AI to support regulatory decision-making for drugs and biologics

- **Status.** "Considerations for the Use of Artificial Intelligence to Support Regulatory Decision-Making for Drug and Biological Products" was issued in January 2025 (FDA page dated 7 Jan 2025), docket FDA-2024-D-4689. It is still labelled "Draft" and "Not for implementation. Contains non-binding recommendations." ([FDA, accessed 7 Nov 2026](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/considerations-use-artificial-intelligence-support-regulatory-decision-making-drug-and-biological)).
  - The comment deadline was 7 April 2025 ([DLA Piper, 23 Jan 2025](https://dlapiper.com/insights/publications/2025/01/fda-releases-draft-guidance-on-use-of-ai)).
  - An article of 2 February 2026 still describes it as a draft ([The Pharma Letter](https://www.thepharmaletter.com/pharma-news/the-fda-ai-credibility-becomes-regulatory-reality)).
  - I found no final version. That none exists is **UNVERIFIED** beyond these sources.
- **Seven-step credibility assessment framework** (per DLA Piper):
  1. Define the question of interest.
  2. Define the context of use.
  3. Assess model risk from "model influence" and "decision consequence".
  4. Develop a credibility assessment plan.
  5. Execute the plan.
  6. Document results and any deviations.
  7. Decide whether the model is adequate for the context of use.
- **Scope.** The draft does not cover AI used in drug discovery, or operational uses that do not affect patient safety, drug quality or the reliability of nonclinical or clinical results (per DLA Piper).
- **FDA and EMA joint principles.** On 14 January 2026 the FDA and EMA issued ten guiding principles for good AI practice in drug development. They include a risk-based approach, proportional validation, a clear context of use, robust data governance and lifecycle monitoring ([Applied Clinical Trials, 29 Jan 2026](https://appliedclinicaltrialsonline.com/view/fda-ema-align-ten-principles-artificial-intelligence-use-drug-development)).

### 4.6 Journal and funder policies on AI-generated analysis

- **Nature Portfolio.** "Large Language Models (LLMs), such as ChatGPT, do not currently satisfy our authorship criteria", and "Use of an LLM should be properly documented in the Methods section". Generative-AI images are not permitted. The policy says nothing specific about AI-performed data analysis ([Nature Portfolio AI policy, npj QI page, accessed 7 Nov 2026](https://www.nature.com/npjqi/editorial-policies/ai)).
- **Science journals.** AI used in the research itself, including data generation or analysis, must be described in Methods with the model name and version, and AI cannot be an author. This is per a third-party summary that cites Science's editorial policies and a September 2026 AI-use guidelines PDF ([Manusights, updated 8 Oct 2026](https://manusights.com/blog/science-ai-policy)). The primary text is **UNVERIFIED** (science.org blocked).
- **NIH (NOT-OD-25-132, 17 Jul 2025).** "Applications substantially developed by AI" will not be considered original. AI use that results in fabricated citations may be referred to the Office of Research Integrity. There is a cap of six applications per principal investigator per year from 25 September 2025, applying in full from 1 January 2026 ([University of Utah OSP summary, Jul 2025](https://osp.utah.edu/news/nih-not-od-25-132.php)). The NIH notice itself was not fetched.
- **Researchers.** Some are already asking venues to require agent "trace logs and code" alongside AI-generated papers ([Luo et al., Sep 2025](https://arxiv.org/abs/2509.08713)).

*Assessment: strength of the regulatory hook by beachhead.*

| Beachhead | Best hook | Strength | Why |
|---|---|---|---|
| UK banks with IRB or internal-model approval | SS1/23 Principle 4 (independent, effective challenge) and 1.2 (inventory) | Medium | Binding for this group; an independent referee and ledger maps onto 4.1(d) and 4.3. Analytics findings are not themselves "models", so the fit is evidential, not mandatory. |
| UK non-IRB lenders and fintechs | SS1/23 "welcome to consider"; FCA AI Live Testing "output-driven validation"; SM&CR accountability | Low–medium | Voluntary. The FCA has ruled out AI-specific rules; the commercial argument is defensibility under SM&CR. |
| US banks | SR 26-2 effective challenge | Low | Generative and agentic AI are explicitly out of scope, and an RFI is pending. This is an opening for thought leadership, not a compliance sale. |
| EU lenders | AI Act Articles 12, 15 and 17 via Annex III 5(b) from 2 Dec 2027 | Medium for consumer and sole-trader credit models; low for analytics agents | It binds providers of high-risk systems. Limited companies are legal persons, so most SME lending sits outside 5(b); sole traders are natural persons. |
| Drug discovery | FDA credibility framework; FDA–EMA principles | Low at the discovery stage; medium once outputs support regulatory submissions | The draft excludes discovery uses. |
| AI-for-science publishing | Nature and Science disclosure rules; NIH originality rule | Low–medium | They require disclosure, not validity; "trace logs" proposals point the right way. |
| Product analytics | None | None | The pull is purely commercial (§3(b)). |

---

## 5. Pricing benchmarks

### 5.1 Developer and experimentation infrastructure

- **GrowthBook.** Free open-source core; Cloud Pro is US$40/seat/month for up to 30 users; Enterprise is custom ([GrowthBook, accessed 7 Nov 2026](https://growthbook.io/pricing)). Ten Pro seats cost US$4,800 a year (computed).
- **Statsig.** Pro is US$150/month including 5m events, plus US$50 per extra million ([Statsig FAQ](https://statsig.com/faq/is-the-pro-tier-priced-at-usd150-per-month-for-unlimited-users)). At 10m events a month that comes to US$400/month (computed).
- **Langfuse** (open-core LLM observability). Hobby is free; Core is US$29/month plus usage; Pro is US$199/month plus usage; Enterprise is US$2,499/month. Usage was historically priced per 100k observations ([PricingSaaS, captured 2 Nov 2026](https://pricingsaas.com/companies/langfuse)).
- **LaunchDarkly.** Experimentation costs US$3 per 1,000 MAU/month on the Foundation plan, according to a competitor's article (**UNVERIFIED**, §2(a)).
- **Kosmos (Edison).** US$200 per run (200 credits at US$1). Edison says the price "ultimately will probably be higher" ([Edison, 5 Nov 2025](https://edisonscientific.com/news/announcing-kosmos)). A US$200/month subscription for 650 credits is described as temporary, and academics receive 650 credits a month ([Edison, 18 Dec 2025](https://edisonscientific.com/news/we-raised-70m-to-accelerate-science)).
- **Summation.** A self-serve "$60 plan"; billing period not stated ([RuntimeWire, 10 Sep 2026](https://runtimewire.com/article/summation-launches-60-ai-analyst-ian-wong)).
- **Databricks Genie One.** Pay-as-you-go pricing by tokens consumed ([SiliconANGLE, 16 Jun 2026](https://siliconangle.com/2026/06/16/databricks-new-agentic-coworker-genie-one-brings-ai-automation-every-part-business/)).

### 5.2 Annual contract values for ML governance, validation and observability tools

| Product | Figure | Source and date |
|---|---|---|
| Monitaur Govern | US$500,000 per 36 months (about US$166,667 a year, computed) | [AWS Marketplace, accessed 7 Nov 2026](https://aws.amazon.com/marketplace/pp/prodview-pkxt75dzzqu3e) |
| Monitaur Automate | US$100,000 per 36 months (about US$33,333 a year, computed) | same |
| Optimizely | Vendr median US$81,447/yr, range US$26,460–261,075, from 126 purchases | [Vendr, Feb 2026](https://vendr.com/marketplace/optimizely) |
| Arize (ML observability) | Vendr median US$60,000/yr, range US$60,000–98,070 | [Vendr, undated](https://www.vendr.com/marketplace/arize) |
| Eppo | Vendr median US$45,000/yr, range US$15,900–94,000 | [Vendr, Feb 2026](https://www.vendr.com/marketplace/eppo) |
| Weights & Biases | Vendr median US$37,800/yr, range US$14,952–91,038, from 43 purchases | [Vendr, undated](https://vendr.com/marketplace/weights-and-biases) |
| ValidMind, Credo AI, Holistic AI, Yields.io, SAS MRM | No public figure ("contact us") | §2(c) |

Gartner expects the average number of GRC solutions per large enterprise to rise from 8 in 2025 to 10 by 2028 (my reading: room for point tools) ([Gartner, 17 Feb 2026](https://www.gartner.com/en/newsroom/press-releases/2026-02-17-gartner-global-ai-regulations-fuel-billion-dollar-market-for-ai-governance-platforms)).

### 5.3 How pricing models are shifting

- **Kyle Poyar survey** (240+ software and AI companies, Apr–May 2025): over the previous 12 months, hybrid pricing rose from 27% to 41%, seat-based fell from 21% to 15%, and flat fees fell from 29% to 22%. 5% use outcome-based pricing today and 25% expect to by 2028. Companies with ACV under US$5k, and product-led companies, usually publish prices ([Growth Unhinged, 4 Jun 2025](https://www.growthunhinged.com/p/2025-state-of-b2b-monetization)).
- **Metronome** (100 SaaS companies, Jan 2025): 85% have adopted some usage-based pricing ([Metronome, 2025](https://metronome.com/state-of-usage-based-pricing-2025)).
- **Orb's 2026 study of 80 AI-agent companies:** 91.3% use usage-based pricing and 95% use hybrid pricing. I read this in Orb's own summary, so it is secondary ([Orb blog, undated](https://www.withorb.com/blog/saas-pricing-statistics)).

### 5.4 Design-partner arrangements

- **Bessemer** ([BVP Atlas, 6 May 2026](https://www.bvp.com/atlas/design-partners-the-pre-launch-edge-most-ai-founders-ignore)):
  - Practitioners typically run five to 12 design partners.
  - Partners should get discounts or early access, not indefinite free use, which BVP calls "an advisory relationship rather than a validation signal".
  - The ask at the end is binary: "go paid or don't".
  - Strella converted all 12 of its partners and reached US$1.6m ARR in its first monetised year.
- **Common Paper** ([Common Paper, 8 Sep 2022, updated 28 Nov 2024](https://commonpaper.com/blog/design-partner)):
  - Partners get free or "highly discounted" access, and either side can terminate at any time.
  - IP ownership clauses survive termination.
  - Agree the conversion milestone and future pricing early.

*Assessment.* The comparables imply a three-layer structure.
- **Open-source core:** free, competing with MethodSeal, online-fdr and expectation.
- **Hosted service:** usage-metered (per confirmatory test or certificate) or per seat. Public anchors are US$40/seat/month (GrowthBook), US$150/month plus events (Statsig) and US$200 per run (Kosmos).
- **Enterprise edition for banks and pharma:** priced against governance and validation ACVs, which sit at roughly US$33k–167k a year in the public data. There is no public ACV for the closest model-risk comparables.

---

## 6. Channels and events in 2027

| Event | Date and place | Beachhead | Source |
|---|---|---|---|
| Credit Scoring and Credit Control Conference XX | 31 Aug–3 Sep 2027, run by the University of Edinburgh CRC. The page does not state the 2027 venue; past editions were in Edinburgh. The 2025 edition had 400+ delegates: 44% from banks, 3% from regulators. | Banks and lenders | [CRC, undated, accessed 7 Nov 2026](https://crc.business-school.ed.ac.uk/conferences/highlights) |
| RSS International Conference 2027 | 6–9 Sep 2027, ICC Wales, Newport | Statistics community, credibility | [RSS, 13 Oct 2025](https://rss.org.uk/news-publication/news-publications/2025/general-news/icc-wales-to-host-the-rss-2027-international-confe/) |
| JSM 2027 | Chicago, 8–12 Aug 2027 per ASA; 7–12 Aug per Wikipedia | Statistics; A/B testing | [ASA Community, 17 Aug 2026](https://community.amstat.org/cnsl/discussion/call-for-invited-session-proposals-for-2027-jsm-due-september-23); [Wikipedia](https://en.wikipedia.org/wiki/Joint_Statistical_Meetings) |
| Risk Live Europe 2027 | 22–24 Jun 2027, London | Banks (CROs, model risk) | [Risk.net events, accessed 7 Nov 2026](https://www.risk.net/events) |
| Money20/20 Europe 2027 | 8–10 Jun 2027, RAI Amsterdam. The 2026 edition had 7,500+ attendees. | Fintech lenders | [Business Wire, 8 Jun 2026](https://www.businesswire.com/news/home/20260608803824/en/Money2020-Europe-Celebrates-Ten-Years-of-Industry-Leadership-as-AI-Digital-Assets-and-Financial-Sovereignty-Take-Centre-Stage) |
| RiskMinds International | 2026 edition 16–19 Nov 2026, London; 2027 dates not published | Banks | [FinTech Futures, accessed 7 Nov 2026](https://www.fintechfutures.com/events/riskminds-international) |
| Bio-IT World 2027 | 18–20 May 2027, Boston (secondary listing citing the organiser, CHI) | Drug discovery and AI for science | [beri.net, 17 Sep 2026](https://www.beri.net/events/bio-it-world-2027) |
| ICML 2027 | Rio de Janeiro; dates TBA. Projected paper deadline about 22 Jan 2027 (an estimate). | AI for science, agents | [ICML](https://icml.cc/Conferences/FutureMeetings); [OpenCurious, 30 Oct 2026](https://www.opencurious.com/ai-conference-deadlines/icml-2027) |
| NeurIPS 2026 / 2027 | 2026: 6–12 Dec 2026, Sydney, with satellites in Atlanta and Paris on 9–13 Dec. 2027: Europe, city TBA. | AI for science, agents | [NeurIPS](https://neurips.cc/Conferences/FutureMeetings); [OpenCurious, 30 Oct 2026](https://www.opencurious.com/ai-conference-deadlines/neurips-2027) |
| PyData London | 2026 edition 5–7 Jun 2026, Convene Sancroft; 2027 not announced (**UNVERIFIED**) | Python and data-science developers (open-source core) | [G-Research, 2026](https://www.gresearch.com/events/pydata-2026/) |
| CODE@MIT 2026 | 13–14 Nov 2026, MIT. Programme includes "Randomizing the Guardrail: …Runtime Governance of AI Agents" and Netflix and Amazon papers on agentic experimentation. 2027 not announced. | Product analytics | [MIT IDE, accessed 7 Nov 2026](https://ide.mit.edu/events/2026-conference-on-digital-experimentation-mit-codemit/) |
| Model Risk Management for Financial Institutions (GFMI / marcus evans) | 11th edition 4–6 Nov 2026, Warsaw; 2027 not announced | Banks (model validators) | [FF News, accessed 7 Nov 2026](https://ffnews.com/events/11th-edition-model-risk-management-for-financial-institutions-2026) |

**Communities, programmes and newsletters**
- **FCA AI Lab.** AI Spotlight is open for applications, and the AI Live Testing evaluation report is due in Q1 2027 ([FCA AI Lab, 3 Jul 2026](https://www.fca.org.uk/firms/ai-lab)).
- **Model Risk Managers' International Association (MRMIA).** Risk.net reported that it "has already drawn 1,800" members (text truncated) ([Risk.net, 19 Oct 2018](https://www.risk.net/risk-management/6008561/finally-a-professional-group-for-model-risk-managers)). MRMIA co-ran a "Fundamentals of Model Risk" day with Edinburgh's Credit Research Centre, with a PRA speaker ([CRC, 20 Feb 2026](https://crc.business-school.ed.ac.uk/news/crc-mrmia-unite-dedicated-day-model-risk)).
- **MCP server directories.** Glama lists GrowthBook's MCP server and is a discovery channel for an open-source MCP server ([Glama, accessed 7 Nov 2026](https://glama.ai/mcp/servers/growthbook/growthbook-mcp)).
- **Experimentation audience.** Lenny's Newsletter published Ronny Kohavi's A/B-testing guide ([Lenny's Newsletter, 27 Jul 2023](https://www.lennysnewsletter.com/p/the-ultimate-guide-to-ab-testing)); its subscriber numbers are **UNVERIFIED**. Kevin Anderson's "Experimental Mind" Substack and a Kohavi course on the "A/B Testing Replication Crisis" on Maven appeared only in search listings, so their reach is **UNVERIFIED**.
- **AI-for-science authors.** Agents4Science (Stanford) is where AI-scientist authors gather ([Science News, 24 Oct 2025](https://www.sciencenews.org/article/science-conference-test-ai-agents)). A 2026 or 2027 edition is **UNVERIFIED**.

*Assessment.* The Credit Scoring and Credit Control Conference (31 Aug–3 Sep 2027; venue not yet stated, past editions in Edinburgh) is the best-matched bank channel: it is probably local, mixes academics and practitioners, and 44% of attendees are from banks. It also suits a founder who is both a CRO and an Edinburgh PhD student. The RSS and JSM conferences, a week or two either side, give the statistics community and its credibility. For the AI-for-science beachhead the levers are ICML 2027 workshops (deadlines from January) and Bio-IT World in May.

---

## 7. Name check: "Buachaille"

- **Meaning.** In Scottish Gaelic, *buachaille* means "herder, herdsman, cowherd, shepherd" and also "a youth or young man". *Buachailleachd* means "herding, watching over cattle, or invigilating an exam". The Irish *buachaill* means "boy" or "young unmarried man" ([Omniglot Celtiadur, undated](https://www.omniglot.com/celtiadur/2019/03/25/cowherd-boy-child/)). Buachaille Etive Mòr means "great herdsman of Etive" ([Wikipedia, accessed 7 Nov 2026](https://en.wikipedia.org/wiki/Buachaille_Etive_M%C3%B2r)). Its summits appear under Walkhighlands' Munros section ([Walkhighlands URL path; page not read](https://www.walkhighlands.co.uk/munros/stob-dearg-buachaille-etive-mor.php)), which fits the Nibheis practice of Munro names for major frameworks.
- **PyPI.** These names are unregistered (HTTP 404 from the PyPI JSON API on 7 Nov 2026, with `numpy` returning 200 as a control): `buachaille`, `buachaille-ai`, `pybuachaille`, `buachaille-etive`, `buachaille-etive-mor`, `buachail`. `nibheis` is also unregistered on PyPI.
- **npm and crates.io.** `buachaille` returns 404 on npm (control `react` returns 200) and on crates.io. The RubyGems check was inconclusive.
- **GitHub.** A personal account named `buachaille` exists, with a profile-configuration repository last pushed on 18 Jun 2026 and a "helloworld" repository from 13 Apr 2025 (GitHub search API, 7 Nov 2026). The exact handle is therefore not available as an organisation name unless that user releases it. No users exist for `buachaille-ai`, `buachailleai` or `buachaille-dev`. Users `nibheis` and `nibheis-john` exist; I could not verify who owns them.
- **Companies House.** BUACHAILLE HOLDINGS LIMITED (company number 10524719) exists. Its listed director is Steven James Howarth, with a correspondence address in Kirkby Stephen, Cumbria ([Companies House officers page, accessed 7 Nov 2026](https://pay.company-information.service.gov.uk/company/10524719/officers)). Its status and line of business are **UNVERIFIED**; the full register search was blocked.
- **Trade marks.**
  - No "BUACHAILLE" mark surfaced in web-indexed USPTO aggregators.
  - A near-identical US mark, **"BUACHAILL"** (serial 88591298, registration 6018073), is owned by Shenzhen Wanshunma Intelligent Technology Co., Ltd. It is in class 9 for earphones, VR-headset accessories, adapters and phone cases, filed 23 Aug 2019 and registered 24 Mar 2020 ([Markinton, accessed 7 Nov 2026](https://markinton.com/trademark/buachaill-88591298)).
  - The page shows the mark as "Live", but its history includes "Terminated After Sanctions" on 6 Aug 2025, which conflicts. Check the status in USPTO TSDR.
  - Direct searches of the UK IPO, EUIPO TMview and WIPO Brand Database were blocked: **UNVERIFIED**.
- **Web presence and domains.** Web searches for "Buachaille" with software, app or company terms returned only mountain, hiking and photography pages. No software company or product was found. The availability of `buachaille.com`, `.ai`, `.io` and `.co.uk` is **UNVERIFIED**, because DNS and RDAP lookups do not work from this environment.

*Assessment.*
- The software namespace is clear where it matters for an open-source Python and MCP launch (PyPI). The *buachailleachd* sense of "invigilating an exam" is a strong brand story for a statistical referee.
- Three conflicts need resolving before brand spend. First, the GitHub handle: use `nibheis/buachaille` or a variant such as `buachaille-ai`. Second, the US class 9 "BUACHAILL" registration: downloadable software is also class 9, though the goods differ and the mark's status is in question. Third, the unrelated UK holding company. Commission a professional clearance search in classes 9 and 42 in the UK, EU and US.
- In my judgement the spelling and pronunciation will cost some recall with US buyers. The Irish meaning "boy" is a minor connotation risk.

---

## Top 15 facts for marketing copy

1. Only 19% of IT application leaders have high or complete trust in their vendor's hallucination protection. Source: [Gartner, 30 Sep 2025](https://www.gartner.com/en/newsroom/press-releases/2025-09-30-gartner-survey-finds-just-15-percent-of-it-application-leaders-are-considering-piloting-or-deploying-fully-autonomous-ai-agents).
2. Only 19% of senior data leaders at companies with US$1bn+ revenue are very confident in AI-generated analysis; 35% have little or no confidence. Source: [WisdomAI survey via GovInfoSecurity, 21 Aug 2026](https://www.govinfosecurity.com/ai-analytics-hits-trust-barrier-a-32632).
3. 53% of data and analytics leaders prioritise audit trails for AI-generated answers, and 31% say they cannot verify AI results. Source: [insightsoftware, 10 Jun 2026](https://www.insightsoftware.com/blog/why-dont-data-leaders-trust-ai-and-other-insights-from-our-2026-ai-survey/).
4. Inaccuracy is the most commonly cited negative consequence of enterprise AI use. Source: [McKinsey State of AI 2025, via IT Brief UK, 11 Nov 2025](https://itbrief.co.uk/story/mckinsey-report-shows-ai-interest-but-slow-scaling).
5. The makers of the Kosmos AI scientist say it "often goes down rabbit holes or chases statistically significant yet scientifically irrelevant findings". Source: [Edison Scientific, 5 Nov 2025](https://edisonscientific.com/news/announcing-kosmos).
6. The authors of Sakana's AI Scientist write in *Nature* that its problems "would prevent us from reliably trusting the outputs of systems like The AI Scientist". Source: [Nature, 25 Mar 2026](https://www.nature.com/articles/s41586-026-10265-5).
7. Given opposing priors, AI analysis agents reached opposing conclusions from the same data, and 86% of their reports still passed AI methodological review. Source: [Miao, Pritchard & Zou, Stanford, 1 Jul 2026](https://www.alphaxiv.org/abs/2607.01507).
8. AI agents "frequently make subtle inferential errors that lead to incorrect conclusions" even when their code runs correctly. Source: [Miao et al., 11 Aug 2026](https://huggingface.co/papers/2608.07437).
9. When 10% of experiments truly succeed, 22% of statistically significant "wins" are false positives; at Airbnb Search's 8% success rate the figure is 26.4%. Source: [Kohavi, Deng & Vermeer, KDD 2022](https://airbnb.tech/wp-content/uploads/sites/19/2025/10/ABTestingIntuitionBusters.pdf).
10. Amgen could confirm only 6 of 53 landmark preclinical cancer findings. Source: [Begley & Ellis, Nature, 29 Mar 2012, via MedicalXpress](https://medicalxpress.com/news/2012-03-duo-preclinical-cancer-results-plain.html).
11. An estimated US$28bn a year is spent on irreproducible preclinical research in the US alone. Source: [Freedman et al., PLOS Biology, Jun 2015, via Newswise](https://www.newswise.com/articles/new-study-on-research-reproducibility-proposes-fixes-for-28-billion-problem).
12. Phase II costs about US$40m per drug candidate, and only 28.9% of Phase II programmes reach Phase III. Sources: [Paul et al., Nat Rev Drug Discov, 2010](https://doi.org/10.1038/nrd3078); [BIO / Informa / QLS, Feb 2021](https://www.cphi-online.com/46/resourcefile/11/36/30/2021%20Clinical%20Development%20Success%20Rates%202011-2020%20v17.pdf).
13. The PRA expects that "The validation function should operate independently from the model development process and from model owners" (SS1/23, 4.1(d)). Source: [PRA Rulebook, SS1/23, effective 17 May 2024](https://prarulebook.co.uk/guidance/supervisory-statements/ss01-23--model-risk-management-principles-for-banks/4---model-risk-management-principles-for--banks/17-05-2024).
14. US banking regulators' April 2026 model risk guidance states that generative and agentic AI models "are not within the scope of this guidance". Source: [OCC Bulletin 2026-13 / SR 26-2, 17 Apr 2026](https://www.occ.gov/news-issuances/bulletins/2026/bulletin-2026-13.html).
15. The EU AI Act requires high-risk AI systems to "technically allow for the automatic recording of events (logs) over the lifetime of the system" (Article 12(1)), with Annex III obligations applying from 2 December 2027. Sources: [AI Act Service Desk](https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-12); [Cuatrecasas on Regulation (EU) 2026/1744, Jul 2026](https://www.cuatrecasas.com/en/spain/intellectual-property/art/digital-omnibus-ai-has-been-published).

---

## Appendix: derived calculations (computed in Python on 7 Nov 2026)

- **False-positive risk** = α(1−p) / (α(1−p) + power·p), with α = 0.025 and power = 0.8. For success rates p of 1/3, 20%, 15%, 10% and 8% this gives 5.9%, 11.1%, 15.0%, 22.0% and 26.4%. These match Kohavi, Deng & Vermeer (2022), Table 2.
- **Monitaur annualisation:** 500,000 / 3 = 166,666.67; 100,000 / 3 = 33,333.33 (US$ a year).
- **Kosmos:** 100 − 79.4 = 20.6% of conclusions not rated accurate.
- **Amgen:** 6 / 53 = 11.3%.
- **Statsig** at 10m events a month: 150 + (10 − 5) × 50 = US$400 a month.
- **GrowthBook Pro**, 10 seats: 40 × 10 × 12 = US$4,800 a year.
- **Paul et al.**, out-of-pocket cost per candidate from hit-to-lead through Phase II: 2.5 + 10 + 5 + 15 + 40 = US$72.5m.
- **Snowflake Intelligence** weekly-active accounts as a share of customers: 2,500 / 13,300 = 18.8%, an upper bound because both figures are approximate in that direction.
- **Gartner AI governance spending**, 2026 to 2030: more than 1,000 / 492 = more than 2.03 times.
- **Days from 7 Nov 2026** to 2 Dec 2027: 390. To 2 Aug 2028: 634.
- **BIRD text-to-SQL gap:** 92.96 − 80.04 = 12.92 percentage points.
