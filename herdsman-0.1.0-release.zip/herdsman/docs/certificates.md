# Certificates

A certificate is a JSON document signed with the referee's Ed25519 key. It is issued the moment a claim's accumulated evidence reaches the level fixed when the claim was committed. Verify one with `herdsman verify-certificate FILE --public-key HEX`, or in Python with `herdsman.verify_document(doc, public_key_hex)`.

| Field | Meaning |
|---|---|
| `format` | `herdsman-certificate/v1` |
| `study.study_id`, `study.title` | The study the claim belongs to |
| `study.params_hash` | SHA-256 of the study's parameters (schema, budget, evidence settings, vault commitments) |
| `study.alpha`, `study.gamma` | The false discovery rate and the budget shape |
| `study.vault_commitment` | Hash of the published fold commitments; released folds can be checked against it |
| `study.seed_commitment` | Salted hash of the seed behind every e-value; the seed is revealed when the study closes |
| `claim_id`, `statement`, `members`, `claim_key` | The claim as committed (several members for a family claim) |
| `commit.t`, `commit.episode`, `commit.actor`, `commit.committed_at` | When and by whom the claim was committed, and its position in the commit order |
| `commit.ledger_seq`, `commit.ledger_hash` | The commit record's position and hash in the ledger |
| `commit.alpha_t`, `commit.gamma_t`, `commit.certified_before`, `commit.threshold_e` | The level fixed at commit and the evidence it implies |
| `evidence.trajectory` | Per fold: the fold's e-value, the running total, group sizes and estimates |
| `evidence.log_e`, `evidence.log10_e`, `evidence.certified_fold` | Final evidence and the fold at which the bar was reached |
| `disclosure` | Exploratory tests logged before the commit, tests in the claim's own family, claims committed before it |
| `ledger_head_at_issue` | Ledger length and head hash when the certificate was issued |
| `issued_at` | Issue time |
| `guarantee` | The guarantee in words |
| `signature` | Algorithm, public key, key fingerprint and base64 signature over the canonical JSON of everything above |

Canonical JSON means keys sorted, no whitespace, UTF-8 and no non-finite numbers, so the signed bytes are reproducible on any machine.

## What a certificate does and does not say

It says that the claim, exactly as written, was certified under online e-LOND at the stated level: across every claim committed in the study, the expected share of certified claims that are false is at most alpha, provided the sealed folds are independent random samples from the study population. It does not say the claim is causal, that its effect is large unless a margin was claimed, or that it will hold if the population changes.


## Format names

New documents carry the format names `herdsman-study/v1`, `herdsman-certificate/v1` and `herdsman-checkpoint/v1`. Documents issued before the product was renamed, including those from the Northfell case study, carry the same formats under the working name `buachaille-…/v1`. Verification does not depend on the format name: a document verifies if its Ed25519 signature over the canonical JSON is valid under the referee's public key.
