"""Builds and executes notebooks/02_experiments.ipynb: reproduces the paper's simulation results."""
from pathlib import Path

from nbbuild import STYLE, build

HERE = Path(__file__).resolve().parent

cells = [
    ("md", """
# Simulation experiments: validity, power and holdout re-use

This notebook reproduces the simulation results in *Refereeing the Robot Analyst*. The full experiments ran from the scripts in `experiments/` (`run_validity.py`, `run_leakage.py`, `run_power.py`, `run_efficiency.py`, `run_overhead.py`); their outputs live in `results/`. Section 1 shows that the scripts are deterministic by re-running a few studies live and checking them against the stored raw results. The remaining sections load the stored results and draw every table and figure.

Every number shown is computed by code from those files.
"""),
    ("code", STYLE + """
import sys, math
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
ROOT = Path.cwd().parent
sys.path.insert(0, str(ROOT / "experiments"))
import simlib as S, run_validity as RV, run_leakage as RL
RES = ROOT / "results"
read = lambda name: pd.read_csv(RES / name, keep_default_na=False, na_values=[""])
pd.set_option("display.width", 160)
"""),
    ("md", """
## 1. Determinism check

Each study is generated from a seed derived from the experiment seed, the world and the replicate number, so any row of the raw results can be regenerated exactly. We re-run three studies of the validity experiment and two of the re-use attack and compare.
"""),
    ("code", """
raw = read("validity_raw.csv")
checks = []
for world, rep in [("null", 0), ("sparse", 7), ("dense", 3)]:
    live = pd.DataFrame(RV.one_rep((world, rep, 20261107)))
    stored = raw[(raw.world == RV.LABEL[world]) & (raw.rep == rep)]
    merged = live.merge(stored, on=["world", "rep", "agent", "method"], suffixes=("_live", "_stored"))
    checks.append(bool((merged.R_live == merged.R_stored).all() and (merged.V_live == merged.V_stored).all()))
leak = read("leakage_raw.csv")
for rep in (0, 1):
    live = pd.DataFrame(RL.one_rep((rep, 20261108)))
    stored = leak[leak.rep == rep].reset_index(drop=True)
    checks.append(bool((live.certified.values == stored.certified.astype(bool).values).all()))
print("all regenerated studies match the stored results:", all(checks), checks)
"""),
    ("md", """
## 2. False discovery rate across worlds, analysts and methods

Table 1 of the paper. In the global null every claim is false, so the false discovery rate is the probability of certifying anything at all.
"""),
    ("code", """
s = read("validity_summary.csv")
order = ["naive_report", "holdout_p05", "explore_bh", "holdout_bh", "holdout_bonferroni", "holdout_by", "single_seal_ebh", "herdsman", "herdsman_flat_prior"]
null = s[s.world == "global_null"].pivot(index="method", columns="agent", values="FDR").reindex(order)
null = null[["diligent", "forking", "pressured", "adaptive_3_episodes"]]
(100 * null).round(1).rename_axis("FDR (%) in the global null")
"""),
    ("code", """
sparse = s[(s.world == "sparse") & (s.agent == "forking")].set_index("method").reindex(order)
sparse[["FDR", "mean_true", "mean_false", "share_true_claims_certified"]].round(3)
"""),
    ("code", """
fig, axes = plt.subplots(1, 2, figsize=(10, 3.4), sharey=True)
for ax, world in zip(axes, ["global_null", "sparse"]):
    part = s[(s.world == world) & (s.agent == "forking")].set_index("method").reindex(order[:-1])
    y = np.arange(len(part))[::-1]
    colours = [TEAL if m == "herdsman" else (AMBER if m in ("naive_report", "holdout_p05") else SLATE) for m in part.index]
    ax.barh(y, part.FDR, xerr=1.96 * part.FDR_se, color=colours)
    ax.axvline(0.1, color=NAVY, ls="--", lw=1)
    ax.set_yticks(y); ax.set_yticklabels(part.index); ax.set_title(world); ax.set_xlabel("false discovery rate")
plt.tight_layout(); plt.show()
"""),
    ("md", """
## 3. The holdout re-use attack

Two hundred noise features, an outcome independent of all of them, and an analyst that builds a composite score from what the referee releases. The composite claim is false by construction.
"""),
    ("code", """
read("leakage_summary.csv").round(4)
"""),
    ("md", """
## 4. Allocation, budget shape and episodes
"""),
    ("code", """
p = read("power_summary.csv")
alloc = p[p.part == "A"].pivot_table(index=["world", "setting"], columns="method", values="share_true_claims_certified")
alloc.round(3)
"""),
    ("code", """
p[p.part == "B"].pivot_table(index="setting", columns="world", values="mean_true").round(2)
"""),
    ("code", """
p[p.part.isin(["B", "C"])].groupby("part")[["FDR"]].max().rename(columns={"FDR": "largest FDR in any setting"})
"""),
    ("code", """
p[p.part == "C"].pivot_table(index="setting", columns="world", values="mean_true").round(2)
"""),
    ("md", """
## 5. How close the e-values come to the oracle

For two-group binary outcomes, the mean log betting e-value compared with the mean of $z^2/2$, the log of the oracle Gaussian likelihood ratio at the true effect, with and without starting bets from an independent exploration sample. The second table shows the z needed to clear the levels the rolling seal uses, by a one-sided z-test and by an e-value with the measured gap.
"""),
    ("code", """
display(read("efficiency.csv").round(3))
display(read("levels.csv").round(3))
"""),
    ("md", """
## 6. Overhead
"""),
    ("code", """
read("overhead.csv").assign(milliseconds=lambda d: (1000 * d.seconds).round(2))
"""),
]

if __name__ == "__main__":
    print("written", build(HERE / "02_experiments.ipynb", cells, timeout=3600))
