"""Tiny helper: build a notebook from (kind, source) cells and execute it in place."""
from __future__ import annotations

import sys
from pathlib import Path

import nbformat
from nbconvert.preprocessors import ExecutePreprocessor


def build(path: str | Path, cells: list[tuple[str, str]], timeout: int = 1800, execute: bool = True) -> Path:
    nb = nbformat.v4.new_notebook()
    nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
    nb.metadata["language_info"] = {"name": "python"}
    for kind, source in cells:
        source = source.strip("\n")
        nb.cells.append(nbformat.v4.new_markdown_cell(source) if kind == "md" else nbformat.v4.new_code_cell(source))
    path = Path(path)
    if execute:
        ExecutePreprocessor(timeout=timeout, kernel_name="python3").preprocess(nb, {"metadata": {"path": str(path.parent)}})
    nbformat.write(nb, path)
    return path


STYLE = r'''
import matplotlib as mpl
NAVY, TEAL, AMBER, SLATE, SAND = "#0B2545", "#1F8A8A", "#E09F3E", "#5B6B7F", "#D9D4C7"
mpl.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 200, "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "axes.edgecolor": SLATE, "axes.labelcolor": NAVY, "xtick.color": SLATE, "ytick.color": SLATE,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#ECE8DF",
    "grid.linewidth": 0.8, "axes.prop_cycle": mpl.cycler(color=[TEAL, AMBER, NAVY, SLATE, "#8FB8B8", "#C9A26B"]),
    "legend.frameon": False,
})
'''

if __name__ == "__main__":  # pragma: no cover
    print("import and call build()", file=sys.stderr)
