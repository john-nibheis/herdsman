"""Builds and executes notebooks/03_quickstart.ipynb."""
from pathlib import Path

from nbbuild import STYLE, build

HERE = Path(__file__).resolve().parent

cells = [
    ("md", """
# Herdsman quickstart: from first test to signed certificate

This notebook walks one analysis through the referee: a study is created and sealed, an analyst explores and commits claims, the referee opens sealed folds one episode at a time, and the claims that survive receive signed certificates that anyone can verify.

The data are synthetic with a known answer, so we can check the referee's decisions against the truth at the end. Everything runs offline; `DEMO_MODE` is on, so no language model is called.
"""),
    ("code", STYLE + """
import json, math, tempfile, shutil
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
import herdsman as bu
from herdsman import Referee, RefereeError, verify_document
from herdsman.canonical import FixedClock
pd.set_option("display.width", 160); pd.set_option("display.max_colwidth", 80)
print("herdsman", bu.__version__, "| demo mode:", bu.demo_mode())
"""),
    ("md", """
## 1. An experiment with a known answer

An online retailer tests a new checkout (B) against the current one (A) on 30,000 customers. By construction, B lifts conversion by six points for **new** customers and does nothing for anyone else, and it has no effect on basket value.
"""),
    ("code", """
rng = np.random.default_rng(2026)
n = 30_000
data = pd.DataFrame({
    "variant": rng.choice(["A", "B"], n),
    "tenure": rng.choice(["new", "established", "loyal"], n, p=[0.3, 0.5, 0.2]),
    "device": rng.choice(["mobile", "desktop"], n),
    "region": rng.choice(["north", "south", "east", "west"], n),
    "plan": rng.choice(["basic", "plus", "pro"], n, p=[0.6, 0.3, 0.1]),
})
lift = 0.06 * ((data.variant == "B") & (data.tenure == "new"))
data["converted"] = rng.binomial(1, 0.20 + lift)
data["basket_value"] = np.clip(rng.gamma(4, 20, n) + 25 * (data.plan == "pro"), 0, 500).round(2)
data.groupby(["tenure", "variant"]).converted.mean().unstack().round(3)
"""),
    ("md", """
## 2. The data owner creates a study

`Referee.create` shuffles the rows with a seeded generator and keeps 40% open for exploration. The other 60% is split into three folds, each encrypted with a key that is written to a separate keys directory. The SHA-256 of every fold and of the seed is published in `study.json` before anyone looks at the data, so the referee cannot quietly swap a fold or re-draw the randomness later.

The error budget is a false discovery rate of 10% spread evenly over ten claim slots.
"""),
    ("code", """
work = Path(tempfile.mkdtemp(prefix="herdsman-quickstart-"))
referee = Referee.create(
    work / "study", work / "keys", data,
    outcomes=["converted", "basket_value"], bounds={"basket_value": (0, 500)},
    alpha=0.10, horizon=10, n_folds=3, exploration_fraction=0.4, seed=11,
    title="Checkout B experiment", question="Did checkout B work, and for whom?",
    clock=FixedClock("2026-11-07T09:00:00Z"),
)
params = referee.params
print("study", params["study_id"], "| referee key", params["referee_key_fingerprint"])
print("fold commitments:", [f["sha256"][:12] for f in params["vault"]["commitments"]["folds"]])
print("seed commitment:", params["seed_commitment"][:24], "...")
referee.budget()
"""),
    ("md", """
## 3. The analyst's view

The analyst (a person or an agent) opens the study **without** the keys. It can read the exploration data, run logged tests and commit claims. It cannot open a sealed fold.
"""),
    ("code", """
analyst = Referee(work / "study", clock=FixedClock("2026-11-07T10:00:00Z"))
brief = analyst.brief()
print(brief["title"], "|", brief["exploration_rows"], "exploration rows |", "outcomes:", brief["outcomes"])
for rule in brief["rules"]:
    print("-", rule)
"""),
    ("md", """
## 4. Explore: a small forking-paths search

The analyst tests the effect of B on both outcomes, overall and in every single-attribute subgroup, plus every tenure-by-device cell: 38 tests. Each one is written to the ledger.
"""),
    ("code", """
specs = []
groups = [("", "everyone")] + [(f"{c} == '{v}'", f"{c}={v}") for c in ["tenure", "device", "region", "plan"] for v in sorted(data[c].unique())]
groups += [(f"tenure == '{t}' and device == '{d}'", f"{t}+{d}") for t in ["new", "established", "loyal"] for d in ["mobile", "desktop"]]
rows = []
for outcome in ["converted", "basket_value"]:
    for population, label in groups:
        spec = {"outcome": outcome, "population": population, "focal": "variant == 'B'", "reference": "variant == 'A'"}
        r = analyst.explore_test(spec)
        rows.append({"outcome": outcome, "subgroup": label, "estimate": r["estimate"], "z": r["z"], "p": r["p_two_sided"], "population": population})
search = pd.DataFrame(rows).sort_values("p")
print(len(search), "tests;", (search.p < 0.05).sum(), "significant at 5%")
search.head(8).round(4)
"""),
    ("code", """
d = analyst.disclosure()
print(f"{d['tests']} tests in {d['families']} families; {d['significant_at_alpha']} significant at 5% "
      f"against {d['expected_significant_if_all_null']:.1f} expected if nothing were real; {d['bh_survivors']} survive BH at 10%.")
pd.DataFrame(d["family_table"])[["family", "tests", "significant_at_alpha", "min_p", "bonferroni_min_p"]]
"""),
    ("md", """
## 5. Commit claims

The analyst commits the five most significant results, in the direction it observed. The level each claim needs is fixed now, by e-LOND: with ten slots and α = 10%, the first claim must reach an e-value of 100. Each certification lowers the bar for claims committed afterwards.
"""),
    ("code", """
for _, row in search.head(5).iterrows():
    direction = "increase" if row.estimate > 0 else "decrease"
    analyst.commit_claim({
        "statement": f"Checkout B {'raises' if direction == 'increase' else 'lowers'} {row.outcome} ({row.subgroup})",
        "outcome": row.outcome, "population": row.population,
        "focal": "variant == 'B'", "reference": "variant == 'A'", "direction": direction,
    })
pd.DataFrame(analyst.claims())[["id", "statement", "alpha_t", "threshold_e", "status"]]
"""),
    ("code", """
try:
    analyst.close_episode()
except RefereeError as err:
    print("Analyst handle refused:", err)
"""),
    ("md", """
## 6. The referee closes episode 1

One sealed fold is opened. Every open claim gets that fold's e-value, which multiplies into its running evidence. Then the fold is released into the exploration pool: it is spent, because no claim committed from now on will be tested on it.
"""),
    ("code", """
episode1 = referee.close_episode()
print("fold", episode1["fold"], "opened; certified now:", [c["id"] for c in episode1["certified"]])
pd.DataFrame(referee.claims())[["id", "statement", "status", "log10_e", "threshold_e"]].round(2)
"""),
    ("md", """
## 7. Episode 2: more data for the analyst, fresh data for the referee

The analyst now explores 40% + 20% of the rows. It commits one more, refined claim. That claim will only ever be tested on folds 2 and 3, which it has not seen. The earlier claims that are still open keep accumulating evidence.
"""),
    ("code", """
print("exploration rows now:", len(analyst.exploration_data()))
for population, words in [("tenure == 'new' and device == 'mobile'", "new mobile customers"),
                          ("tenure == 'new' and plan == 'basic'", "new customers on the basic plan")]:
    try:
        analyst.commit_claim({"statement": f"Checkout B raises conversion for {words}", "outcome": "converted",
                              "population": population, "focal": "variant == 'B'", "reference": "variant == 'A'"})
        print("committed:", words)
        break
    except RefereeError as err:
        print("skipped:", err)
final = referee.close_study()
claims = pd.DataFrame(referee.claims())
claims[["id", "statement", "episode", "status", "log10_e", "threshold_e", "certified_fold"]].round(2)
"""),
    ("md", """
## 8. Checking against the truth

B helps new customers only. A claim is about the *average* effect in its population, so "B raises conversion among mobile customers" is true, if diluted: about 30% of mobile customers are new, so the average lift there is roughly 0.3 × 6 = 1.8 points. A claim is false if it concerns basket value, says B *lowers* conversion, or describes a population with no new customers. Certificates speak to the claim as written; they do not say which customers drive an effect.
"""),
    ("code", """
def true_lift(member):
    # true average effect of B in the claim's population, from the generator rather than the data
    if member["outcome"] != "converted":
        return 0.0
    population = data if not member["population"] else data.query(member["population"])
    return 0.06 * (population.tenure == "new").mean()

def truly_true(row):
    member = row["members"][0]
    lift = true_lift(member)
    return lift > 0 if member["direction"] == "increase" else lift < 0
claims["true_lift"] = claims["members"].apply(lambda m: round(true_lift(m[0]), 4))
claims["true"] = claims.apply(truly_true, axis=1)
print(claims[["id", "statement", "true_lift", "status"]].to_string(index=False))
print(pd.crosstab(claims["true"], claims["status"]))
"""),
    ("md", """
## 9. Evidence paths

Each line is a claim's accumulated evidence (log10 of the e-value) as sealed folds are opened; the dashed line is the evidence it needed.
"""),
    ("code", """
fig, ax = plt.subplots(figsize=(7, 3.6))
for _, c in claims.iterrows():
    folds = [c["episode"] - 1] + [s["fold"] for s in c["trajectory"]]
    path = [0.0] + [s["log_e_cumulative"] / math.log(10) for s in c["trajectory"]]
    line, = ax.plot(folds, path, marker="o", lw=1.8, color=TEAL if c["status"] == "certified" else SLATE, alpha=0.9)
    ax.hlines(math.log10(c["threshold_e"]), folds[0], 3, colors=AMBER, linestyles="dashed", lw=0.8)
    ax.annotate(c["id"], (folds[-1], path[-1]), textcoords="offset points", xytext=(4, 0), fontsize=8, color=NAVY)
ax.set_xlabel("sealed folds opened"); ax.set_ylabel("log10 evidence"); ax.set_xticks([0, 1, 2, 3])
ax.set_title("Certified claims (teal) crossed their bar; the rest did not")
plt.tight_layout(); plt.show()
"""),
    ("md", """
## 10. Certificates and audit

A certificate is a signed JSON document. It records the claim, when it was committed and where in the ledger, the evidence it needed and the evidence it accumulated, how many exploratory tests came before it, and the guarantee. Anyone with the referee's public key can verify it, and anyone can recompute the ledger's hash chain.
"""),
    ("code", """
certified_ids = claims.loc[claims.status == "certified", "id"].tolist()
cert = referee.certificate(certified_ids[0])
summary = {k: cert[k] for k in ["claim_id", "statement", "commit", "disclosure", "guarantee"]}
print(json.dumps(summary, indent=2)[:1800])
print("signature:", verify_document(cert, referee.params["referee_public_key"]))
print("whole study:", {k: v for k, v in referee.verify().items() if k in ("ok", "checkpoint_ok")})
"""),
    ("code", """
# Tamper with a copy: make an early claim look as if it had needed less evidence.
copy = Path(tempfile.mkdtemp()) / "study"
shutil.copytree(work / "study", copy)
lines = (copy / "ledger.jsonl").read_text().splitlines()
for i, line in enumerate(lines):
    record = json.loads(line)
    if record["type"] == "commit":
        record["payload"]["alpha_t"] = 0.5
        lines[i] = json.dumps(record)
        break
(copy / "ledger.jsonl").write_text("\\n".join(lines) + "\\n")
print(Referee(copy).verify()["ledger"])
"""),
    ("md", """
## 11. Batch mode: one pre-registered confirmation

When a team can commit every claim up front and confirm once, batch mode opens a single sealed fold and tests the batch together with Benjamini–Yekutieli (valid under any dependence between claims). It has more power for that single round; rolling mode is the one that stays valid when the analyst comes back for more.
"""),
    ("code", """
batch = Referee.create(work / "batch", work / "batch-keys", data, outcomes=["converted", "basket_value"],
                       bounds={"basket_value": (0, 500)}, alpha=0.10, mode="batch", batch_procedure="by", seed=12)
for _, row in search.head(5).iterrows():
    batch.commit_claim({"statement": f"B {'raises' if row.estimate > 0 else 'lowers'} {row.outcome} ({row.subgroup})",
                        "outcome": row.outcome, "population": row.population, "focal": "variant == 'B'",
                        "reference": "variant == 'A'", "direction": "increase" if row.estimate > 0 else "decrease"})
result = batch.close_episode()
pd.DataFrame(batch.claims())[["id", "statement", "status"]]
"""),
    ("md", """
## 12. Connecting an agent

Agents talk to the referee over the Model Context Protocol. The server below exposes the analyst's tools only; the keys never leave the referee's operator.

```json
{"mcpServers": {"herdsman": {"command": "herdsman-mcp", "args": ["--study", "/data/studies/checkout-b"]}}}
```
"""),
    ("code", """
import asyncio
from herdsman.mcp_server import build_server
server = build_server(str(work / "study"))
for tool in await server.list_tools():
    print(f"{tool.name:22s} {tool.description.splitlines()[0]}")
"""),
    ("md", """
## What the guarantee means

Across every claim committed in a study, the expected share of certified claims that are false is at most α, whatever the analyst did before committing each claim, provided the sealed folds are independent random samples from the population. A certificate speaks to the statistical claim as written. It does not make an association causal, and it does not protect against a population that changes after the study.
"""),
]

if __name__ == "__main__":
    out = build(HERE / "03_quickstart.ipynb", cells)
    print("written", out)
