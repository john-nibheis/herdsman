"""Builds the go-to-market playbook (Word) with every figure filled from the results files.

The same functions that fill the paper compute the shared numbers, so the playbook and the
paper can never disagree. Case-study figures come from results/casestudy_numbers.json.
Usage: python build.py   (writes marketing/out/Herdsman_GTM_playbook.docx)
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "paper"))
import assemble as A  # noqa: E402


def values() -> dict[str, str]:
    for fn in (A.validity, A.leakage, A.power, A.efficiency, A.overhead):
        fn()
    o = A.load("overhead.csv")
    close = o[o.operation.str.startswith("close episode")].iloc[0]["seconds"]
    A.V["overhead_close_seconds"] = f"{close:.1f}"
    case = ROOT / "results" / "casestudy_numbers.json"
    if case.exists():
        A.V.update(json.loads(case.read_text())["values"])
    return A.V


def main() -> None:
    V = values()
    text = "\n\n".join((HERE / f"playbook_{i}.md").read_text() for i in (1, 2, 3))
    used = set(re.findall(r"\{\{([a-zA-Z0-9_]+)\}\}", text))
    missing = sorted(k for k in used if k not in V)
    if missing:
        sys.exit(f"missing values: {missing}")
    for key in used:
        text = text.replace("{{" + key + "}}", V[key])
    out = HERE / "out"
    out.mkdir(exist_ok=True)
    (out / "playbook.md").write_text(text)
    subprocess.run([sys.executable, str(HERE / "md2json.py"), str(out / "playbook.json"), str(out / "playbook.md")], check=True)
    subprocess.run(
        ["node", str(HERE / "render_docx.js"), str(out / "playbook.json"), str(out / "Herdsman_GTM_playbook.docx"),
         "Herdsman", "Go-to-market and marketing playbook", "Herdsman · Go-to-market playbook"],
        check=True,
    )
    print(f"filled {len(used)} values")


if __name__ == "__main__":
    main()
