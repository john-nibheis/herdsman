# Go-to-market plan

## Before launch (November–December 2026)

Resolve the two things that cannot be undone later. First, confirm with the University of Edinburgh how its intellectual-property policy treats work related to a student's research area; Herdsman's sequential-inference core is close to the PhD's subject, and the paper currently lists only the Nibheis affiliation. Second, commission trade-mark clearance for the name. Then publish the paper on arXiv and SSRN, release the code at `github.com/nibheis/herdsman` and on PyPI, list the MCP server in the main directories (Glama and the official registries), and publish the launch post. NeurIPS (6–12 December, Sydney, with satellites in Atlanta and Paris) is for conversations, not a booth.

## Design partners (January–March 2027)

Recruit six to ten design partners: two or three UK and European lenders through the founder's network, two AI-for-science teams, and two product-analytics teams already using MCP with an experimentation platform. Submit to an ICML 2027 workshop (deadlines from late January). Apply to the FCA AI Lab's AI Spotlight. Open the Cloud beta to design partners only.

## General availability (April–June 2027)

Launch Cloud Team and Business. Present at Bio-IT World (18–20 May, Boston) for the science beachhead, Money20/20 Europe (8–10 June, Amsterdam) for fintech lenders, and Risk Live Europe (22–24 June, London) for chief risk officers and model-risk teams. Publish the first two design-partner case studies.

## Credibility season (July–September 2027)

Release the Enterprise edition with the model-risk evidence pack. Submit talks to JSM (8–12 August, Chicago), the Credit Scoring and Credit Control Conference run by the University of Edinburgh's Credit Research Centre (31 August–3 September; 44% of its 2025 delegates were from banks), and the Royal Statistical Society International Conference (6–9 September, Newport). This run of three conferences in five weeks is the best-matched channel for the founder's profile.

## Scale decision (October–December 2027)

EU AI Act obligations for stand-alone high-risk systems begin on 2 December 2027; publish practical guidance on evidencing logging and accuracy for analytics that feed high-risk decisions. Decide, on the evidence of paid conversions, whether to raise a seed round, partner with a platform, or stay a focused, profitable tool.

# Metrics

Track one north-star metric, *certified claims per month* across all users, because it measures both adoption and the product doing its job. Around it, track open-source adoption (PyPI downloads, GitHub stars, MCP installs), activation (studies created that reach a first certification), public certificate verifications, design partners signed and converted, and annual recurring revenue. Targets for the first year, to be revisited after three months: 1,000 studies created on Core, 200 certificates verified publicly, eight design partners with five converting, and $250,000 of annual recurring revenue by December 2027.

# Risks

| Risk | Likelihood | What we do |
|---|---|---|
| A platform (Statsig/OpenAI, Eppo/Datadog, Databricks, Snowflake) ships a good-enough referee for its own agents | Medium | Be the independent referee across platforms; integrate behind their MCP tools; make the certificate format a standard; treat acquisition as a credible exit |
| Buyers hear "certifies fewer findings" as a cost | High | Lead with the null-world and re-use results; offer batch mode; show the false findings avoided in their own data |
| Name conflicts (GitHub handle, US class 9 mark, UK company) | Medium | Clearance search now; publish under `nibheis/herdsman`; fallback name *Herdsman* |
| Regulatory hooks weaker than hoped (SR 26-2 excludes agentic AI; EU obligations from December 2027; SS1/23 binds internal-model banks) | High | Sell on trust and cost of error; use regulation as a tailwind, not the reason |
| University IP claim over the core methods | Low to medium | Settle the position before publication; keep the PhD and Nibheis work clearly separated |
| Conflict with the founder's employment | Medium | Clean-room development; no employer data, customers or time; disclose the side venture as the employment contract requires |
| A security failure in the hosted vault | Low, severe | Hardware-backed keys, independent penetration testing, SOC 2 roadmap, customer-cloud option |
| Liability for a certified finding that later fails | Low | Terms that describe a certificate as a statistical statement with a stated error rate, not a warranty |

# Content pack

## Launch post

**Your AI analyst isn't lying. It's just trying too many things.**

Give an AI agent a dataset and a question, and within minutes it will hand you findings: a segment where the new journey worked, a feature that predicts default, a gene that responds to the drug. The effect sizes will be plausible and the p-values small. The code will usually be correct. What you will not see is the denominator: how many other subgroups, outcomes and specifications the agent tried before it chose these.

That denominator is the oldest problem in statistics, and AI has made it cheap to make worse. A human analyst who tries forty subgroups gets tired. An agent tries four hundred before lunch, and it never forgets to report the one that worked. Studies published this year found that frontier agents can be steered into specification search, that agents given different priors reach opposite conclusions from the same data, and that their misleading analyses still pass methodological review.

The usual safeguards do not survive agents. Pre-registration assumes the plan comes before the data, and an agent sees the data first. Multiple-testing corrections need the number of tests, which nobody reports. And a holdout set works exactly once: the moment someone looks at the holdout and comes back with a refined claim, the holdout has joined the training data. Agents always come back.

Herdsman is a referee for this world. It splits your data into an open exploration set and several sealed folds whose fingerprints are published before anyone looks. Your agent explores as much as it likes. When it believes a finding, it commits a precise claim, and Herdsman fixes there and then how much evidence the claim must reach. At the end of each round, Herdsman opens one sealed fold, once, and updates every open claim. Findings that reach their bar are certified with a signed certificate anyone can verify. The spent fold is handed back to the agent, so nothing is wasted, and the agent can keep iterating, because new claims are only ever tested on data it has not seen.

The result is a promise you can state precisely: across a study, the expected share of certified findings that are false is at most the level you choose. It holds however many things the agent tried and however it revised its claims, and the paper proves it.

We tested the promise hard. In simulated studies where nothing was real, unrefereed AI analyst reports contained false findings in {{null_naive_any_false}} of cases; Herdsman's false discovery rate never exceeded {{max_fdr_rolling}}. When a holdout was re-used, a claim built from pure noise was certified in {{leak_estimates_cert}} of studies; against Herdsman, in {{leak_rolling_cert}}. {{case_post_sentence}}

Rigour has a price, and we publish it: Herdsman certifies fewer findings than a single, pre-registered holdout would, because it stays valid when your agents come back for more. Every finding it declines is one you could not have defended.

The core is open source under Apache 2.0: a Python library, a command line and an MCP server any agent can call. A hosted referee and an enterprise edition with key custody and a model-risk evidence pack are available for design partners now.

## LinkedIn posts

*Post 1.* In our case study, one AI analyst ran {{case_tests_example}} distinct tests before writing a report of {{case_findings_example}} findings for its board, {{case_nulls_example}} of them null results. The p-values in the report describe those {{case_findings_example}} tests. Herdsman's ledger describes all of them, and then re-tests the claims on data the agent has never seen. Introducing Herdsman, a statistical referee for AI analysts.

*Post 2.* A holdout set works once. We built a claim out of pure noise and let a referee re-use its holdout: certified in {{leak_estimates_cert}} of studies. With rolling sealed folds, {{leak_rolling_cert}}. Agents come back for more; your confirmation data has to survive that.

*Post 3.* "Only 19% of senior data leaders are very confident in AI-generated analysis." The fix is not a better-sounding report. It is a referee that controls how many of the agent's findings are false, and shows its working.

*Post 4.* What does a certified finding look like? A signed JSON document: the claim, when it was committed, how much evidence it needed and got, how many tests came before it, and the guarantee. Anyone can verify it offline. We think every agent-generated finding that drives a decision should carry one.

*Post 5, for risk teams.* SS1/23 asks for independent, effective challenge. When the analyst is an AI agent, what does your second line challenge? A ledger of everything it tried, a quantified error rate, and certificates for what it was allowed to conclude.

## Outreach e-mails

**To a head of model risk.** Subject: Independent challenge for agent analytics. Your first-line teams are starting to use AI agents for analysis. When they bring you a finding, you see the result, not the three hundred specifications behind it. Herdsman is an independent referee that logs everything an agent tries, re-tests its claims on sealed data it has never seen, and signs certificates with a controlled false discovery rate. We are taking on a small number of design partners among UK lenders, at half price for the first year, with a model-risk evidence pack built with you. Would a 30-minute walk-through be useful? *Follow-up:* a short note with the re-use attack chart and a sample certificate.

**To a head of data science.** Subject: Making your agents' findings defensible. If your agents report segment-level wins, some of them are noise, and the statistics they show cannot tell you which. Herdsman sits between your agents and your data and certifies only findings that hold up on sealed data, with a provable cap on false ones. The core is open source and runs offline; there is an MCP server your agents can call today. Happy to share the paper and a ten-minute demo. *Follow-up:* the quickstart notebook.

**To an AI-for-science lead.** Subject: Which machine-generated leads have earned a lab experiment? AI scientists generate more leads than labs can test, and their makers warn they chase spurious correlations. Herdsman referees the agent's claims on sealed data and certifies only those that survive, with a controlled error rate across the whole programme. We are looking for two design partners to extend its evidence functions to your assay types. *Follow-up:* the null-world results and a sample certificate.

## Conference abstract

*Refereeing the robot analyst.* Autonomous AI analysts make specification search cheap. We present the rolling seal, a confirmation protocol in which an agent explores freely and commits claims, sealed folds are opened once per episode, each claim's betting e-value accumulates across folds, and spent folds are returned to the agent. Levels fixed at commit by e-LOND give false discovery control under arbitrary adaptivity and dependence. We describe an open-source referee with a hash-chained ledger, signed certificates and an MCP interface, and report simulations, a holdout re-use attack and a case study in which live AI analysts analysed a lending experiment with a known truth.

## Ten-minute demo script

Open the quickstart study and show the published fold fingerprints (one minute). Let an agent run a forking-paths search through the MCP tools and show the disclosure table: tests, families, how many were significant against how many would be expected by chance (two minutes). Commit five claims and show the evidence bar fixed for each (one minute). Close an episode; show the evidence paths and the first certification (two minutes). Show that the spent fold now belongs to the agent and that its new claims will be tested only on unseen folds (one minute). Verify a certificate offline, then tamper with one ledger record and show verification fail (two minutes). Close on the re-use chart and the offer (one minute).

## Frequently asked questions

*What exactly is guaranteed?* Across all claims committed in a study, the expected share of certified claims that are false is at most α (10% by default), provided the sealed folds are independent random samples from the population.

*Does my agent have to log everything?* No. The guarantee comes from sealing. Logging is for transparency.

*What kinds of claims can it certify?* Differences and levels of bounded outcomes (rates, amounts with known bounds) between groups defined by filters, including randomised-experiment effects and associations. Regression, survival and other evidence functions are on the roadmap.

*What does it cost in power?* At strict levels, e-values need stronger evidence than one-off p-value tests. In our sparse-effects simulations Herdsman certified {{sparse_share_rolling}} of true committed claims against {{sparse_share_bh}} for a single pre-registered holdout. Batch mode narrows the gap when you can confirm once.

*Can an LLM break the guarantee?* No. A model may propose how tests group into hypotheses, but everything it proposes is fixed before the relevant sealed data are opened, and the guarantee does not depend on it.

*Does it work with our agents?* Any agent that speaks the Model Context Protocol can use it; Python and command-line interfaces cover the rest.

*Where does our data go?* Nowhere, with Core. Enterprise runs in your environment with your keys.

*Is a certified finding causal?* Only if the design makes it so, as in a randomised experiment. The certificate certifies the statistical claim as written.
