"""Fills the pitch-deck slides and the site artboard with figures computed from the results files.

Deck templates use {{name}} and the site uses @@name@@ markers. Every figure comes from the
paper's assembly functions (shared numbers) or results/casestudy_numbers.json (case study).
Usage: python build_assets.py   (writes marketing/out/deck/project/... and marketing/out/site/project/...)
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import build as B  # noqa: E402

DECK_ORDER = [
    "cover", "agents-search", "trust", "null-studies", "reuse", "architecture", "rolling-seal",
    "guarantee", "power", "case-study", "certificate", "landscape", "beachheads", "pricing", "design-partners",
]
SECTIONS = {
    "s1": {"description": "The problem: agents search hard, buyers do not trust the results, and the usual fixes fail", "start": "agents-search"},
    "s2": {"description": "The product: how the referee works and what it guarantees", "start": "architecture"},
    "s3": {"description": "The evidence: the price in power and the live case study", "start": "power"},
    "s4": {"description": "The market and the offer", "start": "landscape"},
}
FACES = {
    "source-serif-4": {"family": "Source Serif 4", "href": "https://fonts.googleapis.com/css2?family=Source+Serif+4:wght@400..700&display=swap"},
    "ibm-plex-sans": {"family": "IBM Plex Sans", "href": "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;600&display=swap"},
    "ibm-plex-mono": {"family": "IBM Plex Mono", "href": "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&display=swap"},
}


def values() -> dict[str, str]:
    import pandas as pd

    V = dict(B.values())
    V["null_naive_range"] = V["null_naive_any_false"].replace("% to ", "–")
    s = pd.read_csv(ROOT / "results" / "validity_summary.csv", keep_default_na=False, na_values=[""])
    share = lambda w, m: f"{100 * s[(s.world == w) & (s.agent == 'forking') & (s.method == m)].iloc[0]['share_true_claims_certified']:.0f}%"
    V["sparse_share_by"], V["dense_share_by"] = share("sparse", "holdout_by"), share("dense", "holdout_by")
    case = ROOT / "results" / "casestudy_numbers.json"
    if case.exists():
        data = json.loads(case.read_text())
        V.update(data["values"])
        runs = data["runs"]
        V["case_runs_cap"] = {4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight"}.get(len(runs), str(len(runs)))
        right = ' style="text-align:right"'
        V["case_deck_rows7"] = "\n".join(
            f"<tr><td>{x['run']}</td><td>{x['label']}</td><td>{x['world_label']}</td><td{right}>{x['tests']:,}</td>"
            f"<td{right}>{x['findings']} ({x['findings_false']})</td><td{right}>{x['claims']}</td><td{right}>{x['certified']} ({x['certified_false']})</td></tr>"
            for x in runs)
    return V


def fill(text: str, V: dict, pattern: str) -> str:
    keys = set(re.findall(pattern, text))
    missing = sorted(k for k in keys if k not in V)
    if missing:
        raise SystemExit(f"missing values: {missing}")
    for k in keys:
        text = re.sub(pattern.replace(r"([a-zA-Z0-9_]+)", re.escape(k)), lambda _m, k=k: V[k], text)
    return text


def build_deck(V: dict) -> Path:
    out = HERE / "out" / "deck"
    slides = out / "project" / "slides"
    slides.mkdir(parents=True, exist_ok=True)
    present = []
    for sid in DECK_ORDER:
        src = HERE / "deck_src" / f"{sid}.html"
        if not src.exists():
            continue
        (slides / f"{sid}.html").write_text(fill(src.read_text(), V, r"\{\{([a-zA-Z0-9_]+)\}\}"))
        present.append(sid)
    index = {
        "v": 4,
        "createdOnFiles": {"v": 1, "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")},
        "lists": "css",
        "title": "Herdsman: the statistical referee for AI analysts",
        "cover": "cover",
        "order": present,
        "sections": {k: v for k, v in SECTIONS.items() if v["start"] in present},
        "faces": FACES,
        "designSystems": [],
    }
    (out / "project" / "deck.json").write_text(json.dumps(index, indent=1, ensure_ascii=False))
    return out


def build_site(V: dict) -> Path:
    out = HERE / "out" / "site" / "project"
    out.mkdir(parents=True, exist_ok=True)
    (out / "Main.dc.html").write_text(fill((HERE / "site_src" / "Main.dc.html").read_text(), V, r"@@([a-zA-Z0-9_]+)@@"))
    canvas = {
        "v": 3,
        "createdOnFiles": {"v": 1, "at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")},
        "title": "Herdsman website",
        "launch": {"view": "focused", "file": "Main.dc.html"},
        "pages": [],
        "boards": {"Main.dc.html": {"x": 0, "y": 0, "w": 1440, "h": 5200, "title": "Home page", "expand": "fill"}},
        "order": ["Main.dc.html"],
        "notes": {},
        "designSystems": [],
    }
    (out / "canvas.json").write_text(json.dumps(canvas, indent=1, ensure_ascii=False))
    return out.parent


if __name__ == "__main__":
    V = values()
    print("deck:", build_deck(V))
    print("site:", build_site(V))
