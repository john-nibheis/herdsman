"""Minimal Markdown to block JSON for the docx renderer.

Supports headings (#, ##, ###), paragraphs, bullet and numbered lists, pipe tables,
block quotes, and inline **bold**, *italic*, `code` and [links](url).
Usage: python md2json.py out.json part1.md [part2.md ...]
"""
import json
import re
import sys

INLINE = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^)]+\))")


def inline(text: str) -> list[dict]:
    runs = []
    for piece in INLINE.split(text):
        if not piece:
            continue
        if piece.startswith("**") and piece.endswith("**"):
            runs.append({"text": piece[2:-2], "bold": True})
        elif piece.startswith("*") and piece.endswith("*") and len(piece) > 2:
            runs.append({"text": piece[1:-1], "italic": True})
        elif piece.startswith("`") and piece.endswith("`"):
            runs.append({"text": piece[1:-1], "code": True})
        elif piece.startswith("["):
            m = re.match(r"\[([^\]]+)\]\(([^)]+)\)", piece)
            runs.append({"text": m.group(1), "link": m.group(2)})
        else:
            runs.append({"text": piece})
    return runs


def parse(text: str) -> list[dict]:
    blocks, para = [], []
    lines = text.splitlines()
    i = 0

    def flush():
        if para:
            blocks.append({"type": "p", "runs": inline(" ".join(s.strip() for s in para))})
            para.clear()

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped:
            flush()
            i += 1
            continue
        m = re.match(r"^(#{1,3})\s+(.*)$", stripped)
        if m:
            flush()
            blocks.append({"type": f"h{len(m.group(1))}", "text": m.group(2)})
            i += 1
            continue
        if stripped.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.match(r"^:?-{3,}:?$", c) for c in cells):
                    rows.append([inline(c) for c in cells])
                i += 1
            blocks.append({"type": "table", "rows": rows})
            continue
        if re.match(r"^[-*]\s+", stripped):
            flush()
            items = []
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i].strip()):
                items.append(inline(re.sub(r"^[-*]\s+", "", lines[i].strip())))
                i += 1
            blocks.append({"type": "ul", "items": items})
            continue
        if re.match(r"^\d+\.\s+", stripped):
            flush()
            items = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i].strip()):
                items.append(inline(re.sub(r"^\d+\.\s+", "", lines[i].strip())))
                i += 1
            blocks.append({"type": "ol", "items": items})
            continue
        if stripped.startswith(">"):
            flush()
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip().lstrip(">").strip())
                i += 1
            blocks.append({"type": "quote", "runs": inline(" ".join(quote))})
            continue
        para.append(line)
        i += 1
    flush()
    return blocks


if __name__ == "__main__":
    out, *sources = sys.argv[1:]
    blocks = []
    for src in sources:
        blocks.extend(parse(open(src, encoding="utf-8").read()))
    json.dump(blocks, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{len(blocks)} blocks -> {out}")
