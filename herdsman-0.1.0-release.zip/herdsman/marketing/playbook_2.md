# Proof points

Every figure below comes from the accompanying research paper and is reproduced by code in the open repository. Use these numbers verbatim; do not round them in a way that changes their meaning, and always say "in simulation" or "in our case study" where that is where they come from.

| Proof point | Figure | Source |
|---|---|---|
| Unrefereed AI analyst reports that contained at least one false finding when nothing was real | {{null_naive_any_false}} of simulated studies | Paper, Table 1 |
| Highest false discovery rate of Herdsman in any simulated setting | {{max_fdr_rolling}} (target 10%) | Paper, Section 6 |
| A claim built from pure noise, certified after a holdout was re-used | {{leak_estimates_cert}} of null studies | Paper, Table 3 |
| The same attack against Herdsman's rolling seal | {{leak_rolling_cert}} of null studies | Paper, Table 3 |
| True findings certified, sparse effects, Herdsman vs a single pre-registered holdout with Benjamini–Hochberg | {{sparse_share_rolling}} vs {{sparse_share_bh}} | Paper, Table 2 |
| Time to close an episode on a 48,000-row study (decrypt, test ten claims, sign certificates) | {{overhead_close_seconds}} seconds | Paper, Section 6.5 |
{{case_proof_rows}}

The power figure is not a weakness to hide. It is the honest price of a guarantee that survives agents coming back for more; a holdout used once is more powerful, and invalid the moment it is used twice. Lead with the first four rows; use the fifth when a technical buyer asks what it costs.

# Who buys, and why

## Beachhead 1: banks and lenders

The buyer is the Head of Model Risk Management or Model Validation, with the Chief Risk Officer as sponsor and the Head of Data Science as user. The trigger is first-line teams deploying AI agents for analytics, credit strategy and early-warning work, and second-line functions being asked how they challenge agent output. PRA SS1/23 asks for "a validation process that provides ongoing, independent, and effective challenge" and that "the validation function should operate independently from the model development process and from model owners"; its expectations bind banks with internal-model permission and are offered as useful principles to others. The FCA, according to reports of its 2026 statements, intends to rely on existing rules and governance expectations rather than AI-specific rules, so firms will be expected to evidence control themselves; its AI Live Testing programme, whose evaluation report is due in the first quarter of 2027, is exploring output-driven validation. Herdsman gives second-line teams an artefact they can examine: a ledger of what the agent tried, a quantified error rate, and signed certificates for what it was allowed to conclude.

Their objections are integration with model inventories, data residency and key custody, and whether the vendor will be around; the Enterprise edition and an open-source core answer all three. The founder's own profile, a practising chief risk officer and head of data science at a UK lender who is starting a statistics PhD, is the strongest asset in this segment; keep Nibheis work clean-room and separate from the employer, and never use employer data, customers or materials.

## Beachhead 2: AI-for-science and drug discovery

The buyer is the head of computational biology, AI research or platform at a company running AI-scientist agents, or the scientific officer who decides which machine-generated leads earn wet-lab time. The trigger is the cost of following false leads and the vendors' own warnings that their agents chase spurious correlations. Herdsman's message here is "decide which leads have earned an experiment". Certificates and ledgers also answer journals and funders who increasingly ask how AI-generated analyses were produced. This segment has the largest budgets and the most acute pain; it needs domain e-values beyond means (survival, dose-response, omics), so plan the roadmap with design partners.

## Beachhead 3: product analytics and experimentation

The buyer is the head of data science or experimentation at a digital business whose agents already read and run experiments through MCP. The trigger is agents mining experiments for segment-level wins. Herdsman sits behind the experimentation platform's MCP tools as the referee for anything beyond the pre-declared primary metric. This segment is the fastest to adopt the open-source core and the most price-sensitive.

## Personas in one line each

The model-risk head wants independent, documented challenge they can show a regulator. The data-science head wants their agents to stop embarrassing them in front of executives. The computational scientist wants to spend lab money only on leads that will replicate. The experimentation lead wants agent-found segment wins they can actually ship. The agent builder wants a tool their agent can call that makes its findings credible.

# Competition and positioning

## The landscape

Experimentation platforms (Statsig, now owned by OpenAI; Eppo, now owned by Datadog; GrowthBook; Optimizely; LaunchDarkly) offer sequential testing, CUPED and multiple-comparison corrections inside a pre-declared experiment, and several expose experiments to agents through MCP. They are the most natural integration partners and the most plausible fast followers.

AI analytics vendors positioning on trust (QueryStory, which raised a $6m seed; Summation, $35m; Solid, a $20m seed; Probably, a $9m seed) verify computation, lineage, semantics or definitions. Investors are funding "trust in AI analysis" at seed sizes of $6m to $35m. These are complements and channel partners: a QueryStory or Summation finding could carry a Herdsman certificate.

Verification for AI in science and regulated reasoning (Helical, Axiomatic AI, Pramaana Labs) checks predictions or reasoning against evidence or formal rules, not the error rate of exploratory findings.

Model-risk and AI-governance tools (ValidMind, Monitaur, Fiddler, Arthur, Credo AI, Holistic AI) inventory, document, test and monitor models. ValidMind, with an open-source library and explicit SS1/23 positioning, is the most important adjacency: a likely partner and a possible competitor if it adds an "agent claims" module.

Open-source and academic work is the closest in substance. MethodSeal, an MIT-licensed tool published in July 2026, hash-seals analysis plans for agents and blocks unlogged edits, but has no sealed confirmation data or error-rate control. SDCP is a one-person prototype calibrating false discovery on null worlds. A NeurIPS 2026 paper describes a broker that binds confirmatory attempts before data access under an online false discovery controller. Building blocks such as the online-fdr and expectation packages exist on PyPI.

## Where Herdsman wins

The defensible ground is the combination, packaged for regulated buyers: sealed rotating folds that let agents iterate without contaminating confirmation data; a provable error rate under arbitrary agent behaviour; a tamper-evident ledger; signed, independently verifiable certificates; and an MCP interface. No single primitive is defensible on its own. Two further moats are worth building deliberately: being independent of any data platform, which a platform cannot credibly offer about its own agents, and making the certificate format a standard that others verify.

## Battlecard

| When they say | They mean | We say |
|---|---|---|
| "Our experimentation platform already corrects for multiple comparisons." | Benjamini–Hochberg or sequential tests on one experiment's metrics. | Those protect a pre-declared experiment. Your agent explores across segments, outcomes and datasets after the fact; Herdsman controls the error rate of those conclusions, and can sit behind the platform's own agent tools. |
| "Our AI analytics tool shows the SQL and the lineage." | Provenance. | Provenance tells you the number was computed correctly. It cannot tell you whether it is a real effect or the best of three hundred tries. Use both. |
| "We keep a holdout set." | A single holdout that people look at. | A holdout used twice is no longer a holdout. In our test, re-using one let a claim built from noise be certified in {{leak_estimates_cert}} of studies. The rolling seal spends each fold once and gives it back. |
| "ValidMind / our governance platform documents our models." | Model inventory and validation workflow. | Herdsman produces the evidence those workflows need for agent analytics: a ledger, an error rate and certificates. We integrate rather than replace. |
| "MethodSeal does pre-registration for agents, free." | Hash-sealed plans. | Sealing a plan is good hygiene; it does not stop an agent from trying many plans, and it has no confirmation data or error-rate control. Herdsman's core is free too. |
| "We could build this ourselves." | An internal tool. | You could. The guarantee rests on details (levels fixed at commit, folds spent once, e-values valid under dependence, keys held apart) that are easy to get subtly wrong, and an internal referee is not independent. |

# Pricing and packaging hypotheses

These are starting hypotheses to test with design partners, anchored on public comparables; none is validated. Public anchors: GrowthBook Pro at $40 per seat per month; Statsig Pro at $150 a month plus usage; Kosmos at $200 a run; median annual contracts of $45,000 for Eppo, $60,000 for Arize and $81,000 for Optimizely; Monitaur's public offers at roughly $33,000 and $167,000 a year. Hybrid pricing is now the norm among software and AI companies.

| Edition | Who it is for | Proposed price | What it includes |
|---|---|---|---|
| Core | Developers, researchers, agent builders | Free, Apache 2.0 | Library, CLI, MCP server, local vault, certificates, reports |
| Cloud Team | A data-science team | $490 a month per workspace | Hosted referee and key custody, five active studies, unlimited analysts and agents, certificate registry with public verification links |
| Cloud Business | Several teams; regulated mid-market | $1,950 a month | Twenty-five active studies, single sign-on, audit exports, seven-year retention, 99.9% availability commitment |
| Enterprise | Banks, lenders, pharma | From $60,000 a year; typical $60,000–150,000 | Customer-cloud or on-premises deployment, hardware-backed keys, model-risk evidence pack, inventory integration, named support |
| Academic | Non-commercial research groups | Free Cloud Team | Adoption and credibility; publication of certificates |

Make certificate verification free for anyone, forever: every verification is a small advertisement and builds the certificate into a standard. Test a usage component (per active study or per certified claim) against the flat tiers with the first ten customers; seat-based pricing is a poor fit when the analysts are agents.

Run six to ten design partners, two to four per beachhead, on a twelve-month agreement at half of list price with a conversion decision agreed in advance at month nine; Bessemer's advice to make the end of a design partnership a binary "go paid or don't" is the right discipline. Ask each partner for a named case study and a reference call in return.

# Messaging

## Pillars

**Agent-proof validity.** The share of certified findings that are false is capped at the level you choose, whatever your agents do, however many things they try, and however they revise their claims. Proof: the theorem in the paper and a false discovery rate of at most {{max_fdr_rolling}} across every simulated setting.

**Built for iteration.** Agents come back; Herdsman expects them to. Each sealed fold is spent once and then handed back, so the agent can keep exploring without contaminating the confirmation data. Proof: the re-use attack ({{leak_estimates_cert}} versus {{leak_rolling_cert}}).

**Evidence you can audit.** Every test and decision is in a hash-chained ledger; every certified finding has a signed certificate that anyone can verify offline; every number can be recomputed from published commitments. Proof: tampering with a single ledger record is detected.

**Fits your agent stack.** Python, command line and an MCP server any agent can call; open source; runs offline by default. Proof: {{case_stack_proof}}

## Pitches

*Ten seconds.* Herdsman is a statistical referee for AI analysts: it certifies only the findings that hold up on data your agent has never seen.

*Thirty seconds.* AI agents can test hundreds of ideas in minutes and report the best-looking ones, and the statistics they show you will not tell you how hard they looked. Herdsman sits between your agents and your data. It keeps confirmation data sealed, fixes the bar for each claim before testing it, and signs a certificate only when a finding survives. Across a study, you choose the maximum share of false findings, and it holds whatever the agent did.

*Two minutes.* Add the problem evidence (the 19% confidence figure and one agent study), the re-use attack result, a thirty-second demo of a certificate being verified, and the offer: the core is open source; the hosted referee and the enterprise edition give you key custody and the evidence your validators need.

## Words to use and avoid

Say "certifies", "controls the false discovery rate", "independent challenge", "sealed data", "evidence you can audit". Avoid "guarantees truth", "proves causality", "eliminates false positives" and "AI-powered statistics". Never claim that a certificate makes a finding causal or that it holds after the population changes; the certificate says what it covers, and so should we.

## Objections

"It will certify fewer findings." Yes, by design. In our simulations, when nothing was real, unrefereed AI reports contained false findings in {{null_naive_any_false}} of studies; every finding Herdsman declines is one you could not have defended. If you can pre-register one round of claims, batch mode recovers much of the power.

"We already have a holdout." If anyone looks at the holdout and iterates, it has stopped being one.

"Our analysts are careful." They may be; in our case study the AI agents were careful too, and none reported a false effect. Careful is not the same as verified. The referee told the executive committee which findings had held up on data the agent had never seen and which had not yet, including the most important risk, and it left an audit trail either way. Careful analysts still walk forking paths when the data are noisier or the brief is looser; the referee is cheap insurance and free documentation.

"Is it a black box?" No: the core is open source, deterministic and offline by default, and every number can be recomputed from the published commitments.

"What about causality?" A certificate certifies the statistical claim as written. Randomised experiments make treatment claims causal; associations stay associations.

"Where does our data go?" With Core, nowhere. With Enterprise, it stays in your cloud with keys in your hardware security module.
