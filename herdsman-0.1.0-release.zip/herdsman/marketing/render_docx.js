// Renders block JSON (from md2json.py) to a branded Word document with docx-js.
// Usage: node render_docx.js blocks.json out.docx "Title" "Subtitle" "Running header"
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, ShadingType,
  AlignmentType, Footer, Header, PageNumber, TableOfContents, ExternalHyperlink, LevelFormat, BorderStyle,
  PageBreak, TableLayoutType,
} = require("docx");

const [, , input, output, title, subtitle, running] = process.argv;
const blocks = JSON.parse(fs.readFileSync(input, "utf8"));

const NAVY = "0B2545", TEAL = "1F8A8A", AMBER = "E09F3E", SLATE = "5B6B7F", SAND = "D9D4C7", MIST = "EEF3F3";
const BODY = "Cambria", HEAD = "Calibri";
const PAGE_W = 11906, MARGIN = 1247; // A4, 2.2 cm margins
const CONTENT_W = PAGE_W - 2 * MARGIN;

function runs(list, opts = {}) {
  return list.map((r) => {
    const base = { text: r.text, bold: r.bold || opts.bold, italics: r.italic || opts.italic, font: r.code ? "Consolas" : opts.font || BODY, size: opts.size || 21, color: opts.color };
    if (r.link) {
      return new ExternalHyperlink({ link: r.link, children: [new TextRun({ ...base, color: TEAL, underline: {} })] });
    }
    return new TextRun(base);
  });
}

const children = [];
// Cover page
children.push(new Paragraph({ spacing: { before: 2400, after: 0 }, children: [new TextRun({ text: "NIBHEIS", font: HEAD, size: 20, bold: true, color: TEAL, characterSpacing: 60 })] }));
children.push(new Paragraph({ spacing: { before: 120, after: 0 }, children: [new TextRun({ text: "Financial Intelligence from Higher Ground", font: HEAD, size: 18, color: SLATE, italics: true })] }));
children.push(new Paragraph({ spacing: { before: 1800, after: 120 }, children: [new TextRun({ text: title, font: HEAD, size: 72, bold: true, color: NAVY })] }));
children.push(new Paragraph({ border: { bottom: { style: BorderStyle.SINGLE, size: 18, color: AMBER, space: 8 } }, spacing: { after: 240 }, children: [new TextRun({ text: subtitle, font: HEAD, size: 32, color: TEAL })] }));
children.push(new Paragraph({ spacing: { before: 240 }, children: [new TextRun({ text: "Version 1.0 · November 2026 · Confidential: prepared for colleagues and design partners", font: HEAD, size: 18, color: SLATE })] }));
children.push(new Paragraph({ spacing: { before: 120 }, children: [new TextRun({ text: "Credit Risk Models (E) Limited, trading as Nibheis", font: HEAD, size: 18, color: SLATE })] }));
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Contents")] }));
children.push(new TableOfContents("Contents", { hyperlink: true, headingStyleRange: "1-2" }));
children.push(new Paragraph({ children: [new PageBreak()] }));

let first = true;
for (const b of blocks) {
  if (b.type === "h1") {
    if (!first) children.push(new Paragraph({ children: [new PageBreak()] }));
    first = false;
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(b.text)] }));
  } else if (b.type === "h2") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(b.text)] }));
  } else if (b.type === "h3") {
    children.push(new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(b.text)] }));
  } else if (b.type === "p") {
    children.push(new Paragraph({ style: "Body", children: runs(b.runs) }));
  } else if (b.type === "quote") {
    children.push(new Paragraph({
      style: "Body",
      indent: { left: 400 },
      border: { left: { style: BorderStyle.SINGLE, size: 18, color: TEAL, space: 10 } },
      shading: { type: ShadingType.CLEAR, fill: MIST, color: "auto" },
      children: runs(b.runs, { italic: true }),
    }));
  } else if (b.type === "ul" || b.type === "ol") {
    for (const item of b.items) {
      children.push(new Paragraph({ style: "Body", numbering: { reference: b.type === "ul" ? "bullets" : "numbers", level: 0 }, children: runs(item) }));
    }
  } else if (b.type === "table") {
    const ncol = Math.max(...b.rows.map((r) => r.length));
    // width heuristic: weight columns by their longest cell
    const weights = Array.from({ length: ncol }, (_, c) => Math.max(8, ...b.rows.map((r) => (r[c] || []).map((x) => x.text).join("").length)));
    const capped = weights.map((w) => Math.min(w, 70));
    const total = capped.reduce((a, b2) => a + b2, 0);
    const widths = capped.map((w) => Math.round((CONTENT_W * w) / total));
    widths[widths.length - 1] += CONTENT_W - widths.reduce((a, b2) => a + b2, 0);
    const rows = b.rows.map((r, ri) => new TableRow({
      tableHeader: ri === 0,
      cantSplit: true,
      children: Array.from({ length: ncol }, (_, c) => new TableCell({
        width: { size: widths[c], type: WidthType.DXA },
        shading: ri === 0 ? { type: ShadingType.CLEAR, fill: NAVY, color: "auto" } : (ri % 2 === 0 ? { type: ShadingType.CLEAR, fill: "F7F5F0", color: "auto" } : undefined),
        margins: { top: 70, bottom: 70, left: 100, right: 100 },
        children: [new Paragraph({ spacing: { before: 0, after: 0 }, children: runs(r[c] || [{ text: "" }], { font: HEAD, size: 17, color: ri === 0 ? "FFFFFF" : "1A1A1A", bold: ri === 0 }) })],
      })),
    }));
    children.push(new Table({
      width: { size: CONTENT_W, type: WidthType.DXA },
      columnWidths: widths,
      layout: TableLayoutType.FIXED,
      borders: {
        top: { style: BorderStyle.SINGLE, size: 8, color: NAVY }, bottom: { style: BorderStyle.SINGLE, size: 8, color: NAVY },
        left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" }, right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        insideHorizontal: { style: BorderStyle.SINGLE, size: 4, color: SAND }, insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      },
      rows,
    }));
    children.push(new Paragraph({ spacing: { before: 0, after: 120 }, children: [] }));
  }
}

const doc = new Document({
  features: { updateFields: true },
  creator: "Nibheis",
  title,
  description: subtitle,
  styles: {
    default: { document: { run: { font: BODY, size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Body", quickFormat: true, run: { font: HEAD, size: 36, bold: true, color: NAVY }, paragraph: { spacing: { before: 240, after: 160 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Body", quickFormat: true, run: { font: HEAD, size: 26, bold: true, color: TEAL }, paragraph: { spacing: { before: 280, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Body", quickFormat: true, run: { font: HEAD, size: 22, bold: true, color: NAVY }, paragraph: { spacing: { before: 200, after: 80 }, keepNext: true, outlineLevel: 2 } },
      { id: "Body", name: "Body", basedOn: "Normal", quickFormat: true, run: { font: BODY, size: 21, color: "1A1A1A" }, paragraph: { spacing: { before: 0, after: 140, line: 288 }, alignment: AlignmentType.LEFT } },
    ],
  },
  numbering: {
    config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
      { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
    ],
  },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: 1247, bottom: 1247, left: MARGIN, right: MARGIN } } },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: running, font: HEAD, size: 16, color: SLATE })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: HEAD, size: 16, color: SLATE })] })] }) },
    children,
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(output, buf); console.log("written", output); });
