# Summary

Herdsman is an independent statistical referee for AI analysts and AI scientists. It sits between an agent and its data, keeps confirmation data sealed where the agent cannot see it, tests each claim the agent commits on data it has never seen, and signs a verifiable certificate only for findings that survive. Across every claim in a study, the expected share of certified claims that are false is capped at a level the customer chooses, whatever the agent did to find them.

The problem is no longer hypothetical. Agents that analyse data are now default features of every major data platform, and in 2026 a run of studies showed that they can be steered into specification search, that their conclusions follow the priors they are given, and that their misleading analyses pass methodological review. Buyers already say what they want: only 19% of senior data leaders at large companies are very confident in AI-generated analysis, and 53% of data and analytics leaders prioritise audit trails for AI answers.

We found no funded company selling this. Provenance and verification vendors show how a number was computed; experimentation platforms correct error rates inside one pre-declared experiment; model-governance tools inventory and document models. None controls the error rate of the conclusions an autonomous analyst draws from open-ended exploration. The idea is in the air (an open-source pre-registration tool, a one-person prototype and several academic papers appeared between June and August 2026), so the window is months, not years.

Our evidence is unusually strong for a launch. A working, tested product exists. A research paper proves the guarantee and measures it: in simulated studies where nothing was real, unrefereed AI analyst reports contained false findings in {{null_naive_any_false}} of studies, while Herdsman's false discovery rate never exceeded {{max_fdr_rolling}}. When a team re-uses a holdout, as agents do, a claim built from pure noise was certified in {{leak_estimates_cert}} of studies even with a modern online error budget; under Herdsman's rolling seal, in {{leak_rolling_cert}}. {{case_marketing_sentence}}

The plan is open-core. Release the core library and MCP server free under Apache 2.0 to win developers and credibility; sell a hosted referee (key custody, sealed vaults, a public certificate registry) by subscription; and sell an enterprise edition with a model-risk evidence pack to banks, lenders and pharmaceutical companies. Start with six to ten design partners across three beachheads: bank and lender analytics, AI-for-science teams, and product analytics teams whose agents already run experiments. The decisive near-term actions are four: clear the name and the University of Edinburgh IP position, publish the paper and the code together, sign the first three design partners, and get the MCP server into the directories where agent builders look.

Three risks deserve board-level attention. A platform could ship a good-enough version (Statsig is owned by OpenAI and Eppo by Datadog, and both already expose experiments to agents); being the independent referee, and the certificate standard, is the defence, and acquisition is a plausible exit. Rigour certifies fewer findings, and some buyers will hear that as a cost; the message must be that every finding it removes was one they could not defend. And the regulatory hooks are narrower than often assumed, so the sale must stand on trust and cost of error, with regulation as a tailwind rather than the reason.

# The product

## One-line description

Herdsman is the statistical referee for AI analysts: it counts every test, seals the confirmation data, and certifies only what survives.

## Positioning statement

For data, risk and science teams that let AI agents analyse their data, Herdsman is the independent statistical referee that certifies only the findings that hold up on sealed data, with a provable cap on the share of certified findings that are false. Unlike provenance and SQL-verification tools, which show how a number was computed, Herdsman tells you whether the finding is real given how hard the agent searched for it.

## Taglines

The primary line is "Count every test. Seal the confirmation data. Certify only what survives." Shorter alternatives for different settings are "The referee for AI analysts", "Findings you can sign", and, for risk audiences, "Independent challenge for agent analytics".

## The name

*Herdsman* is the English for *buachaille*. Buachaille Etive Mòr, the great herdsman of Etive, stands guard at the head of Glen Coe, and the Gaelic sense of watching over a herd, or invigilating an examination, is the brand story: Herdsman watches over your agents' conclusions the way an invigilator watches an exam. The name keeps the Nibheis convention of naming major frameworks after Munros, through the mountain it is named for, while giving buyers in the United States and in regulated firms a word they can say, spell and search for. Use the mountain in the origin story, not in the product name.

On 7 November 2026 the name was free on PyPI; on npm it is used by a small early-stage dashboard project, so any JavaScript client should take a scoped name such as `@nibheis/herdsman`. Use the GitHub path `nibheis/herdsman`. A quick search of United States trademark records found HERDSMAN marks for computer goods (class 9, cancelled in 2023), metal goods and housewares (classes 6 and 21, live), grass seed (class 31, abandoned) and an animal-husbandry database (class 44, abandoned as eHERDSMAN). None of the live marks found is in classes 9 or 42, but this was not a clearance search, and the United Kingdom and European Union registers were not checked. Herdsman is an ordinary English word with agricultural uses, so commission a professional clearance search in classes 9 and 42 in the UK, EU and US before any brand spend. The earlier working name, Buachaille, remains available for the open-source project or a product tier.

## What it does

Herdsman splits a dataset into an open exploration set and sealed folds whose hashes are published before anyone looks. The agent explores freely through Python, a command line or the Model Context Protocol, and every test it runs through the referee is written to a hash-chained ledger. When the agent believes a finding, it commits a precise, testable claim, and the referee fixes there and then the evidence the claim must reach. At the end of each episode the referee opens one sealed fold, once, and each open claim's evidence is updated; claims that reach their bar are certified and signed. The spent fold is then handed to the agent, so nothing is wasted and the agent can keep iterating, because new claims are only ever tested on folds it has not seen. Language models can help propose how tests group into hypotheses, but every number is computed by deterministic code, and nothing a model proposes can weaken the guarantee.

## Packaging

Herdsman Core is the open-source library, command line, MCP server, local vault, certificates and HTML reports, under Apache 2.0. Herdsman Cloud is the hosted referee: key custody, sealed vaults the analyst's machine never holds, a certificate registry with public verification links, team workspaces and audit exports. Herdsman Enterprise runs in the customer's cloud or data centre with keys in a hardware security module, and adds a model-risk evidence pack: mappings to PRA SS1/23 Principle 4 and EU AI Act Articles 12 and 15, validation-report templates, and integration with model inventories.

# The problem

## AI analysts are mainstream

Analytics agents are now standard features of the platforms enterprises already pay for. Databricks reported more than 4,000 customers adopting its Genie analytics agent during preview. Snowflake said its Intelligence agent had become essential to almost 2,500 accounts within three months. Hex raised $100m at a $1.2bn valuation calling itself an analytics platform "for humans and agents", and Julius AI reported more than two million users. Agents also run experiments: Statsig's MCP server gives coding agents a tool to create experiments, and GrowthBook's shows agents reading results and recommending whether to ship. Optimizely reports that users of its agents run 78.7% more experiments.

AI scientists have arrived in pharmaceutical research too. Edison Scientific launched its Kosmos AI scientist at $200 a run, and said executives from six of the top ten pharmaceutical companies had enquired. Periodic Labs raised a $300m seed; Lila Sciences was reported in talks at an $8.5bn valuation.

## Trust is the bottleneck

Only 19% of senior data leaders at North American companies with more than $1bn of revenue are very confident in AI-generated analysis, and 35% have little or no confidence. In another survey, 53% of data and analytics leaders said they prioritise audit trails for AI answers, and 31% said they cannot verify AI results. Gartner found that only 19% of IT application leaders have high or complete trust in their vendor's hallucination protection. Inaccuracy is the most commonly cited negative consequence of enterprise AI use in McKinsey's 2025 survey.

## The failure is in the search, not the code

The best recent evidence locates the risk in what agents choose to report, not in arithmetic errors. Frontier coding agents decline explicit requests to produce significant results, but run systematic specification searches when the same request is reframed as "uncertainty reporting". Agents given opposing priors reached opposing conclusions from the same data, reproducing 72% of the ideological gap seen among 42 human research teams, and 86% of their reports passed independent AI methodological review. Agents "frequently make subtle inferential errors that lead to incorrect conclusions" even when their code runs. The makers of the Kosmos AI scientist say it "often goes down rabbit holes or chases statistically significant yet scientifically irrelevant findings", and the authors of Sakana's AI Scientist write in *Nature* that its problems "would prevent us from reliably trusting the outputs".

## False discoveries are expensive

In online experimentation, when 10% of experiments truly succeed, about 22% of statistically significant wins are false positives; at an 8% success rate the figure is about 26%. Amgen could confirm only 6 of 53 landmark preclinical cancer findings, and an estimated $28bn a year is spent on irreproducible preclinical research in the United States. A Phase II programme costs around $40m per candidate. In lending, a spurious early-warning signal or a mis-targeted product change is paid for in credit losses, customer harm and regulatory attention.

## Existing safeguards do not transfer

Pre-registration assumes the plan is written before the data are seen, but an agent with data access always sees it first. Multiple-testing corrections need the number of tests, which agents rarely report. A holdout set works only if it is used once; the moment someone looks at holdout results and comes back with a refined claim, the holdout is contaminated, and agents always come back.
