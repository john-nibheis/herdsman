"""Shared loaders and formatting for paper figures, tables and in-text numbers.
Every number quoted in the paper is produced here from the results files."""
from __future__ import annotations

from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = Path(__file__).resolve().parent / "figures"

NAVY, TEAL, AMBER, SLATE, SAND = "#0B2545", "#1F8A8A", "#E09F3E", "#5B6B7F", "#D9D4C7"

METHOD_LABELS = {
    "naive_all_p05": "Every exploratory test with p < 0.05",
    "naive_report": "Analyst's report (top claims, p < 0.05)",
    "explore_bh": "BH at 10% over all logged exploratory tests",
    "holdout_p05": "Holdout, p < 0.05 per claim",
    "holdout_bonferroni": "Holdout, Bonferroni at 10%",
    "holdout_bh": "Holdout, Benjamini–Hochberg at 10%",
    "holdout_by": "Holdout, Benjamini–Yekutieli at 10% (batch mode)",
    "single_seal_ebh": "Holdout, e-BH at 10% (betting e-values)",
    "herdsman": "Rolling seal, e-LOND at 10% (Herdsman)",
    "herdsman_flat_prior": "Rolling seal without starting bets",
}
AGENT_LABELS = {
    "diligent": "Diligent",
    "forking": "Forking paths",
    "pressured": "Pressured",
    "adaptive_3_episodes": "Adaptive, 3 episodes",
}


def load(name: str) -> pd.DataFrame:
    return pd.read_csv(RESULTS / name, keep_default_na=False, na_values=[""])


def _half_up(x: float, digits: int) -> Decimal:
    """Round half away from zero after removing binary floating-point noise (0.8725 prints as 87.3%, not 87.2%)."""
    d = Decimal(repr(float(x))).quantize(Decimal("1e-9"), rounding=ROUND_HALF_EVEN)
    return d.quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)


def pct(x: float, digits: int = 0) -> str:
    return f"{_half_up(100 * x, digits)}%"


def num(x: float, digits: int = 1) -> str:
    return f"{_half_up(x, digits):,}"


def md_table(frame: pd.DataFrame, align: list[str] | None = None, widths: list[int] | None = None) -> str:
    """Pipe table; ``widths`` sets relative column widths through the separator's dash counts."""
    cols = list(frame.columns)
    align = align or ["l"] + ["r"] * (len(cols) - 1)
    widths = widths or [4] * len(cols)

    def mark(a: str, w: int) -> str:
        dashes = "-" * max(3, w)
        return {"l": ":" + dashes, "r": dashes + ":", "c": ":" + dashes + ":"}[a]

    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(mark(a, w) for a, w in zip(align, widths)) + " |"]
    for _, row in frame.iterrows():
        lines.append("| " + " | ".join(str(v) for v in row.tolist()) + " |")
    return "\n".join(lines)
