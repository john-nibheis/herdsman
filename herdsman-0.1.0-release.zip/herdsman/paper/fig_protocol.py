"""Figure 1: the rolling seal, drawn with matplotlib."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

NAVY, TEAL, AMBER, SLATE, SAND, PAPER = "#0B2545", "#1F8A8A", "#E09F3E", "#5B6B7F", "#D9D4C7", "#F7F5F0"
FONT = "DejaVu Sans"

fig, ax = plt.subplots(figsize=(10, 5.0))
ax.set_xlim(0, 100)
ax.set_ylim(0, 50)
ax.axis("off")

cols = [(16, "Episode 1"), (44.5, "Episode 2"), (73, "Episode 3")]
width = 25


def rbox(x, y, w, h, fc, ec, lw=1.0):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.9", fc=fc, ec=ec, lw=lw))


def text(x, y, s, size=8, color=NAVY, weight="normal", ha="center", va="center"):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va, family=FONT, linespacing=1.25)


# row labels
text(1, 41, "What the analyst\ncan read", 8.5, NAVY, "bold", ha="left")
text(1, 27, "Analyst", 8.5, NAVY, "bold", ha="left")
text(1, 12.5, "Referee", 8.5, NAVY, "bold", ha="left")

for k, (x, title) in enumerate(cols):
    text(x + width / 2, 48, title, 9.5, NAVY, "bold")
    # data strip: exploration + three folds
    segments = [("explore", 9.6), ("F1", 4.8), ("F2", 4.8), ("F3", 4.8)]
    cx = x
    for i, (label, w) in enumerate(segments):
        visible = i == 0 or i <= k
        ax.add_patch(Rectangle((cx, 38), w, 6, fc=TEAL if visible else NAVY, ec="white", lw=1.2))
        text(cx + w / 2, 41, label if visible else f"{label}\nsealed", 7 if visible else 6.3, "white", "bold")
        cx += w
    # analyst box
    rbox(x, 22, width, 10, PAPER, SAND)
    claims = ["C1–C5", "C6–C8", "C9"][k]
    text(x + width / 2, 27, f"Explores everything it can read\nand commits claims {claims}.\nEach claim's bar 1/α_t is fixed now.", 7.6)
    # referee box
    rbox(x, 7, width, 11, "#FBEBD2", AMBER)
    open_claims = ["C1–C5", "open claims from\nC1–C8", "open claims from\nC1–C9"][k]
    text(x + width / 2, 12.5, f"Opens fold {k + 1} once.\nMultiplies its e-value into the\nevidence of {open_claims}." if k == 0 else f"Opens fold {k + 1} once.\nMultiplies its e-value into the\nevidence of {open_claims}.", 7.4)
    ax.add_patch(FancyArrowPatch((x + width / 2, 21.6), (x + width / 2, 18.6), arrowstyle="-|>", mutation_scale=10, color=SLATE, lw=1.1))
    if k < 2:
        nxt = cols[k + 1][0]
        gap = x + width + (nxt - x - width) / 2
        target = nxt + 9.6 + 4.8 * (k + 1) - 2.4
        ax.plot([x + width + 0.3, gap, gap, target], [12.5, 12.5, 35.4, 35.4], color=TEAL, lw=1.2, ls="--")
        ax.add_patch(FancyArrowPatch((target, 35.4), (target, 37.7), arrowstyle="-|>", mutation_scale=10, color=TEAL, lw=1.2))
        ax.text(gap - 0.6, 24, f"fold {k + 1} spent, released", rotation=90, fontsize=6.8, color=TEAL, ha="right", va="center", family=FONT)

text(16, 2.6, "A claim is certified as soon as its running evidence reaches its bar; open claims keep accumulating on later folds.\n"
     "Guarantee: across all claims, the false discovery rate is at most α, whatever the analyst does.", 7.6, SLATE, ha="left")
plt.tight_layout(pad=0.4)
plt.savefig("figures/fig1_protocol.png", dpi=220, facecolor="white")
print("figures/fig1_protocol.png")
