"""Figure 7: evidence paths of every committed claim in the six case-study runs."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

import make_figures  # noqa: F401  (applies the shared figure style)
from results_lib import AMBER, FIGURES, NAVY, SLATE, TEAL

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "experiments"))
import casestudy as CS  # noqa: E402
import casestudy_stats as ST  # noqa: E402

from herdsman import Referee  # noqa: E402


def main() -> None:
    stats = ST.run_stats().set_index("run")
    scored = ST.load_scored()
    truth = scored[scored.kind == "committed claim"].copy()
    truth["id"] = truth["item"].str.split(".").str[0]
    truth = truth.groupby(["run", "id"])["is_true"].apply(lambda x: bool((x == True).any())).to_dict()  # noqa: E712
    runs = list(stats.index)
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.6), sharex=True, sharey=True)
    for ax, run in zip(axes.ravel(), runs):
        ref = Referee(CS.ROOT / "runs" / run / "study")
        for c in ref.claims():
            start = c["episode"] - 1
            xs = [start] + [t["fold"] for t in c["trajectory"]]
            ys = [0.0] + [t["log_e_cumulative"] / math.log(10) for t in c["trajectory"]]
            ys = [max(-1.5, min(y, 8.0)) for y in ys]
            certified = c["status"] == "certified"
            false = truth.get((run, c["id"])) is False
            color = AMBER if false else (TEAL if certified else SLATE)
            ax.plot(xs, ys, lw=1.0, marker="o", ms=2.2, color=color, alpha=0.9 if certified else 0.6, zorder=3 if certified else 2)
        for e in (200, 20):
            ax.axhline(math.log10(e), color=NAVY, lw=0.6, ls=(0, (3, 2)), alpha=0.5)
        r = stats.loc[run]
        ax.set_title(f"{run}: {r['label'].replace(' brief', '')}, {r['world_label'].lower()}", fontsize=8.5)
        ax.set_xticks([0, 1, 2, 3])
        ax.set_ylim(-1.6, 8.2)
    for ax in axes[1]:
        ax.set_xlabel("sealed folds opened")
    for ax in axes[:, 0]:
        ax.set_ylabel("log$_{10}$ evidence (capped at 8)")
    handles = [
        plt.Line2D([], [], color=TEAL, marker="o", ms=3, lw=1, label="certified"),
        plt.Line2D([], [], color=SLATE, marker="o", ms=3, lw=1, label="not certified"),
        plt.Line2D([], [], color=AMBER, marker="o", ms=3, lw=1, label="false claim"),
        plt.Line2D([], [], color=NAVY, lw=0.6, ls=(0, (3, 2)), label="e = 200 and e = 20"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    out = FIGURES / "fig7_case.png"
    fig.savefig(out, bbox_inches="tight")
    print("written", out)


if __name__ == "__main__":
    main()
