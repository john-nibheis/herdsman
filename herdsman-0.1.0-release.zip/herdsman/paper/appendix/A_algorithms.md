# Appendix A. Algorithms {.unnumbered}

**Algorithm 1 (rolling seal).** Input: data, $\alpha$, budget shape $\gamma$, $K$ folds, exploration fraction, number of orderings $B$.

1. Draw a seed $S$ and a salt; publish $\mathrm{SHA256}(\text{salt}:S)$. Shuffle the rows with $S$ and split them into $D_0,F_1,\dots,F_K$. Encrypt each fold; publish the hash of every fold's plaintext. Set $D\leftarrow0$ (certified claims), $t\leftarrow0$ (claims committed), $k\leftarrow1$ (current episode).
2. *Commit* (any time while $k\le K$): validate the claim; reject an exact duplicate of an open or certified claim; set $t\leftarrow t+1$, $\alpha_t\leftarrow\min\{\alpha,\alpha\gamma_t(D+1)\}$; compute the starting bet from the data the analyst can currently read; record everything in the ledger. The claim is open.
3. *Close episode $k$*: decrypt $F_k$ and check its hash. For each open claim $t$, compute $E_t^{(k)}$ on $F_k$ from its betting state, update $\log M_t\leftarrow\log M_t+\log E_t^{(k)}$ and its state; if $M_t\ge1/\alpha_t$, certify $t$, set $D\leftarrow D+1$ and issue a signed certificate. If $k=K$, expire every open claim. Release $F_k$ to the analyst. Set $k\leftarrow k+1$.
4. *Close study*: stop accepting claims; repeat step 3 while folds remain and claims are open; reveal $S$ and the salt; sign a checkpoint of the ledger head.

**Algorithm 2 (blocked betting e-value for a difference claim on one fold).** Input: focal outcomes $a_1,\dots,a_{n_f}$, reference outcomes $b_1,\dots,b_{n_r}$ in $[L,U]$, direction $s\in\{+1,-1\}$, margin $\delta$, state $(s_0,q_0)$, seed, $B$, $c=\tfrac12$.

1. $m\leftarrow\min(n_f,n_r)$, $r\leftarrow\lfloor\max(n_f,n_r)/m\rfloor$, $b\leftarrow U-L+\delta$, $v_0\leftarrow(U-L)^2/4$.
2. For each ordering $j=1,\dots,B$: permute both groups with the seeded generator; form $d_i$ by matching each unit of the smaller group with $r$ units of the larger; set $y_i=s\,d_i-\delta$; for $i=1,\dots,m$ set $\lambda_i=\mathrm{clip}\bigl((s_0+\sum_{l<i}y_l)/(q_0+\sum_{l<i}y_l^2+v_0),\,0,\,c/b\bigr)$ and $W_j=\prod_i(1+\lambda_iy_i)$.
3. Return $E=B^{-1}\sum_jW_j$ and the updated state (the averages over orderings of $\sum_iy_i$ and $\sum_iy_i^2$, added to $s_0$ and $q_0$).
