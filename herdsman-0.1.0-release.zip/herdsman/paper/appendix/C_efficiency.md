# Appendix C. How close the e-values come to the oracle {.unnumbered}

For two groups of binary outcomes with a real difference, Table C1 compares the mean log e-value with the mean of $z^2/2$, the log of the oracle Gaussian likelihood ratio evaluated at the true effect, which no e-value can beat on average. The informed start uses an estimate from an independent sample of the same size, as the referee does at commit. Starting bets close {{eff_gap_closed}} of the gap on average; the remainder, {{eff_gap_informed}} nats, is the cost of learning the bet from the data and of averaging over orderings.

{{table_efficiency}}

Table C2 translates these levels into the standardised effect a claim needs to be certified on its own at the first slot, by a one-sided z-test and by an e-value with the measured gap. At fifteen slots the e-value needs $z\approx{{z_e_150}}$ where the test needs $z\approx{{z_p_150}}$; later claims face lower bars once earlier ones are certified.

{{table_levels}}
