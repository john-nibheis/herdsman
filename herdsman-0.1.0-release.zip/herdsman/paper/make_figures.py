"""Figures 2-7 from the results files (Figure 1 is fig_protocol.py)."""
from __future__ import annotations

import math
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from results_lib import AMBER, FIGURES, METHOD_LABELS, NAVY, RESULTS, SAND, SLATE, TEAL, load

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 8.5,
        "axes.titlesize": 9.5,
        "axes.titleweight": "bold",
        "axes.titlecolor": NAVY,
        "axes.edgecolor": SLATE,
        "axes.labelcolor": NAVY,
        "xtick.color": SLATE,
        "ytick.color": SLATE,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.color": "#ECE8DF",
        "legend.frameon": False,
        "savefig.dpi": 220,
        "axes.axisbelow": True,
    }
)

ORDER = ["naive_report", "holdout_p05", "explore_bh", "holdout_bh", "holdout_bonferroni", "holdout_by", "single_seal_ebh", "herdsman"]
SHORT = {
    "naive_report": "Analyst's report",
    "holdout_p05": "Holdout, p<0.05",
    "explore_bh": "BH over logged tests",
    "holdout_bh": "Holdout, BH",
    "holdout_bonferroni": "Holdout, Bonferroni",
    "holdout_by": "Holdout, BY (batch)",
    "single_seal_ebh": "Holdout, e-BH",
    "herdsman": "Rolling seal (e-LOND)",
}


def colour(method: str) -> str:
    if method == "herdsman":
        return TEAL
    if method in ("naive_report", "holdout_p05"):
        return AMBER
    return SLATE


def fig_validity():
    s = load("validity_summary.csv")
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.4), sharey=True)
    for ax, world, title in zip(axes, ["global_null", "sparse"], ["Global null: every claim is false", "Sparse effects"]):
        part = s[(s.world == world) & (s.agent == "forking")].set_index("method").loc[ORDER]
        y = np.arange(len(ORDER))[::-1]
        ax.barh(y, part["FDR"], xerr=1.96 * part["FDR_se"], color=[colour(m) for m in ORDER], height=0.62, error_kw={"ecolor": NAVY, "lw": 0.8, "capsize": 2})
        ax.axvline(0.10, color=NAVY, ls="--", lw=1)
        ax.text(0.105, y[0] + 0.45, "α = 10%", color=NAVY, fontsize=7.5)
        for yi, v, se in zip(y, part["FDR"], part["FDR_se"]):
            ax.text(min(v + 1.96 * se, 1.0) + 0.02, yi, f"{100 * v:.1f}%", va="center", fontsize=7.2, color=NAVY)
        ax.set_xlim(0, 1.12)
        ax.set_yticks(y)
        ax.set_yticklabels([SHORT[m] for m in ORDER])
        ax.set_xlabel("false discovery rate (95% interval)")
        ax.set_title(title, loc="left")
        ax.grid(axis="y", visible=False)
    fig.suptitle("Forking-paths analyst: 723 exploratory tests, 15 claims per study, 500 simulated studies per world", x=0.01, ha="left", fontsize=8.5, color=SLATE)
    plt.tight_layout()
    fig.savefig(FIGURES / "fig2_validity.png", facecolor="white")
    plt.close(fig)


def fig_power():
    s = load("validity_summary.csv")
    methods = ["holdout_bh", "holdout_by", "single_seal_ebh", "herdsman", "herdsman_flat_prior"]
    labels = ["Holdout, BH", "Holdout, BY\n(batch mode)", "Holdout, e-BH", "Rolling seal", "Rolling seal,\nno starting bet"]
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.1))
    for ax, world, title in zip(axes, ["sparse", "dense"], ["Sparse effects", "Dense effects"]):
        part = s[(s.world == world) & (s.agent == "forking")].set_index("method").loc[methods]
        x = np.arange(len(methods))
        ax.bar(x, part["mean_true"], color=[TEAL if m.startswith("herdsman") else SLATE for m in methods], width=0.62, label="true claims certified")
        ax.bar(x, part["mean_false"], bottom=part["mean_true"], color=AMBER, width=0.62, label="false claims certified")
        committed = float(part["mean_committed_true"].iloc[0])
        ax.axhline(committed, color=NAVY, ls="--", lw=1)
        ax.text(len(methods) - 0.5, committed + 0.2, f"true claims committed: {committed:.1f}", ha="right", fontsize=7.2, color=NAVY)
        for xi, v in zip(x, part["mean_true"]):
            ax.text(xi, v / 2, f"{v:.1f}", ha="center", va="center", color="white", fontsize=7.5, fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=7.2)
        ax.set_ylabel("claims per study (mean)")
        ax.set_title(title, loc="left")
        ax.set_ylim(0, committed * 1.42)
        ax.grid(axis="x", visible=False)
    axes[0].legend(loc="upper left", fontsize=7.2, ncol=2)
    plt.tight_layout()
    fig.savefig(FIGURES / "fig3_power.png", facecolor="white")
    plt.close(fig)


def fig_leakage():
    raw = load("leakage_raw.csv")
    arms = ["reuse/estimates", "reuse/bits", "reuse/certified", "rolling/full"]
    labels = ["Re-used holdout,\nestimates released", "Re-used holdout,\n'e > 1' bits released", "Re-used holdout,\ndecisions only", "Rolling seal,\nspent fold released in full"]
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.2), gridspec_kw={"width_ratios": [1.35, 1]})
    ax = axes[0]
    for i, arm in enumerate(arms):
        values = raw.loc[raw.arm == arm, "log_e"].to_numpy() / math.log(10)
        jitter = np.random.default_rng(i).uniform(-0.18, 0.18, len(values))
        ax.scatter(values, np.full(len(values), len(arms) - 1 - i) + jitter, s=5, alpha=0.35, color=TEAL if arm.startswith("rolling") else AMBER, lw=0)
    threshold = math.log10((201) / 0.10)
    ax.axvline(threshold, color=NAVY, ls="--", lw=1)
    ax.text(threshold + 0.2, 1.62, "evidence needed\n(e ≥ 2,010)", fontsize=7, color=NAVY, va="center")
    ax.text(0.6, 1.0, "no claim was ever certified, so the analyst\nlearned nothing it could build a score from", fontsize=6.6, color=SLATE, va="center")
    ax.set_yticks(range(len(arms)))
    ax.set_yticklabels(labels[::-1], fontsize=7.4)
    ax.set_xlabel("log10 e-value of the composite claim (null by construction)")
    ax.set_title("Evidence for a claim built from what the referee released", loc="left")
    ax.grid(axis="y", visible=False)
    s = load("leakage_summary.csv").set_index("arm").loc[arms]
    ax = axes[1]
    x = np.arange(len(arms))
    ax.bar(x - 0.18, s["false_certification_rate"], width=0.34, color=NAVY, label="certified by e-LOND")
    ax.bar(x + 0.18, s["naive_holdout_p05_rate"], width=0.34, color=AMBER, label="'validated': holdout p < 0.05")
    for xi, (a, b) in enumerate(zip(s["false_certification_rate"], s["naive_holdout_p05_rate"])):
        ax.text(xi - 0.18, a + 0.02, f"{100 * a:.0f}%", ha="center", fontsize=7, color=NAVY)
        ax.text(xi + 0.18, b + 0.02, f"{100 * b:.0f}%", ha="center", fontsize=7, color=NAVY)
    ax.set_xticks(x)
    ax.set_xticklabels(["estimates", "bits", "decisions", "rolling\nseal"], fontsize=7.4)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("share of 400 null studies")
    ax.set_title("False certification of the composite", loc="left")
    ax.legend(fontsize=7, loc="upper right")
    ax.grid(axis="x", visible=False)
    plt.tight_layout()
    fig.savefig(FIGURES / "fig4_leakage.png", facecolor="white")
    plt.close(fig)


def fig_allocation():
    s = load("power_summary.csv")
    a = s[s.part == "A"].copy()
    a["setting"] = a["setting"].astype(float)
    fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.0), gridspec_kw={"width_ratios": [1, 1, 1.05]})
    styles = {"herdsman": (TEAL, "o", "Rolling seal"), "holdout_bh": (SLATE, "s", "Holdout, BH"), "holdout_by": (NAVY, "^", "Holdout, BY"), "single_seal_ebh": (AMBER, "D", "Holdout, e-BH")}
    for ax, world in zip(axes[:2], ["sparse", "dense"]):
        part = a[a.world == world]
        for method, (c, m, label) in styles.items():
            p = part[part.method == method].sort_values("setting")
            ax.plot(p["setting"], p["share_true_claims_certified"], marker=m, color=c, lw=1.6, ms=4, label=label)
        ax.set_xlabel("share of data kept for exploration")
        ax.set_ylabel("share of true claims certified")
        ax.set_title(f"{world.capitalize()} effects", loc="left")
        ax.set_ylim(0, 1)
    axes[0].legend(fontsize=7, loc="lower left")
    b = s[s.part == "B"]
    ax = axes[2]
    order = ["uniform_15", "harmonic_15", "uniform_50", "decaying"]
    labels = ["uniform\n15 slots\n(matched)", "front-loaded\n15 slots", "uniform\n50 slots", "decaying\nunlimited"]
    x = np.arange(len(order))
    for i, (world, c) in enumerate([("sparse", TEAL), ("dense", NAVY)]):
        p = b[b.world == world].set_index("setting").loc[order]
        ax.bar(x + (i - 0.5) * 0.36, p["mean_true"], width=0.34, color=c, label=world)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=6.8)
    ax.set_ylabel("true claims certified (mean)")
    ax.set_title("Budget shape", loc="left")
    ax.legend(fontsize=7)
    ax.grid(axis="x", visible=False)
    plt.tight_layout()
    fig.savefig(FIGURES / "fig5_allocation.png", facecolor="white")
    plt.close(fig)


def fig_episodes():
    s = load("power_summary.csv")
    c = s[s.part == "C"].copy()
    c["K"] = c["setting"].str.extract(r"K=(\d+)").astype(int)
    c["mode"] = np.where(c["setting"].str.contains("accumulate"), "accumulate", "one-shot")
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    for world, col in [("sparse", TEAL), ("dense", NAVY)]:
        for mode, ls in [("accumulate", "-"), ("one-shot", ":")]:
            p = c[(c.world == world) & (c["mode"] == mode)].sort_values("K")
            ax.plot(p["K"], p["mean_true"], ls=ls, marker="o", ms=3.5, color=col, label=f"{world}, {mode}")
    ax.set_xticks([2, 3, 4, 6])
    ax.set_xlabel("folds = episodes (30 claims in total)")
    ax.set_ylabel("true claims certified (mean)")
    ax.set_title("Adaptive analyst over several episodes", loc="left")
    ax.legend(fontsize=7)
    plt.tight_layout()
    fig.savefig(FIGURES / "fig6_episodes.png", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    wanted = sys.argv[1:] or ["validity", "power", "leakage", "allocation", "episodes"]
    for name in wanted:
        globals()[f"fig_{name}"]()
        print("figure", name)
