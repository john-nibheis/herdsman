"""Builds paper/reference.docx: pandoc's default reference document restyled in the
Nibheis print palette (navy #0B2545, teal #1F8A8A, amber #E09F3E)."""
from copy import deepcopy

import docx
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

NAVY, TEAL, SLATE = RGBColor(0x0B, 0x25, 0x45), RGBColor(0x1F, 0x8A, 0x8A), RGBColor(0x5B, 0x6B, 0x7F)
BODY, HEAD = "Cambria", "Calibri"

doc = docx.Document("default-ref.docx")


class _Styles:
    """Look styles up by their displayed name (python-docx maps some names to lowercase ids)."""

    def __init__(self, document):
        self._all = {st.name: st for st in document.styles}

    def __getitem__(self, name):
        return self._all[name]

    def __iter__(self):
        return iter(self._all.values())


styles = _Styles(doc)


def font(style, name, size=None, bold=None, italic=None, color=None):
    f = style.font
    f.name = name
    rpr = style.element.get_or_add_rPr()
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        rpr.append(fonts)
    for attr in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        fonts.set(qn(attr), name)
    for attr in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if fonts.get(qn(attr)) is not None:
            del fonts.attrib[qn(attr)]
    if size is not None:
        f.size = Pt(size)
    if bold is not None:
        f.bold = bold
    if italic is not None:
        f.italic = italic
    if color is not None:
        f.color.rgb = color


def spacing(style, before=None, after=None, line=None, keep_next=None, align=None):
    pf = style.paragraph_format
    if before is not None:
        pf.space_before = Pt(before)
    if after is not None:
        pf.space_after = Pt(after)
    if line is not None:
        pf.line_spacing = line
    if keep_next is not None:
        pf.keep_with_next = keep_next
    if align is not None:
        pf.alignment = align


for name in ("Normal", "Body Text", "First Paragraph", "Compact"):
    font(styles[name], BODY, 10.5, color=RGBColor(0x1A, 0x1A, 0x1A))
spacing(styles["Body Text"], before=0, after=7, line=1.15, align=WD_ALIGN_PARAGRAPH.JUSTIFY)
spacing(styles["First Paragraph"], before=0, after=7, line=1.15, align=WD_ALIGN_PARAGRAPH.JUSTIFY)
spacing(styles["Compact"], before=0, after=3, line=1.1)

font(styles["Title"], HEAD, 22, bold=True, color=NAVY)
spacing(styles["Title"], before=0, after=6, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Subtitle"], HEAD, 13, italic=False, color=TEAL)
spacing(styles["Subtitle"], before=0, after=14, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Author"], HEAD, 11, color=NAVY)
spacing(styles["Author"], before=0, after=2, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Date"], HEAD, 10, color=SLATE)
spacing(styles["Date"], before=0, after=14, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Abstract Title"], HEAD, 10.5, bold=True, color=NAVY)
spacing(styles["Abstract Title"], before=6, after=4, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Abstract"], BODY, 10, color=RGBColor(0x26, 0x32, 0x40))
spacing(styles["Abstract"], before=0, after=12, line=1.15, align=WD_ALIGN_PARAGRAPH.JUSTIFY)
styles["Abstract"].paragraph_format.left_indent = Cm(0.6)
styles["Abstract"].paragraph_format.right_indent = Cm(0.6)

sizes = {1: 15, 2: 12.5, 3: 11, 4: 10.5}
for level, size in sizes.items():
    style = styles[f"Heading {level}"]
    font(style, HEAD, size, bold=True, color=NAVY if level < 3 else TEAL)
    spacing(style, before=16 if level == 1 else 11, after=5, keep_next=True, align=WD_ALIGN_PARAGRAPH.LEFT)

for name in ("Caption", "Table Caption", "Image Caption"):
    font(styles[name], HEAD, 9, italic=False, color=SLATE)
    spacing(styles[name], before=3, after=10, align=WD_ALIGN_PARAGRAPH.LEFT)
font(styles["Block Text"], BODY, 10, italic=True, color=RGBColor(0x26, 0x32, 0x40))
styles["Block Text"].paragraph_format.left_indent = Cm(0.8)
font(styles["Bibliography"], BODY, 9.5)
spacing(styles["Bibliography"], before=0, after=4, line=1.1)
styles["Bibliography"].paragraph_format.left_indent = Cm(0.6)
styles["Bibliography"].paragraph_format.first_line_indent = Cm(-0.6)
font(styles["Footnote Text"], BODY, 9)

# Hyperlinks in teal
for style in styles:
    if style.name == "Hyperlink":
        style.font.color.rgb = TEAL

# Table style: booktabs-like rules, small sans text, shaded header row
table = styles["Table"]
tpr = table.element.find(qn("w:tblPr"))
if tpr is None:
    tpr = OxmlElement("w:tblPr")
    table.element.append(tpr)
for old in tpr.findall(qn("w:tblBorders")):
    tpr.remove(old)
borders = OxmlElement("w:tblBorders")
for edge, size in (("top", 12), ("bottom", 12), ("insideH", 4)):
    el = OxmlElement(f"w:{edge}")
    el.set(qn("w:val"), "single")
    el.set(qn("w:sz"), str(size))
    el.set(qn("w:space"), "0")
    el.set(qn("w:color"), "0B2545" if edge != "insideH" else "D9D4C7")
    borders.append(el)
tpr.append(borders)
rpr = table.element.find(qn("w:rPr"))
if rpr is None:
    rpr = OxmlElement("w:rPr")
    table.element.append(rpr)
for tag, val in (("w:rFonts", None), ("w:sz", "17"), ("w:szCs", "17")):
    el = OxmlElement(tag)
    if tag == "w:rFonts":
        for attr in ("w:ascii", "w:hAnsi", "w:cs"):
            el.set(qn(attr), HEAD)
    else:
        el.set(qn("w:val"), val)
    rpr.append(el)
# header row conditional formatting
tsp = OxmlElement("w:tblStylePr")
tsp.set(qn("w:type"), "firstRow")
trpr = OxmlElement("w:rPr")
b = OxmlElement("w:b")
trpr.append(b)
color = OxmlElement("w:color")
color.set(qn("w:val"), "0B2545")
trpr.append(color)
tsp.append(trpr)
tcpr = OxmlElement("w:tcPr")
shd = OxmlElement("w:shd")
shd.set(qn("w:val"), "clear")
shd.set(qn("w:color"), "auto")
shd.set(qn("w:fill"), "EEF3F3")
tcpr.append(shd)
tsp.append(tcpr)
for old in table.element.findall(qn("w:tblStylePr")):
    table.element.remove(old)
table.element.append(tsp)

# A4 page, 2.2 cm margins
for section in doc.sections:
    section.page_height, section.page_width = Cm(29.7), Cm(21.0)
    section.left_margin = section.right_margin = Cm(2.2)
    section.top_margin = section.bottom_margin = Cm(2.2)

doc.save("reference.docx")
print("reference.docx written")
