#!/usr/bin/env bash
# Builds the paper as Word (paper.docx) and PDF (paper.pdf). assemble.py fills every number from results/.
set -euo pipefail
cd "$(dirname "$0")"
python3 assemble.py
COMMON=(--from markdown+tex_math_dollars+pipe_tables+implicit_figures+raw_tex+table_captions --citeproc --bibliography references.bib --number-sections --resource-path=.:figures)
pandoc paper.md "${COMMON[@]}" --reference-doc reference.docx -o paper.docx
pandoc paper.md "${COMMON[@]}" --pdf-engine=pdflatex \
  -V documentclass=article -V papersize=a4 -V fontsize=10pt -V geometry:margin=2.3cm \
  -V linkcolor=teal -V citecolor=teal -V urlcolor=teal -V colorlinks=true \
  -H latex-header.tex -o paper.pdf
echo "built paper.docx and paper.pdf"
