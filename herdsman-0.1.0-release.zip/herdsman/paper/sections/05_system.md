# Herdsman: a referee for agents

We implemented the rolling seal as an open-source Python package, Herdsman, with a command-line interface and a Model Context Protocol (MCP) server so that any MCP-capable agent can work through it. Figure 1 shows the flow. This section describes the parts that matter for trust.

![Figure 1. The rolling seal with three sealed folds. In each episode the analyst can read the exploration set and every fold already spent; it explores and commits claims, each with its bar fixed at commit. Closing the episode opens one fresh fold once, multiplies the fold's e-value into the evidence of every open claim, and then releases the fold to the analyst.](figures/fig1_protocol.png){width=100%}

## Roles and keys

A study has two roles. The *data owner* creates it and holds a keys directory containing the vault key that decrypts sealed folds, the Ed25519 key that signs certificates, and the seed. The *analyst*, human or agent, opens the same study without keys. Through the analyst view it can read the exploration data and every spent fold, run logged exploratory tests, commit and withdraw claims, and read its budget, claims and certificates. It cannot open a fold. Only the referee view closes an episode. In hosted deployments the keys never leave the referee's infrastructure; locally, the separation is a matter of process and file permissions, which suffices against careless and motivated analysts but not against a user with administrative access to the same machine (Section 8).

## The vault

At creation the rows are shuffled with the study seed, or ordered by a time column, and split into the exploration set and $K$ folds. Each fold is serialised, hashed with SHA-256 and encrypted with Fernet (AES-128 in CBC mode with an HMAC-SHA256 tag). The fold hashes, the exploration hash and a salted hash of the seed are published in the study's parameters before anyone sees the data. When a fold is opened, its plaintext is checked against its commitment; when it is released, anyone can check it again. A referee therefore cannot quietly swap a fold for a more convenient one, and cannot re-draw the randomness behind the e-values after seeing the data.

Outcome bounds, which the e-values need, are taken from the data owner's declaration or, failing that, from the exploration set only. Sealed values outside the bounds are clipped, and the claim's estimand is then the mean of the clipped outcome.

## Claims and filters

A claim names an outcome, a population filter, a focal and a reference group (or a constant, for level claims), a direction, an optional margin, and a plain-English statement that plays no part in the statistics. Filters use a deliberately small language: column names, constants, comparisons, membership in a list, and the connectives *and*, *or* and *not*. They are parsed with Python's abstract-syntax-tree module against a whitelist of node types, so a filter can never call a function, read an attribute or execute code, which matters when the filter's author is a language model that may have read untrusted text. A row belongs to a group only if every column the filter mentions is observed for that row; rows matching both groups are dropped from both, so the two groups are disjoint by construction. Claims may also define a linear score over numeric columns and compare its high and low values, which is how risk-score claims are expressed.

At commit the referee validates the claim against the schema, rejects exact duplicates of open or certified claims, fixes the level $\alpha_t$ and the starting bet, and records everything in the ledger.

## The ledger

Every action is a record in an append-only JSON-lines ledger: study creation, each exploratory test with its specification and result, each commit with its level, each fold opening with its hash, each claim's evidence on each fold, each certification, each fold release, each certificate issued, and a final signed checkpoint. Each record contains the SHA-256 hash of its predecessor and its own hash over a canonical serialisation, so altering, deleting or reordering any record breaks every later hash. Verification recomputes the chain, checks released folds against their commitments, and checks every certificate's signature and its commit record.

By Corollary 2 the ledger is not what makes certificates valid. It is what makes the search visible. For each study the referee reports the number of exploratory tests, the number of hypothesis families they fall into, how many were significant at 5% against how many would be expected if every hypothesis were null, and how many survive Benjamini–Hochberg across the logged tests. Each certificate records how many exploratory tests, and how many in the claim's own family, preceded its commit. This is multiverse-style disclosure [@steegen2016increasing; @simonsohn2020specification] produced as a side effect of doing the analysis.

## Hypothesis families and the language model

How many questions did the analyst really ask? Counting tests overstates it, because one idea tested in fourteen subgroups is one question asked fourteen ways; counting distinct outcomes understates it. Herdsman separates the proposal of families from their accounting. A deterministic heuristic groups tests by outcome and grouping variables, ignoring subgroup, threshold and direction. Outside demo mode, a language model may instead read the specifications and statements and propose a partition; the referee checks that the answer is a valid partition and falls back to the heuristic if it is not. Families drive the disclosure tables and, when an analyst commits a family claim, which member e-values are averaged (Proposition 2). By Proposition 1 none of this can affect validity, and by design no number the referee reports passes through a language model.

## Two modes

*Rolling* mode is the protocol of Section 3 and the default. *Batch* mode is for teams that can pre-register a single confirmation: all claims are committed, one sealed fold is opened, and the batch is tested together with Benjamini–Yekutieli [@benjamini2001control] (valid under arbitrary dependence), Benjamini–Hochberg [@benjamini1995controlling] (under positive dependence) or e-BH [@wang2022false], using large-sample Welch tests for the p-value procedures. Batch mode is more powerful for one round; it offers no protection if the analyst comes back to the same fold, so the referee closes the study after its single fold is used.

## Certificates

A certified claim receives a signed JSON certificate containing the study's identity and parameter hash, the vault and seed commitments, the claim and its plain-English statement, the commit record's position and hash in the ledger, the level and threshold fixed at commit, the evidence on every fold, the disclosure counts, the ledger head at issue, and the guarantee in words. Anyone holding the referee's public key can verify a certificate offline; anyone holding the released data and the revealed seed can recompute its e-values.

## Agent interface

The MCP server exposes the analyst view as tools: a study brief (columns, outcomes, budget, claim format and rules), grouped descriptive summaries, logged exploratory tests, claim and family-claim commits, claim and budget status, certificates and search disclosure. The server's instructions tell the agent to report only certified claims as established and to describe others as unconfirmed. Closing an episode is not exposed unless the operator deliberately enables it, and even then the tool opens a fold without revealing anything the agent could use to evaluate an uncommitted claim on it.
