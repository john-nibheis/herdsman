# Evidence for analytical claims

The rolling seal needs, for each claim and each fold, an e-value that is exact in finite samples, makes no distributional assumption beyond bounded outcomes, and is powerful against the effects analysts actually report. We use testing by betting [@shafer2021testing; @waudbysmith2024estimating].

## Betting on a bounded mean

Consider centred observations $y_1,\dots,y_m$ that are independent with $\mathbb{E}[y_i]\le0$ under the null and $y_i\ge-b$. A bettor starts with unit wealth and stakes a fraction $\lambda_i\in[0,c/b]$, $c<1$, chosen from $y_1,\dots,y_{i-1}$ only:
$$
W_m=\prod_{i=1}^m\bigl(1+\lambda_iy_i\bigr).
$$
Each factor is at least $1-c>0$, and under the null $\mathbb{E}[1+\lambda_iy_i\mid y_{<i}]=1+\lambda_i\mathbb{E}[y_i]\le1$, so $W_m$ is an e-value. We use a Kelly-style plug-in,
$$
\lambda_i=\operatorname{clip}\left(\frac{S_{i-1}}{Q_{i-1}+v_0},\,0,\,\frac{c}{b}\right),\qquad S_{i-1}=s_0+\sum_{j<i}y_j,\quad Q_{i-1}=q_0+\sum_{j<i}y_j^2,
$$
which approximates the growth-optimal constant bet $\mathbb{E}[y]/\mathbb{E}[y^2]$, with $c=\tfrac12$ and $v_0=(U-L)^2/4$. The running sums continue across folds, so a claim's later bets learn from its earlier folds; this keeps the bet predictable and Assumption 1 intact.

## Two groups, one fold: blocking

A difference claim compares a focal group of size $n_f$ with a reference group of size $n_r$ in the fold. Because rows are independent draws from $P$, conditional on which rows fall into each group the focal outcomes are independent draws from the focal conditional distribution and likewise for the reference group, and the two sets are independent. We draw a random order of each group, match each unit of the smaller group with $r=\lfloor\max(n_f,n_r)/\min(n_f,n_r)\rfloor$ units of the larger group, and form block differences
$$
d_i=\bar Y^{\,\mathrm{foc}}_{(i)}-\bar Y^{\,\mathrm{ref}}_{(i)},\qquad i=1,\dots,\min(n_f,n_r),
$$
which are independent with mean exactly $\mu_f-\mu_r$ and lie in $[-(U-L),\,U-L]$. Betting on $y_i=\pm d_i-\delta_t$ (the sign follows the claimed direction) gives an e-value for $\mu_f-\mu_r\le\delta_t$ with $b=U-L+\delta_t$. Blocking uses almost all of both groups when they are unbalanced, which matters for subgroup claims, where a small treated cell is often compared with a large control cell.

The wealth depends on the random order. Any fixed order gives a valid e-value, and an average of e-values is an e-value, so the referee averages the wealth over $B=16$ orders generated from a committed seed. The seed's hash is published when the study is created and the seed is revealed when it closes, so anyone holding the data can recompute every e-value exactly. Validity does not require the seed to be secret; the commitment is for reproducibility.

Level claims, which compare a conditional mean with a constant, use the same bettor on the outcomes themselves.

## Starting bets from the exploration data

A plug-in bettor that starts from nothing wastes its first observations learning how much to stake. The analyst, however, has already estimated the effect on the exploration data. When a claim is committed the referee recomputes that estimate and enters it, halved to temper the winner's curse, as $k_0=100$ pseudo-observations:
$$
s_0=k_0\,\tfrac12\hat\theta^{\,\mathrm{exp}},\qquad q_0=k_0\bigl(\hat\sigma_d^{2}+(\tfrac12\hat\theta^{\,\mathrm{exp}})^2\bigr).
$$
The starting state is fixed at commit and is therefore $\mathcal{G}_{\kappa(t)}$-measurable; by Proposition 1 it cannot affect validity, however wrong it is. A misleading start costs the claim some wealth; a good one removes most of the learning cost. In our simulations the betting e-value with this start comes within {{eff_gap_informed}} nats of the oracle likelihood ratio $\exp(z^2/2)$ for effects of the size analysts report, against {{eff_gap_flat}} nats without it (Appendix C).

## What this costs

E-values pay for their robustness. A p-value test at level $\alpha_t$ needs roughly $z\ge\Phi^{-1}(1-\alpha_t)$; an e-value needs $\log E\ge\log(1/\alpha_t)$, and since a good bettor achieves $\log E\approx z^2/2-O(1)$, it needs roughly $z^2\gtrsim2\log(1/\alpha_t)+O(1)$. The two requirements agree to leading order as $\alpha_t\to0$, but at the levels used in practice the gap is material: at $\alpha_t=1/150$ a one-sided z-test needs $z\approx{{z_p_150}}$ where the e-value needs $z\approx{{z_e_150}}$. Section 6 measures the resulting loss of power. The rolling seal accepts it in exchange for validity that does not depend on the dependence between claims, on the analyst's behaviour, or on when anyone stops; batch mode (Section 5.6) offers ordinary p-values with Benjamini–Yekutieli when a single pre-registered confirmation is enough.
