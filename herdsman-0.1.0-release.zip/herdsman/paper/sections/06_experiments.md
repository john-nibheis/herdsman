# Simulation experiments

## Design

Each simulated study is a randomised experiment on {{sim_rows}} customers with a binary treatment, six categorical covariates (between three and six levels each) and three binary outcomes. Treatment effects live only in *effect regions*, conjunctions of one or two covariate levels, and are always positive. A claim "the treatment raises outcome $o$ in subgroup $S$" is therefore true exactly when $S$ overlaps an effect region for $o$, and every claim of a decrease is false, so the truth of every claim is known without estimation error. We use three worlds: a *global null* with no effects; a *sparse* world with one single-level and one two-level region; and a *dense* world with three of each. Effect sizes are drawn per study, from 3 to 6 points for single-level regions and 8 to 15 points for two-level regions, on baseline rates between 12% and 55%.

Each study is split into {{sim_explore_pct}} exploration data and three sealed folds. Scripted analysts search the exploration data and commit their strongest results, in the direction observed:

- the *diligent* analyst tests every outcome overall and in every single-covariate subgroup ({{tests_diligent}} tests) and commits its ten strongest results;
- the *forking-paths* analyst adds every two-covariate subgroup ({{tests_forking}} tests) and commits fifteen;
- the *pressured* analyst behaves like the forking-paths analyst but, if it has fewer than eight results with $p<0.01$, widens its search to three-covariate subgroups ({{tests_pressured}} tests on average in the null world) before committing fifteen;
- the *adaptive* analyst works over three episodes. In each it re-runs the forking-paths search on everything it can read, including folds already spent and released, and commits its ten strongest results not yet committed.

We compare what each analyst would report unrefereed (its committed results with exploratory $p<0.05$) with conventional safeguards applied to the same committed claims: testing each on the full holdout at $p<0.05$; Bonferroni, Benjamini–Hochberg and Benjamini–Yekutieli on the holdout p-values at 10%; e-BH on betting e-values computed on the full holdout; and Benjamini–Hochberg at 10% across every logged exploratory test. The rolling seal uses e-LOND at $\alpha=10\%$ with a uniform horizon equal to the number of claims the analyst will commit, starting bets from the exploration data, and 16 orderings per e-value. Every method sees the same data and claims within a study. We ran {{sim_reps}} studies per world, {{sim_studies}} in all.

## False discoveries and power

Table 1 and Figure 2 report the false discovery rate. In the global null, where every claim is false, the false discovery rate equals the probability of certifying anything. Unrefereed reports contained at least one false finding in {{null_naive_diligent}} of studies for the diligent analyst and in {{null_naive_forking}} for the forking-paths and pressured analysts, which reported {{null_false_forking}} false findings per study on average. Testing each committed claim on a holdout at $p<0.05$ cut that to {{null_holdout_p05_forking}}, which is still a false finding in half of all null studies. Holdout Benjamini–Hochberg, Bonferroni and Benjamini–Yekutieli all stayed near or below 10%, as they should for a single round of pre-committed claims. Benjamini–Hochberg across the logged exploratory tests ran at {{null_explore_bh_pressured}} for the pressured analyst, slightly above nominal, consistent with a search that widens itself when results disappoint. The rolling seal's false discovery rate was at most {{max_fdr_rolling}} in every world and for every analyst, including the adaptive analyst, which re-explored released folds before each round of claims.

![Figure 2. False discovery rate for the forking-paths analyst, with 95% intervals, in the global null and the sparse world ({{sim_reps}} simulated studies per world). The dashed line is α = 10%.](figures/fig2_validity.png){width=100%}

{{table_validity}}

Figure 3 and Table 2 show what this costs. In the sparse world the forking-paths analyst committed {{sparse_committed_true}} true claims per study on average. Holdout Benjamini–Hochberg certified {{sparse_true_bh}} of them, Benjamini–Yekutieli (our batch mode) {{sparse_true_by}}, holdout e-BH {{sparse_true_ebh}}, and the rolling seal {{sparse_true_rolling}}, or {{sparse_share_rolling}} of the true claims committed against {{sparse_share_bh}} for holdout Benjamini–Hochberg. In the dense world the corresponding shares were {{dense_share_rolling}} and {{dense_share_bh}}. Starting bets from the exploration data raised the rolling seal's certifications by {{prior_gain_sparse}} in the sparse world and {{prior_gain_dense}} in the dense world without any change in false discoveries. The adaptive analyst, which spread thirty claims over three episodes, had {{adaptive_true_sparse}} true claims certified per sparse study, with a false discovery rate of {{adaptive_fdr_sparse}}, against an unrefereed false discovery rate of {{adaptive_naive_fdr_sparse}}.

![Figure 3. True and false claims certified per study by each method for the forking-paths analyst. The dashed line is the mean number of true claims the analyst committed.](figures/fig3_power.png){width=100%}

{{table_power}}

The comparison flatters the holdout methods in one respect: they are valid here because our scripted analysts commit once and never look at the holdout. The next experiment shows what happens when an analyst does look.

## Re-using a holdout

We reproduced the attack behind the reusable holdout [@dwork2015reusable] against a referee that keeps one holdout. In each of {{leak_reps}} studies, 200 noise features and a binary outcome are all independent. The analyst first commits 200 claims, one per feature, that observations above zero on the feature have a higher outcome rate, each in the direction suggested by the exploration data. It then reads what the referee releases about those claims and commits a 201st claim: that a score summing the features, signed by what it learned, predicts the outcome. The composite claim is false by construction. The referee runs e-LOND with 201 slots, so the composite needs an e-value of {{leak_threshold}}.

When the re-used holdout released per-claim estimates, the composite was certified in {{leak_estimates_cert}} of studies and passed a conventional holdout test at $p<0.05$ in {{leak_estimates_naive}} (Figure 4). Releasing only whether each claim's evidence had grown ($e>1$) let the analyst build a weaker score from {{leak_bits_features}} features on average; e-LOND then certified it in {{leak_bits_cert}} of studies, but a conventional holdout test still declared it significant in {{leak_bits_naive}}. Releasing only certification decisions leaked nothing usable in this attack, as Proposition 3(a) suggests. Under the rolling seal the analyst received the spent fold *in full* and built its score from everything it had seen; the composite, tested on the next fold, was certified in {{leak_rolling_cert}} of studies and passed $p<0.05$ in {{leak_rolling_naive}}, the nominal rate.

![Figure 4. The holdout re-use attack. Left: evidence for the composite claim, false by construction, under each referee; the dashed line is the evidence e-LOND required. Right: how often the composite was certified, and how often it passed a conventional holdout test at p < 0.05.](figures/fig4_leakage.png){width=100%}

{{table_leakage}}

## Allocation, budget shape and episodes

Figure 5 varies the share of data kept for exploration from 20% to 70% for the forking-paths analyst. More exploration data lets the analyst choose better claims; less leaves more sealed data to confirm them. The two pull in opposite directions, and they balance differently for different methods. In the sparse world the rolling seal certified the most true claims with {{alloc_best_rolling}} of the data kept for exploration ({{alloc_best_rolling_true}} per study), and its yield fell steadily beyond that, to {{alloc_rolling_70}} at 70%; holdout Benjamini–Hochberg peaked at {{alloc_best_bh}} ({{alloc_best_bh_true}} per study). Stricter evidence needs more confirmation data, so a rolling-seal study should keep more of its data sealed than a single-holdout study would.

![Figure 5. Left and centre: share of the true committed claims that were certified as the share of data kept for exploration varies. Right: true claims certified per study under four budget shapes.](figures/fig5_allocation.png){width=100%}

The shape of the budget matters too. With fifteen claims, a uniform horizon of fifteen slots certified {{budget_u15_sparse}} true claims per sparse study; a horizon of fifty, two-thirds of it unused, certified {{budget_u50_sparse}}; the infinite-horizon decaying sequence certified {{budget_decay_sparse}}; a front-loaded sequence that favours the analyst's first, strongest claims certified {{budget_h15_sparse}}. In no setting of this section did the rolling seal's false discovery rate exceed {{budget_max_fdr}}.

Figure 6 splits thirty claims over two to six episodes, one fold per episode. Carrying each claim's evidence across later folds is what makes many episodes affordable. With three folds the adaptive analyst had {{episodes_acc_k3_sparse}} true claims certified per sparse study when evidence accumulated, against {{episodes_one_k3_sparse}} when each claim was judged on the single fold opened after it was committed; with six folds the figures were {{episodes_acc_k6_sparse}} and {{episodes_one_k6_sparse}}. With accumulation, the number of episodes barely mattered ({{episodes_acc_range_sparse}} true certifications per sparse study from two to six episodes), so analysts can iterate as often as they like at little cost in power.

![Figure 6. True claims certified per study for the adaptive analyst as thirty claims are spread over more episodes, with each claim's evidence accumulated across later folds or judged on the single fold opened after it was committed.](figures/fig6_episodes.png){width=72%}

## Overhead

{{overhead_sentence}}
