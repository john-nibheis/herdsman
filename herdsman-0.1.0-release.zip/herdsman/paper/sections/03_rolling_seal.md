# The rolling seal

## Setting

Rows of data are independent draws from a population distribution $P$. Before anyone looks, the referee splits the available rows at random into an exploration set $D_0$ and $K$ sealed folds $F_1,\dots,F_K$. Conditional on their sizes these are independent samples from $P$, and they are independent of the analyst's internal randomness $U$ and of the referee's seed $S$.

The analyst is any procedure, human or machine, deterministic or random. It works in *episodes*. During episode $k$ it may use everything in
$$
\mathcal{G}_k=\sigma\bigl(D_0,F_1,\dots,F_{k-1},U,S\bigr),
$$
that is, the exploration data, every fold already spent, its own randomness, and anything the referee has released, all of which are functions of these. Nothing restricts how it explores, how many tests it runs, in what order it commits claims, or whether it revisits earlier decisions. We do not even require that its exploration is logged.

A *claim* $H_t$ is a one-sided statement about a functional of $P$. For a difference claim it reads
$$
H_t:\ \theta_t(P)=\mathbb{E}_P[Y\mid Z\in A_{\mathrm{pop}}\cap A_{\mathrm{foc}}\setminus A_{\mathrm{ref}}]-\mathbb{E}_P[Y\mid Z\in A_{\mathrm{pop}}\cap A_{\mathrm{ref}}\setminus A_{\mathrm{foc}}]\ \le\ \delta_t ,
$$
where $Z$ is a row, $Y\in[L,U]$ is a bounded outcome and the sets $A$ are the population, focal and reference filters. The claim the analyst wants certified is the alternative, $\theta_t>\delta_t$; level claims compare a single conditional mean with a constant. We say $H_t$ is *true* when the claim is false: certifying it would be a false discovery. Claim $t$ is committed during episode $\kappa(t)$, so its specification, together with anything the referee fixes at commit (its level, its starting bet, its family), is $\mathcal{G}_{\kappa(t)}$-measurable.

## The protocol

When claim $t$ is committed, the referee counts the claims already certified, $D_t$, and fixes the level
$$
\alpha_t=\min\{\alpha,\ \alpha\,\gamma_t\,(D_t+1)\},\qquad \gamma_t\ge 0,\quad \textstyle\sum_t\gamma_t\le 1 .
$$
This is e-LOND [@xu2024online]. When episode $k$ closes, the referee opens fold $F_k$ for the first and only time. Every open claim with $\kappa(t)\le k$ receives an e-value $E_t^{(k)}$ computed on $F_k$ alone, possibly using a state carried over from earlier folds, and its running evidence becomes
$$
M_t^{(k)}=\prod_{j=\kappa(t)}^{k}E_t^{(j)} .
$$
Claim $t$ is certified at the first fold for which $M_t^{(k)}\ge 1/\alpha_t$. The fold is then *spent*: it is released to the analyst, and no claim committed afterwards is ever evaluated on it. Open claims keep accumulating evidence on later folds until they are certified, withdrawn, or the folds run out.

The per-fold e-values must satisfy one property.

**Assumption 1 (conditional validity).** For every claim $t$ and fold $k\ge\kappa(t)$, on the event that $H_t$ is true, $\mathbb{E}\bigl[E_t^{(k)}\mid\mathcal{G}_k\bigr]\le 1$.

Assumption 1 holds whenever $E_t^{(k)}=e(F_k;\,H_t,\xi)$ for an evidence function $e$ that is an e-value for $H_t$ for every fixed specification and every fixed auxiliary input $\xi$ (betting state, starting bet, seed), and $\xi$ is $\mathcal{G}_k$-measurable. Because $F_k$ is independent of $\mathcal{G}_k$, the conditional expectation is then the unconditional expectation of a valid e-value with its inputs frozen. Section 4 gives evidence functions with this property.

## Guarantee

**Lemma 1 (each claim is an e-process over folds).** On the event that $H_t$ is true, $(M_t^{(k)})_{k\ge\kappa(t)-1}$ with $M_t^{(\kappa(t)-1)}=1$ is a non-negative supermartingale with respect to $(\mathcal{G}_{k+1})_k$. Consequently
$$
\mathbb{P}\left(\max_{k}M_t^{(k)}\ge 1/\alpha_t\ \middle|\ \mathcal{G}_{\kappa(t)}\right)\le\alpha_t\quad\text{on }\{H_t\text{ true}\}.
$$

*Proof.* $M_t^{(k)}=M_t^{(k-1)}E_t^{(k)}$ with $M_t^{(k-1)}$ measurable with respect to $\mathcal{G}_k$, so $\mathbb{E}[M_t^{(k)}\mid\mathcal{G}_k]=M_t^{(k-1)}\,\mathbb{E}[E_t^{(k)}\mid\mathcal{G}_k]\le M_t^{(k-1)}$ by Assumption 1. The event $\{H_t\text{ true}\}$ and the level $\alpha_t$ are $\mathcal{G}_{\kappa(t)}$-measurable, so Ville's inequality [@ville1939etude] applied conditionally on $\mathcal{G}_{\kappa(t)}$ gives the bound. $\square$

**Theorem 1 (false discovery control under arbitrary adaptivity).** Let $\mathcal{R}$ be the set of certified claims and $V=\#\{t\in\mathcal{R}: H_t\text{ true}\}$. Under Assumption 1,
$$
\mathrm{FDR}=\mathbb{E}\left[\frac{V}{|\mathcal{R}|\vee 1}\right]\le\alpha ,
$$
for every analyst, every way of choosing, ordering, revising or withdrawing claims, and every dependence between claims.

*Proof.* If $t$ is certified, then every claim certified before $t$ was committed is also in $\mathcal{R}$, so $|\mathcal{R}|\ge D_t+1$. Hence
$$
\frac{V}{|\mathcal{R}|\vee1}=\sum_t\frac{\mathbf{1}\{t\in\mathcal{R},\,H_t\text{ true}\}}{|\mathcal{R}|}\le\sum_t\frac{\mathbf{1}\{t\in\mathcal{R},\,H_t\text{ true}\}}{D_t+1}.
$$
Taking expectations and conditioning each term on $\mathcal{G}_{\kappa(t)}$, Lemma 1 gives
$$
\mathbb{E}\left[\frac{\mathbf{1}\{t\in\mathcal{R},H_t\text{ true}\}}{D_t+1}\right]\le\mathbb{E}\left[\frac{\mathbf{1}\{H_t\text{ true}\}\,\alpha_t}{D_t+1}\right]\le\alpha\,\gamma_t ,
$$
and summing over $t$ gives $\mathrm{FDR}\le\alpha\sum_t\gamma_t\le\alpha$. Claims that are withdrawn, expire, or are never committed contribute nothing. $\square$

The argument is the e-LOND proof of @xu2024online, and its ingredients are theirs: their doubly sequential setting already lets each hypothesis's evidence be a stopped e-process, and their asynchronous e-LOND fixes each level when a hypothesis is launched, counting only decisions already made. What the rolling seal contributes is a data design under which Assumption 1 holds for an analyst who has seen everything released so far: each fold is opened once, after every claim it judges was committed, and is shared by all open claims rather than set aside for one. Nothing in the proof refers to how the analyst behaved before committing, which is why the guarantee survives an analyst we cannot model. The bound also holds at any closing time. Let $\tau$ be the time at which the study is closed, possibly chosen after seeing results, and $\mathcal{R}_\tau$ the claims certified by then. For $t\in\mathcal{R}_\tau$ we still have $|\mathcal{R}_\tau|\ge D_t+1$, because the $D_t$ claims certified before $t$ was committed are in $\mathcal{R}_\tau$ too, and $\mathbf{1}\{t\in\mathcal{R}_\tau\}\le\mathbf{1}\{\max_k M_t^{(k)}\ge 1/\alpha_t\}$, because a claim is certified only when its running evidence reaches its bar. The display in the proof therefore holds with $\mathcal{R}_\tau$ in place of $\mathcal{R}$, and Lemma 1, which bounds the probability that the evidence *ever* reaches the bar, bounds each term as before.

One assumption is implicit in Assumption 1. Before a fold is opened, the analyst can see its published SHA-256 commitment, which is a function of the fold's contents, so the information $\mathcal{G}$ formally includes it. Our guarantee treats the commitment as uninformative, which holds computationally: no analyst can recover anything useful about 9,600 rows from their hash. A deployment that wants the statement to hold without a computational assumption can commit to a salted hash and reveal each salt when its fold is opened.

**Corollary 1 (releasing spent folds is free).** The guarantee is unchanged if, after episode $k$, the analyst receives $F_k$ in full. Spent folds can therefore be returned to the exploration pool, so no data are wasted on confirmation alone.

*Proof.* $\mathcal{G}_{k+1}$ already contains $F_k$. $\square$

**Corollary 2 (validity comes from sealing, not surveillance).** Theorem 1 does not use the exploration ledger. Logging the search is for disclosure and audit; an analyst that explores off the record cannot weaken the guarantee, provided it cannot read unspent folds.

**Proposition 1 (commit-time choices are free).** Any quantity fixed from $\mathcal{G}_{\kappa(t)}$ — a margin $\delta_t$, a starting bet built from the exploration estimate, the grouping of members into a family claim, or a data-dependent budget share $\gamma_t$ provided $\sum_t\gamma_t\le1$ on every path — leaves Theorem 1 intact.

*Proof.* Each enters the proof only through $\mathcal{G}_{\kappa(t)}$-measurable quantities: the evidence function's frozen inputs in Assumption 1, or $\gamma_t$, which can be moved inside the conditional expectation, giving $\mathrm{FDR}\le\alpha\,\mathbb{E}[\sum_t\gamma_t]\le\alpha$. $\square$

This is the formal sense in which a language model can be *in the loop but not in the guarantee*. A model may parse a plain-English finding into a claim, propose which tests belong to one hypothesis family, or suggest which members to pool, and a poor proposal can cost power or clarity. It cannot cost validity, because everything it proposes is fixed before the sealed fold it will be judged on is opened.

**Proposition 2 (family claims).** Let $e_1,\dots,e_m$ be per-fold e-values for $H_{t,1},\dots,H_{t,m}$, arbitrarily dependent, and let $w$ be weights fixed at commit with $\sum_i w_i=1$. Then $\sum_i w_ie_i$ is an e-value for the intersection null $\bigcap_iH_{t,i}$. Certifying the family claim therefore establishes that at least one member effect is real, at the cost of one claim slot.

*Proof.* Under the intersection null each $\mathbb{E}[e_i\mid\mathcal{G}_k]\le1$; average. $\square$

## Why the fold must be fresh

Re-using a holdout after releasing anything about it breaks every guarantee of this kind, and the break is not subtle.

**Proposition 3 (re-use and transcripts).** (a) Suppose a fold $F$ is used to evaluate claim $t$ after a transcript $\tau(F)$ of earlier results on $F$ has been released, where $\tau$ takes at most $N$ values. Then $E_t/N$ is a valid e-value; without the deflation, $\mathbb{E}[E_t]$ can be as large as $N$. (b) If continuous statistics such as estimates are released, $N$ is unbounded, and there are analysts whose re-used e-values exceed any threshold with probability tending to one under the global null.

*Proof.* (a) Write $H(\tau)$ for the claim the analyst would commit after seeing transcript value $\tau$; for fixed $\tau$ it is a function of $D_0,U$ and $\tau$ only, hence independent of $F$. Then $\mathbb{E}[E_t\mathbf{1}\{H_t\text{ true}\}]=\mathbb{E}\bigl[\sum_\tau\mathbf{1}\{\tau(F)=\tau\}\,e(F;H(\tau))\mathbf{1}\{H(\tau)\text{ true}\}\bigr]\le\sum_\tau\mathbb{E}\bigl[e(F;H(\tau))\mathbf{1}\{H(\tau)\text{ true}\}\bigr]\le N$. (b) Take $d$ independent noise features and an outcome independent of all of them. Release the sign of each feature's estimated association on $F$, then claim that the score $\sum_j\mathrm{sign}(\hat z_j)x_j$ predicts the outcome. On $F$ the score's standardised association is approximately $d^{-1/2}\sum_j|\hat z_j|\approx\sqrt{2d/\pi}$, which grows without bound, and so does any consistent e-value computed on $F$. $\square$

Part (b) is the classic construction behind the reusable holdout [@dwork2015reusable]; Section 6.3 reproduces it against an e-LOND referee that re-uses its holdout, and against the rolling seal. Part (a) explains a subtler finding there: releasing only certification decisions leaks little in practice, because almost every decision is "not certified" and the transcript carries few effective bits. The rolling seal needs no such argument: it never asks a fold to judge a claim that was formed after anything about that fold was seen.

## Choosing the budget shape

Theorem 1 holds for any $\gamma$ with $\sum_t\gamma_t\le1$, but power depends heavily on the shape. A *uniform horizon*, $\gamma_t=1/N$ for $t\le N$, spends the budget evenly over $N$ claim slots; the first claim needs $e\ge N/\alpha$, and every certification lowers the bar for later claims through the $(D_t+1)$ factor. The infinite-horizon sequence of @javanmard2018online never runs out but places only a few per cent of the budget on any early claim. Section 6.4 shows that matching $N$ to the number of claims an analysis will actually make is, with the share of data kept for exploration (Section 6.4), one of the two choices that matter most: unused slots are unused power.
