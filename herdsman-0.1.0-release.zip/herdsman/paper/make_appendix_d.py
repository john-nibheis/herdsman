"""Writes appendix/D_case_study.md from the exact texts used in the case study."""
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[0] / "experiments"))
import casestudy as CS  # noqa: E402

brief = (CS.ROOT / "runs" / "N1" / "workspace" / "brief.md").read_text()
brief_generic = brief.replace(CS.PERSONAS["neutral"], "[persona paragraph]")
messages = (HERE.parents[0] / "experiments" / "casestudy_messages.md").read_text()
messages = messages.split("\n", 1)[1]  # drop the file's own title
messages_fixed = "\n".join((l + " {.unnumbered}") if l.startswith("## Phase") else l for l in messages.splitlines()).replace("## Phase", "### Phase")
messages_fixed = messages_fixed.split("(The phase-3 message is generated")[0].rstrip()

lines = [
    "# Appendix D. Case-study materials {.unnumbered}",
    "",
    "Each analyst was an independent instance of the same agent, given only the instruction to read `brief.md` in its workspace and follow it, to work only inside that folder, to use the helper module for hypothesis tests and to keep to roughly forty tool calls. The workspace held the exploration data, a data dictionary generated from the column descriptions, the brief and the helper module. The data generator, the oracle, the sealed folds and the referee's keys were outside the workspace.",
    "",
    "The messages below are reproduced verbatim and refer to the referee by its working name at the time, Buachaille; the certificates and ledgers from the case study carry that name in their format fields for the same reason.",
    "",
    "## Persona paragraphs {.unnumbered}",
    "",
]
LABELS = {"neutral": "Neutral", "pressured": "Pressured", "sceptical": "Sceptical", "segment_hunt": "Segment-hunting"}
for name, text in CS.PERSONAS.items():
    lines.append(f"*{LABELS.get(name, name)}.* {text}")
    lines.append("")
lines += [
    "## The brief (persona paragraph elided) {.unnumbered}",
    "",
    "\n".join(("> **" + l.lstrip("#").strip() + "**") if l.startswith("#") else ("> " + l if l.strip() else ">") for l in brief_generic.strip().splitlines()),
    "",
    "## Messages after phase 1 {.unnumbered}",
    "",
    messages_fixed,
    "",
    "## Worlds and oracle {.unnumbered}",
    "",
    "The *standard* world contains the effects described in Section 7.1. In the *no-wins* world, generated with the same seed, journey B has no effect on completion or journey time (and hence none on funding); its harm to broker arrears and all arrears drivers are unchanged. For each world the oracle draws 300,000 independent applications from the generator and, for each application and each journey, enumerates the three completion and funding states with their probabilities; a claim's true value is the weighted difference in expected outcomes between its focal and reference groups, which is exact in expectation and free of outcome noise. Claims whose filters condition on arrears or journey time are not scored. A claim counts as true if its true value in the claimed direction exceeds its margin by at least 0.002 (0.2 minutes for journey time), so negligible effects count against the analyst; with a negative margin, which several agents used for non-inferiority claims, the same rule requires the true effect in the opposite direction to fall short of the margin's size by that tolerance. Findings that an analyst reported with p ≥ 0.05, which the agents used to report the absence of an effect, are scored as null findings: correct if the true effect lies within that tolerance of zero.",
]
(HERE / "appendix" / "D_case_study.md").write_text("\n".join(lines) + "\n")
print("appendix/D_case_study.md written")
