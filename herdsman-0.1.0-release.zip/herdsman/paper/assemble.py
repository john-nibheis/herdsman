"""Assembles paper.md from the section files, filling every {{placeholder}} from results.

No number in the paper is typed by hand: each placeholder below is computed from the
results files written by the experiment scripts. The build fails if a placeholder is
missing or unused.
"""
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

import pandas as pd

from results_lib import AGENT_LABELS, METHOD_LABELS, RESULTS, load, md_table, num, pct

HERE = Path(__file__).resolve().parent
V: dict[str, str] = {}


def validity():
    s = load("validity_summary.csv")
    raw = load("validity_raw.csv")
    g = lambda w, a, m: s[(s.world == w) & (s.agent == a) & (s.method == m)].iloc[0]
    V["sim_rows"] = "40,000"
    V["sim_explore_pct"] = "40%"
    V["sim_reps"] = f"{int(g('global_null', 'forking', 'herdsman')['reps']):,}"
    V["sim_studies"] = f"{raw[['world', 'rep']].drop_duplicates().shape[0]:,}"
    V["tests_diligent"] = f"{g('global_null', 'diligent', 'herdsman')['mean_tests']:.0f}"
    V["tests_forking"] = f"{g('global_null', 'forking', 'herdsman')['mean_tests']:.0f}"
    V["tests_pressured"] = f"{g('global_null', 'pressured', 'herdsman')['mean_tests']:,.0f}"
    V["null_naive_any_false"] = f"{pct(g('global_null', 'diligent', 'naive_report')['P_any_false'])} to {pct(g('global_null', 'forking', 'naive_report')['P_any_false'])}"
    V["null_naive_diligent"] = pct(g("global_null", "diligent", "naive_report")["P_any_false"])
    V["null_naive_forking"] = pct(g("global_null", "forking", "naive_report")["P_any_false"])
    V["null_false_forking"] = num(g("global_null", "forking", "naive_report")["mean_false"], 1)
    V["null_holdout_p05_forking"] = pct(g("global_null", "forking", "holdout_p05")["FDR"])
    pr = g("global_null", "pressured", "explore_bh")
    V["null_explore_bh_pressured"] = f"{pct(pr['FDR'], 1)} (standard error {pct(pr['FDR_se'], 1)})"
    rolling = s[s.method == "herdsman"]
    V["max_fdr_rolling"] = pct(rolling["FDR"].max(), 1)
    V["n_episodes"] = "three"
    sp = lambda m: g("sparse", "forking", m)
    dn = lambda m: g("dense", "forking", m)
    V["sparse_committed_true"] = num(sp("herdsman")["mean_committed_true"], 1)
    V["sparse_true_bh"] = num(sp("holdout_bh")["mean_true"], 1)
    V["sparse_true_by"] = num(sp("holdout_by")["mean_true"], 1)
    V["sparse_true_ebh"] = num(sp("single_seal_ebh")["mean_true"], 1)
    V["sparse_true_rolling"] = num(sp("herdsman")["mean_true"], 1)
    V["sparse_share_rolling"] = pct(sp("herdsman")["share_true_claims_certified"])
    V["sparse_share_bh"] = pct(sp("holdout_bh")["share_true_claims_certified"])
    V["dense_share_rolling"] = pct(dn("herdsman")["share_true_claims_certified"])
    V["dense_share_bh"] = pct(dn("holdout_bh")["share_true_claims_certified"])
    V["prior_gain_sparse"] = pct(sp("herdsman")["mean_true"] / sp("herdsman_flat_prior")["mean_true"] - 1)
    V["prior_gain_dense"] = pct(dn("herdsman")["mean_true"] / dn("herdsman_flat_prior")["mean_true"] - 1)
    ad = g("sparse", "adaptive_3_episodes", "herdsman")
    V["adaptive_true_sparse"] = num(ad["mean_true"], 1)
    V["adaptive_fdr_sparse"] = pct(ad["FDR"], 1)
    V["adaptive_naive_fdr_sparse"] = pct(g("sparse", "adaptive_3_episodes", "naive_report")["FDR"])

    order = ["naive_report", "holdout_p05", "explore_bh", "holdout_bh", "holdout_bonferroni", "holdout_by", "single_seal_ebh", "herdsman"]
    agents = ["diligent", "forking", "pressured", "adaptive_3_episodes"]
    rows = []
    for m in order:
        row = {"Method": METHOD_LABELS[m]}
        for a in agents:
            hit = s[(s.world == "global_null") & (s.agent == a) & (s.method == m)]
            row[AGENT_LABELS[a]] = "—" if hit.empty else f"{100 * hit.iloc[0]['FDR']:.1f} ({100 * hit.iloc[0]['FDR_se']:.1f})"
        rows.append(row)
    V["table_validity"] = (
        md_table(pd.DataFrame(rows), widths=[30, 14, 14, 14, 16])
        + "\n\n: Table 1. False discovery rate, in per cent (standard error), in the global null, where every claim is false. "
        f"{V['sim_reps']} simulated studies per cell. Holdout methods test the analyst's committed claims once on all sealed data; "
        "the adaptive analyst exists only under the rolling seal and unrefereed."
    )
    rows = []
    for m in ["naive_report", "holdout_p05", "holdout_bh", "holdout_by", "single_seal_ebh", "herdsman", "herdsman_flat_prior"]:
        r1, r2 = g("sparse", "forking", m), g("dense", "forking", m)
        rows.append(
            {
                "Method": METHOD_LABELS[m],
                "Sparse: FDR %": f"{100 * r1['FDR']:.1f}",
                "Sparse: true certified": f"{r1['mean_true']:.2f}",
                "Sparse: share of true claims": pct(r1["share_true_claims_certified"]),
                "Dense: FDR %": f"{100 * r2['FDR']:.1f}",
                "Dense: true certified": f"{r2['mean_true']:.2f}",
                "Dense: share of true claims": pct(r2["share_true_claims_certified"]),
            }
        )
    V["table_power"] = (
        md_table(pd.DataFrame(rows), widths=[26, 9, 10, 11, 9, 10, 11])
        + f"\n\n: Table 2. Forking-paths analyst, fifteen claims per study. 'Share of true claims' is the mean, over studies with at least one true claim committed, of true certifications divided by true claims committed ({V['sparse_committed_true']} per sparse study, {num(dn('herdsman')['mean_committed_true'], 1)} per dense study). The analyst's report counts every committed claim with exploratory p < 0.05."
    )


def leakage():
    s = load("leakage_summary.csv").set_index("arm")
    V["leak_reps"] = f"{int(s.loc['rolling/full', 'reps']):,}"
    V["leak_threshold"] = f"{201 / 0.10:,.0f}"
    V["leak_estimates_cert"] = pct(s.loc["reuse/estimates", "false_certification_rate"])
    V["leak_estimates_naive"] = pct(s.loc["reuse/estimates", "naive_holdout_p05_rate"])
    V["leak_bits_features"] = num(s.loc["reuse/bits", "mean_features_used"], 1)
    V["leak_bits_cert"] = f"{pct(s.loc['reuse/bits', 'false_certification_rate'], 1)} (standard error {pct(s.loc['reuse/bits', 'false_certification_se'], 1)})"
    V["leak_bits_naive"] = pct(s.loc["reuse/bits", "naive_holdout_p05_rate"])
    V["leak_rolling_cert"] = pct(s.loc["rolling/full", "false_certification_rate"])
    V["leak_rolling_naive"] = pct(s.loc["rolling/full", "naive_holdout_p05_rate"], 1)
    labels = {
        "reuse/estimates": "Re-used holdout; per-claim estimates released",
        "reuse/bits": "Re-used holdout; only 'e > 1' bits released",
        "reuse/certified": "Re-used holdout; only certification decisions released",
        "rolling/full": "Rolling seal; spent fold released in full",
    }
    rows = []
    for arm, label in labels.items():
        r = s.loc[arm]
        rows.append(
            {
                "Referee": label,
                "Features in composite": f"{r['mean_features_used']:.1f}",
                "Median log10 e": f"{r['median_log10_e']:.2f}",
                "Certified by e-LOND": pct(r["false_certification_rate"], 1),
                "Holdout p < 0.05": pct(r["naive_holdout_p05_rate"], 1),
            }
        )
    V["table_leakage"] = (
        md_table(pd.DataFrame(rows), widths=[34, 12, 12, 12, 12])
        + f"\n\n: Table 3. The holdout re-use attack, {V['leak_reps']} null studies. The composite claim is false in every study."
    )


def power():
    s = load("power_summary.csv")
    a = s[s.part == "A"].copy()
    a["setting"] = a["setting"].astype(float)
    sp = a[a.world == "sparse"]
    roll = sp[sp.method == "herdsman"].sort_values("mean_true")
    bhm = sp[sp.method == "holdout_bh"].sort_values("mean_true")
    V["alloc_best_rolling"] = pct(roll.iloc[-1]["setting"])
    V["alloc_best_rolling_true"] = num(roll.iloc[-1]["mean_true"], 1)
    V["alloc_rolling_70"] = num(roll[roll.setting == 0.7].iloc[0]["mean_true"], 1)
    V["alloc_best_bh"] = pct(bhm.iloc[-1]["setting"])
    V["alloc_best_bh_true"] = num(bhm.iloc[-1]["mean_true"], 1)
    b = s[s.part == "B"].set_index(["world", "setting"])
    V["budget_u15_sparse"] = num(b.loc[("sparse", "uniform_15"), "mean_true"], 2)
    V["budget_u50_sparse"] = num(b.loc[("sparse", "uniform_50"), "mean_true"], 2)
    V["budget_decay_sparse"] = num(b.loc[("sparse", "decaying"), "mean_true"], 2)
    V["budget_h15_sparse"] = num(b.loc[("sparse", "harmonic_15"), "mean_true"], 2)
    V["budget_max_fdr"] = pct(s[s.method == "herdsman"]["FDR"].max(), 1)
    c = s[(s.part == "C") & (s.world == "sparse")].set_index("setting")
    V["episodes_acc_k3_sparse"] = num(c.loc["K=3, accumulate", "mean_true"], 1)
    V["episodes_one_k3_sparse"] = num(c.loc["K=3, one-shot", "mean_true"], 1)
    V["episodes_acc_k6_sparse"] = num(c.loc["K=6, accumulate", "mean_true"], 1)
    V["episodes_one_k6_sparse"] = num(c.loc["K=6, one-shot", "mean_true"], 1)
    acc = c[c.index.str.contains("accumulate")]["mean_true"]
    V["episodes_acc_range_sparse"] = f"{acc.min():.1f} to {acc.max():.1f}"


def efficiency():
    e = load("efficiency.csv")
    V["eff_gap_informed"] = f"{e['gap_informed'].min():.1f}–{e['gap_informed'].max():.1f}"
    lev = load("levels.csv").set_index("slots")
    V["eff_gap_flat"] = f"{e['gap_flat'].min():.1f}–{e['gap_flat'].max():.1f}"
    V["eff_gap_closed"] = pct(((e["gap_flat"] - e["gap_informed"]) / e["gap_flat"]).mean())
    rows = [
        {
            "Group size": f"{int(r.n_per_group):,}",
            "Effect": f"{100 * r.effect:.0f} points",
            "Mean z": f"{r.mean_z:.2f}",
            "Oracle log LR": f"{r.oracle_log_lr:.2f}",
            "log e, flat start": f"{r.log_e_flat:.2f}",
            "log e, informed start": f"{r.log_e_informed:.2f}",
            "Gap (informed)": f"{r.gap_informed:.2f}",
        }
        for r in e.itertuples()
    ]
    V["table_efficiency"] = md_table(pd.DataFrame(rows)) + "\n\n: Table C1. Mean over 200 replications; baseline rate 30%. Gaps are in nats."
    rows = [
        {
            "Claim slots": int(k),
            "Level α_t": f"{r.alpha_t:.4f}",
            "Evidence needed": f"{r.threshold_e:,.0f}",
            "z needed, one-sided test": f"{r.z_needed_pvalue:.2f}",
            "z needed, e-value": f"{r.z_needed_evalue:.2f}",
        }
        for k, r in lev.iterrows()
    ]
    V["table_levels"] = md_table(pd.DataFrame(rows)) + f"\n\n: Table C2. First-claim levels at α = 10% under a uniform horizon. The e-value column assumes the mean measured gap of {lev['assumed_gap_nats'].iloc[0]:.1f} nats."
    V["z_p_150"] = f"{lev.loc[15, 'z_needed_pvalue']:.1f}"
    V["z_e_150"] = f"{lev.loc[15, 'z_needed_evalue']:.1f}"


def overhead():
    o = load("overhead.csv")
    get = lambda op, size=None: o[(o.operation == op) & ((o["size"] == size) if size else True)].iloc[0]["seconds"]
    ev_1m = get("e-value for one claim (16 orderings)", 1_000_000)
    ev_10k = get("e-value for one claim (16 orderings)", 10_000)
    append = get("ledger append (fsync each record)")
    verify = get("verify full ledger chain")
    close = get("close episode: unseal 9,600 rows, 10 claims, sign certificates")
    V["overhead_sentence"] = (
        f"On a two-core cloud machine, an e-value for one claim with 16 orderings took {1000 * ev_10k:.0f} ms on a fold of 10,000 rows "
        f"and {ev_1m:.1f} s on a fold of a million. Appending a ledger record with a forced disk sync took {1000 * append:.1f} ms, "
        f"and verifying a 2,000-record chain {1000 * verify:.0f} ms. Closing an episode of the Northfell study, which decrypts and checks "
        f"9,600 rows, updates ten claims and signs their certificates, took {close:.1f} s. The referee adds seconds to an analysis that "
        "takes an agent minutes."
    )


def casestudy():
    path = RESULTS / "casestudy_numbers.json"
    data = json.loads(path.read_text())
    V.update(data["values"])


def main():
    for fn in (validity, leakage, power, efficiency, overhead, casestudy):
        fn()
    parts = [(HERE / "metadata.yaml").read_text()]
    for path in sorted((HERE / "sections").glob("*.md")) + sorted((HERE / "appendix").glob("*.md")):
        parts.append(path.read_text())
    text = "\n\n".join(parts)
    used = set(re.findall(r"\{\{([a-zA-Z0-9_]+)\}\}", text))
    missing = sorted(k for k in used if k not in V)
    if missing:
        sys.exit(f"missing values: {missing}")
    for key in used:
        text = text.replace("{{" + key + "}}", V[key])
    (HERE / "paper.md").write_text(text)
    (RESULTS / "paper_numbers.json").write_text(json.dumps({k: V[k] for k in sorted(used) if not k.startswith("table_")}, indent=1, ensure_ascii=False))
    print(f"paper.md assembled with {len(used)} computed values; unused: {sorted(set(V) - used)}")


if __name__ == "__main__":
    main()
