"""End-to-end: create a study, explore, commit, close episodes, certify, verify, tamper."""
import asyncio
import json

import numpy as np
import pandas as pd
import pytest

from herdsman import Referee, RefereeError, verify_document
from herdsman.canonical import FixedClock
from herdsman.cli import main as cli_main


def _data(n=24000, seed=1):
    rng = np.random.default_rng(seed)
    segment = rng.choice(["x", "y", "z"], n)
    variant = rng.choice(["A", "B"], n)
    p = 0.30 + 0.12 * ((variant == "B") & (segment == "x"))
    minutes = np.clip(rng.normal(30 - 4 * (variant == "B"), 8, n), 0, 60)
    return pd.DataFrame(
        {
            "segment": segment,
            "variant": variant,
            "noise": rng.normal(size=n),
            "converted": rng.binomial(1, p),
            "minutes": minutes.round(1),
        }
    )


TRUE_CLAIM = {
    "statement": "Journey B lifts conversion in segment x",
    "outcome": "converted",
    "population": "segment == 'x'",
    "focal": "variant == 'B'",
    "reference": "variant == 'A'",
    "direction": "increase",
}
NULL_CLAIM = {**TRUE_CLAIM, "statement": "Journey B lifts conversion in segment y", "population": "segment == 'y'"}


@pytest.fixture()
def study(tmp_path):
    referee = Referee.create(
        tmp_path / "study",
        tmp_path / "keys",
        _data(),
        outcomes=["converted", "minutes"],
        bounds={"minutes": (0, 60)},
        alpha=0.1,
        horizon=10,
        n_folds=3,
        exploration_fraction=0.4,
        seed=12345,
        title="Test study",
        clock=FixedClock(),
    )
    return referee, tmp_path


def test_full_protocol(study):
    referee, tmp_path = study
    analyst = Referee(tmp_path / "study", clock=FixedClock("2026-11-07T10:00:00Z"))
    brief = analyst.brief()
    assert brief["exploration_rows"] == 9600
    assert brief["budget"]["next_claim_threshold_e"] == pytest.approx(100.0)

    result = analyst.explore_test(TRUE_CLAIM)
    assert result["p_two_sided"] < 0.01 and result["ledger_seq"] >= 2
    analyst.explore_test({**TRUE_CLAIM, "population": "segment == 'z'"})

    c1 = analyst.commit_claim(TRUE_CLAIM)
    c2 = analyst.commit_claim(NULL_CLAIM)
    assert (c1["id"], c2["id"]) == ("C001", "C002")
    with pytest.raises(RefereeError):
        analyst.commit_claim(TRUE_CLAIM)  # duplicate
    with pytest.raises(RefereeError):
        analyst.close_episode()  # analysts cannot open folds

    first = referee.close_episode()
    assert first["fold"] == 1
    assert len(analyst.exploration_data()) == 9600 + 4800  # spent fold released

    c3 = analyst.commit_claim(
        {"statement": "B shortens the journey", "outcome": "minutes", "focal": "variant == 'B'", "reference": "variant == 'A'", "direction": "decrease"}
    )
    assert c3["episode"] == 2

    final = referee.close_study()
    statuses = {c["id"]: c["status"] for c in referee.claims()}
    assert statuses["C001"] == "certified"
    assert statuses["C002"] in {"expired", "open"} and statuses["C002"] != "certified"
    assert statuses["C003"] == "certified"
    assert {c["id"] for c in final["certified"]} == {"C001", "C003"}

    with pytest.raises(RefereeError):
        analyst.commit_claim({**NULL_CLAIM, "population": "segment == 'z'"})

    certificate = referee.certificate("C001")
    assert verify_document(certificate, referee.params["referee_public_key"])["ok"]
    assert certificate["commit"]["threshold_e"] == pytest.approx(100.0)
    assert certificate["disclosure"]["exploratory_tests_logged_before_commit"] == 2

    check = referee.verify()
    assert check["ok"] and check["checkpoint_ok"]
    assert "Herdsman" in referee.report_html()
    assert referee.disclosure()["tests"] == 2


def test_tampering_is_detected(study):
    referee, tmp_path = study
    referee.commit_claim(TRUE_CLAIM)
    referee.close_episode()
    ledger_path = tmp_path / "study" / "ledger.jsonl"
    lines = ledger_path.read_text().splitlines()
    for i, line in enumerate(lines):
        record = json.loads(line)
        if record["type"] == "commit":
            record["payload"]["alpha_t"] = 0.5
            lines[i] = json.dumps(record)
    ledger_path.write_text("\n".join(lines) + "\n")
    assert not referee.verify()["ok"]


def test_family_claims_and_withdrawal(study):
    referee, _ = study
    family = referee.commit_family(
        [TRUE_CLAIM, NULL_CLAIM], statement="Journey B lifts conversion in at least one of segments x and y"
    )
    assert family["family_claim"] and len(family["members"]) == 2
    other = referee.commit_claim(NULL_CLAIM)
    referee.withdraw_claim(other["id"])
    referee.close_study()
    statuses = {c["id"]: c["status"] for c in referee.claims()}
    assert statuses[family["id"]] == "certified"
    assert statuses[other["id"]] == "withdrawn"


def test_invalid_claims_are_rejected(study):
    referee, _ = study
    with pytest.raises(RefereeError):
        referee.commit_claim({"outcome": "segment", "focal": "variant == 'B'", "reference": "variant == 'A'"})
    with pytest.raises(RefereeError):
        referee.commit_claim({"outcome": "converted", "focal": "__import__('os')", "reference": "variant == 'A'"})
    with pytest.raises(RefereeError):
        referee.commit_claim({"outcome": "converted", "population": "segment == 'x'"})  # neither reference nor value


def test_cli_and_mcp(study):
    referee, tmp_path = study
    assert cli_main(["budget", "--study", str(tmp_path / "study")]) == 0
    assert cli_main(["commit", "--study", str(tmp_path / "study"), "--claim", json.dumps(TRUE_CLAIM)]) == 0
    from herdsman.mcp_server import build_server

    server = build_server(str(tmp_path / "study"))
    tools = asyncio.run(server.list_tools())
    names = {t.name for t in tools}
    assert {"study_brief", "explore_test", "commit_claim", "budget_status"} <= names
    assert "close_episode" not in names


def test_batch_mode_single_seal(tmp_path):
    referee = Referee.create(
        tmp_path / "study", tmp_path / "keys", _data(), outcomes=["converted", "minutes"], bounds={"minutes": (0, 60)},
        alpha=0.1, mode="batch", batch_procedure="by", seed=7, clock=FixedClock(),
    )
    assert referee.vault.n_folds == 1
    referee.commit_claim(TRUE_CLAIM)
    referee.commit_claim(NULL_CLAIM)
    referee.commit_claim({**NULL_CLAIM, "population": "segment == 'z'"})
    result = referee.close_episode()
    assert [c["id"] for c in result["certified"]] == ["C001"]
    certificate = referee.certificate("C001")
    assert "Benjamini-Yekutieli" in certificate["guarantee"]
    assert referee.verify()["ok"]
    with pytest.raises(RefereeError):
        referee.commit_claim({**NULL_CLAIM, "population": "segment == 'x' and noise > 0"})


def test_audit_bundle_round_trip(study, tmp_path):
    referee, _ = study
    referee.commit_claim(TRUE_CLAIM)
    referee.close_study()
    bundle = referee.audit_bundle(tmp_path / "bundle.zip")
    from herdsman import verify_bundle

    result = verify_bundle(bundle)
    assert result["ok"] and result["params_in_ledger"] and result["checkpoint_ok"]
    assert cli_main(["verify-bundle", str(bundle)]) == 0
    import zipfile

    with zipfile.ZipFile(bundle) as zf:
        names = zf.namelist()
    assert not any(n.endswith(".key") or n.endswith(".pem") or "fold_" in n for n in names)
    # a bundle signed by another key fails when the trusted key is pinned
    from herdsman import Signer

    assert not verify_bundle(bundle, Signer.generate().public_hex)["ok"]
