import numpy as np
import pandas as pd
import pytest

from herdsman.filters import Filter, FilterError

FRAME = pd.DataFrame(
    {
        "device": ["mobile", "desktop", "mobile", None, "tablet"],
        "years": [1.0, 5.0, np.nan, 7.0, 3.0],
        "flag": [1, 0, 1, 1, 0],
    }
)


def test_trivial_filter_selects_everything():
    assert Filter("").mask(FRAME).all()
    assert Filter("all").is_trivial


def test_basic_comparisons_and_normalisation():
    f = Filter("device=='mobile'   and years>0")
    assert f.text == "device == 'mobile' and years > 0"
    assert f.columns == frozenset({"device", "years"})
    assert f.mask(FRAME).tolist() == [True, False, False, False, False]


def test_in_lists_chained_comparisons_and_not():
    assert Filter("device in ['mobile', 'tablet']").mask(FRAME).tolist() == [True, False, True, False, True]
    assert Filter("2 <= years < 6").mask(FRAME).tolist() == [False, True, False, False, True]
    assert Filter("not flag == 1").mask(FRAME).tolist() == [False, True, False, False, True]


def test_missing_values_never_satisfy_a_filter():
    # device is missing in row 3, so even "device != 'mobile'" excludes it
    assert Filter("device != 'mobile'").mask(FRAME).tolist() == [False, True, False, False, True]
    assert not Filter("not years > 100").mask(FRAME)[2]


@pytest.mark.parametrize(
    "expression",
    [
        "__import__('os').system('echo hi')",
        "device.upper() == 'MOBILE'",
        "years ** 2 > 4",
        "frame['years'] > 1",
        "lambda: 1",
        "[x for x in years]",
        "f'{device}' == 'mobile'",
        "years > (lambda: 3)()",
        "1 == 1",
        "device in years",
    ],
)
def test_unsafe_or_meaningless_filters_are_rejected(expression):
    with pytest.raises(FilterError):
        Filter(expression, FRAME.columns)


def test_unknown_columns_are_rejected():
    with pytest.raises(FilterError):
        Filter("colour == 'red'", FRAME.columns)


def test_overlong_filter_is_rejected():
    with pytest.raises(FilterError):
        Filter(" or ".join(["flag == 1"] * 200))
