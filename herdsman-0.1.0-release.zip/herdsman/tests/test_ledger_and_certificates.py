import json

from herdsman.canonical import FixedClock
from herdsman.certificates import Signer, verify_document
from herdsman.ledger import Ledger


def _ledger(tmp_path):
    ledger = Ledger(tmp_path / "ledger.jsonl", clock=FixedClock())
    for i in range(5):
        ledger.append("explore", "agent", {"i": i, "p": 0.1 * i})
    return ledger


def test_ledger_chain_verifies(tmp_path):
    ledger = _ledger(tmp_path)
    result = ledger.verify()
    assert result["ok"] and result["records"] == 5
    assert ledger.head()[0] == 5


def test_editing_a_record_is_detected(tmp_path):
    ledger = _ledger(tmp_path)
    lines = ledger.path.read_text().splitlines()
    record = json.loads(lines[2])
    record["payload"]["p"] = 0.0001
    lines[2] = json.dumps(record)
    ledger.path.write_text("\n".join(lines) + "\n")
    result = Ledger(ledger.path).verify()
    assert not result["ok"] and "altered" in result["error"]


def test_deleting_or_reordering_records_is_detected(tmp_path):
    ledger = _ledger(tmp_path)
    lines = ledger.path.read_text().splitlines()
    ledger.path.write_text("\n".join(lines[:1] + lines[2:]) + "\n")
    assert not Ledger(ledger.path).verify()["ok"]
    ledger.path.write_text("\n".join([lines[1], lines[0], *lines[2:]]) + "\n")
    assert not Ledger(ledger.path).verify()["ok"]


def test_certificate_signatures(tmp_path):
    signer = Signer.generate()
    signer.save(tmp_path / "key.pem")
    loaded = Signer.load(tmp_path / "key.pem")
    assert loaded.public_hex == signer.public_hex
    document = signer.sign_document({"claim": "B lifts completion", "log_e": 7.2})
    assert verify_document(document)["ok"]
    assert verify_document(document, signer.public_hex)["ok"]
    assert not verify_document(document, Signer.generate().public_hex)["ok"]
    tampered = {**document, "log_e": 9.9}
    assert not verify_document(tampered)["ok"]
