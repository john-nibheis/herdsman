"""Monte Carlo checks that the e-values are valid under their nulls and useful otherwise."""
import math

import numpy as np
import pytest

from herdsman.evalues import BettingState, difference_evidence, level_evidence, p_to_e, e_to_p

REPS = 1500


def _summary(log_es, alpha=0.05):
    e = np.exp(np.minimum(log_es, 700))
    mean = e.mean()
    se = e.std(ddof=1) / math.sqrt(e.size)
    reject = np.mean(np.asarray(log_es) >= math.log(1 / alpha))
    return mean, se, reject


@pytest.mark.parametrize(
    "n_focal,n_ref,p",
    [(150, 150, 0.3), (60, 600, 0.1), (500, 80, 0.5)],
)
def test_difference_evalue_is_valid_at_the_null_boundary(n_focal, n_ref, p):
    rng = np.random.default_rng(2026)
    log_es = []
    for i in range(REPS):
        ev = difference_evidence(
            rng.binomial(1, p, n_focal), rng.binomial(1, p, n_ref), lower=0, upper=1, seed=i, n_orderings=4
        )
        log_es.append(ev.log_e)
    mean, se, reject = _summary(log_es)
    assert mean <= 1.0 + 3 * se
    assert reject <= 0.05 + 3 * math.sqrt(0.05 * 0.95 / REPS)


def test_difference_evalue_with_margin_and_skewed_outcome_is_valid():
    rng = np.random.default_rng(7)
    log_es = []
    for i in range(REPS):
        focal = rng.beta(2, 5, 200) + 0.05  # mean shifted by exactly the margin
        ref = rng.beta(2, 5, 300)
        ev = difference_evidence(focal, ref, lower=0, upper=1.05, margin=0.05, seed=i, n_orderings=4)
        log_es.append(ev.log_e)
    mean, se, reject = _summary(log_es)
    assert mean <= 1.0 + 3 * se
    assert reject <= 0.05 + 3 * math.sqrt(0.05 * 0.95 / REPS)


def test_decrease_direction_is_valid_and_detects_a_decrease():
    rng = np.random.default_rng(11)
    null = [
        difference_evidence(rng.binomial(1, 0.4, 300), rng.binomial(1, 0.4, 300), lower=0, upper=1, direction="decrease", seed=i, n_orderings=4).log_e
        for i in range(REPS)
    ]
    mean, se, _ = _summary(null)
    assert mean <= 1.0 + 3 * se
    alt = difference_evidence(rng.binomial(1, 0.30, 2000), rng.binomial(1, 0.40, 2000), lower=0, upper=1, direction="decrease", seed=1)
    assert alt.log_e > math.log(1000)


def test_level_evalue_is_valid_at_the_boundary():
    rng = np.random.default_rng(3)
    true_mean = 2 / 7
    log_es = [
        level_evidence(rng.beta(2, 5, 250), lower=0, upper=1, value=true_mean, seed=i, n_orderings=4).log_e for i in range(REPS)
    ]
    mean, se, reject = _summary(log_es)
    assert mean <= 1.0 + 3 * se
    assert reject <= 0.05 + 3 * math.sqrt(0.05 * 0.95 / REPS)


def test_evalues_have_power_against_real_effects():
    rng = np.random.default_rng(5)
    ev = difference_evidence(rng.binomial(1, 0.56, 1500), rng.binomial(1, 0.50, 1500), lower=0, upper=1, seed=0)
    assert ev.log_e > math.log(20)
    lev = level_evidence(rng.binomial(1, 0.60, 1000), lower=0, upper=1, value=0.5, seed=0)
    assert lev.log_e > math.log(1000)


def test_same_seed_same_evidence_and_state_carries_over():
    rng = np.random.default_rng(9)
    a, b = rng.binomial(1, 0.55, 400), rng.binomial(1, 0.5, 700)
    first = difference_evidence(a, b, lower=0, upper=1, seed=42)
    again = difference_evidence(a, b, lower=0, upper=1, seed=42)
    assert first.log_e == again.log_e
    assert first.state.n == 400
    later = difference_evidence(a, b, lower=0, upper=1, seed=43, state=first.state)
    assert later.state.n == 800
    assert BettingState.from_dict(later.state.to_dict()) == later.state


def test_empty_groups_give_no_evidence():
    ev = difference_evidence([], [1, 0, 1], lower=0, upper=1, seed=0)
    assert ev.log_e == 0.0 and ev.n_obs == 0


def test_calibrators():
    assert p_to_e(1.0) == pytest.approx(0.5)
    assert p_to_e(0.01) > 1
    assert e_to_p(20) == pytest.approx(0.05)
    assert e_to_p(0.5) == 1.0


def test_misleading_exploration_prior_keeps_validity():
    """A starting bet fixed before the data are seen cannot break validity, however wrong it is."""
    from herdsman.evalues import prior_state

    rng = np.random.default_rng(13)
    start = prior_state(0.15, 0.21, 300, 0.21, 300)  # claims a 15-point lift that does not exist
    log_es = [
        difference_evidence(rng.binomial(1, 0.3, 300), rng.binomial(1, 0.3, 300), lower=0, upper=1, seed=i, n_orderings=4, state=start).log_e
        for i in range(REPS)
    ]
    mean, se, reject = _summary(log_es)
    assert mean <= 1.0 + 3 * se
    assert reject <= 0.05 + 3 * math.sqrt(0.05 * 0.95 / REPS)
