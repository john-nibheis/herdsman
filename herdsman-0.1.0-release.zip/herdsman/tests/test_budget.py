import math

import numpy as np
import pytest

from herdsman.budget import ELond, GammaPolicy, bh, by, bonferroni, e_bh, lond


@pytest.mark.parametrize("policy", [GammaPolicy.uniform(40), GammaPolicy.harmonic(40), GammaPolicy.decaying()])
def test_gamma_sequences_sum_to_at_most_one(policy):
    total = sum(policy.gamma(j) for j in range(1, 20001))
    assert total <= 1.0 + 1e-12
    assert all(policy.gamma(j) >= 0 for j in range(1, 100))


def test_uniform_policy_closes_after_horizon():
    policy = GammaPolicy.uniform(5)
    assert policy.gamma(5) == pytest.approx(0.2)
    assert policy.gamma(6) == 0.0


def test_elond_levels_rise_with_discoveries_but_are_capped():
    elond = ELond(0.1, GammaPolicy.uniform(20))
    assert elond.level(1, 0) == pytest.approx(0.005)
    assert elond.level(3, 2) == pytest.approx(0.015)
    assert elond.level(3, 50) == pytest.approx(0.1)


def test_bh_and_e_bh_on_known_examples():
    p = [0.001, 0.008, 0.039, 0.041, 0.042, 0.06, 0.074, 0.205, 0.212, 0.216]
    assert bh(p, 0.05).sum() == 2
    assert by(p, 0.05).sum() <= 2
    assert bonferroni(p, 0.05).sum() == 1
    e = [400, 120, 30, 2, 1, 0.5]
    assert e_bh(e, 0.1).tolist() == [True, True, True, False, False, False]


def test_lond_rejects_in_order():
    policy = GammaPolicy.uniform(10)
    out = lond([0.001, 0.5, 0.004, 0.001], 0.1, policy)
    assert out.tolist() == [True, False, True, True]


def test_elond_controls_fdr_under_perfect_dependence():
    """All null e-values are the same heavy-tailed draw: the worst case for dependence."""
    rng = np.random.default_rng(0)
    alpha, policy = 0.1, GammaPolicy.uniform(30)
    elond = ELond(alpha, policy)
    fdp = []
    for _ in range(20000):
        shared = 400.0 if rng.random() < 1 / 400 else 0.0  # mean one
        is_null = rng.random(30) < 0.7
        certified = 0
        false = 0
        for t in range(1, 31):
            e = shared if is_null[t - 1] else 1e6
            if e >= 1.0 / elond.level(t, certified):
                certified += 1
                false += bool(is_null[t - 1])
        fdp.append(false / max(certified, 1))
    fdr = float(np.mean(fdp))
    assert fdr <= alpha + 3 * math.sqrt(alpha * (1 - alpha) / len(fdp))
