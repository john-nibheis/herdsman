"""Experiment 1: false discovery rate and power across worlds, analysts and methods.

Usage: python experiments/run_validity.py --reps 500
Writes results/validity_raw.csv and results/validity_summary.csv.
"""
from __future__ import annotations

import argparse
import math
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import simlib as S  # noqa: E402

from herdsman.budget import bh, by  # noqa: E402

ALPHA = 0.10
N_ROWS = 40_000
EXPLORE = 0.4
FOLDS = 3
WORLDS = ("null", "sparse", "dense")
LABEL = {"null": "global_null", "sparse": "sparse", "dense": "dense"}
AGENTS = {
    "diligent": (S.analyst_diligent, 10),
    "forking": (S.analyst_forking, 15),
    "pressured": (S.analyst_pressured, 15),
}


def one_rep(args):
    world_kind, rep, base_seed = args
    rng = np.random.default_rng([base_seed, WORLDS.index(world_kind), rep])
    world = S.draw_world(world_kind, rng)
    data = S.generate(world, N_ROWS, rng)
    d0, folds = S.split(data, EXPLORE, FOLDS, rng)
    holdout = S.Data.concat(folds)
    seed = int(rng.integers(2**62))
    rows = []
    for name, (agent, k) in AGENTS.items():
        tests, chosen = agent(d0, k=k)
        claims = [c for c, _ in chosen]
        committed_true = sum(S.is_true(c, world) for c in claims)
        p_hold = [S.holdout_pvalue(c, holdout) for c in claims]
        methods = {
            "naive_all_p05": [S.as_claim(t) for t in tests if t[4] < 0.05],
            "naive_report": [c for c, t in chosen if t[4] < 0.05],
            "explore_bh": [S.as_claim(t) for t, keep in zip(tests, bh([t[4] for t in tests], ALPHA)) if keep],
            "holdout_p05": [c for c, p in zip(claims, p_hold) if p < 0.05],
            "holdout_bonferroni": [c for c, p in zip(claims, p_hold) if p < ALPHA / max(len(claims), 1)],
            "holdout_bh": [c for c, keep in zip(claims, bh(p_hold, ALPHA)) if keep],
            "holdout_by": [c for c, keep in zip(claims, by(p_hold, ALPHA)) if keep],
            "single_seal_ebh": [c for c, keep in zip(claims, S.single_seal_ebh(chosen, holdout, alpha=ALPHA, seed=seed)) if keep],
        }
        entries, _ = S.rolling_seal(lambda data, excl, _t=tests, _c=chosen: (_t, _c), d0, folds, alpha=ALPHA, horizon=k, seed=seed, episodes=1)
        methods["herdsman"] = [e["claim"] for e in entries if e["status"] == "certified"]
        flat, _ = S.rolling_seal(lambda data, excl, _t=tests, _c=chosen: (_t, _c), d0, folds, alpha=ALPHA, horizon=k, seed=seed, episodes=1, prior=False)
        methods["herdsman_flat_prior"] = [e["claim"] for e in flat if e["status"] == "certified"]
        for method, found in methods.items():
            rows.append({"world": LABEL[world_kind], "rep": rep, "agent": name, "method": method, "tests": len(tests), "committed_true": committed_true, "committed": len(claims), **S.score(found, world)})
    # multi-episode adaptive analyst under the rolling seal
    def adaptive(data, excl):
        return S.analyst_forking(data, k=10, exclude=excl)

    entries, logs = S.rolling_seal(adaptive, d0, folds, alpha=ALPHA, horizon=30, seed=seed, episodes=3)
    found = [e["claim"] for e in entries if e["status"] == "certified"]
    committed_true = sum(S.is_true(e["claim"], world) for e in entries)
    rows.append({"world": LABEL[world_kind], "rep": rep, "agent": "adaptive_3_episodes", "method": "herdsman", "tests": sum(len(t) for t in logs), "committed_true": committed_true, "committed": len(entries), **S.score(found, world)})
    naive = [e["claim"] for e in entries if e["test"][4] < 0.05]
    rows.append({"world": LABEL[world_kind], "rep": rep, "agent": "adaptive_3_episodes", "method": "naive_report", "tests": sum(len(t) for t in logs), "committed_true": committed_true, "committed": len(entries), **S.score(naive, world)})
    return rows


def summarise(raw: pd.DataFrame) -> pd.DataFrame:
    def agg(g):
        fdp = g["FDP"].to_numpy()
        n = len(g)
        power = (g["T"] / g["committed_true"].where(g["committed_true"] > 0)).dropna()
        return pd.Series(
            {
                "reps": n,
                "FDR": fdp.mean(),
                "FDR_se": fdp.std(ddof=1) / math.sqrt(n),
                "mean_discoveries": g["R"].mean(),
                "mean_false": g["V"].mean(),
                "mean_true": g["T"].mean(),
                "P_any_false": (g["V"] > 0).mean(),
                "mean_tests": g["tests"].mean(),
                "mean_committed_true": g["committed_true"].mean(),
                "share_true_claims_certified": power.mean() if len(power) else float("nan"),
            }
        )

    return raw.groupby(["world", "agent", "method"], sort=False).apply(agg, include_groups=False).reset_index()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20261107)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "results"))
    args = parser.parse_args()
    jobs = [(w, r, args.seed) for w in WORLDS for r in range(args.reps)]
    start = time.time()
    rows = []
    with Pool(args.workers) as pool:
        for i, chunk in enumerate(pool.imap_unordered(one_rep, jobs, chunksize=4)):
            rows.extend(chunk)
            if (i + 1) % 100 == 0:
                print(f"{i + 1}/{len(jobs)} reps, {time.time() - start:.0f}s", flush=True)
    raw = pd.DataFrame(rows)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    raw.to_csv(out / "validity_raw.csv", index=False)
    summary = summarise(raw)
    summary.to_csv(out / "validity_summary.csv", index=False)
    print(summary.round(3).to_string())
    print(f"done in {time.time() - start:.0f}s")


if __name__ == "__main__":
    main()
