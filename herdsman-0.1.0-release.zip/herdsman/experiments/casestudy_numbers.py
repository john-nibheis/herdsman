"""Writes results/casestudy_numbers.json: every case-study value used by the paper, playbook, deck and site.

Numbers come from casestudy_stats.run_stats(); this file only wraps them in sentences.
Usage: python casestudy_numbers.py
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import casestudy as CS  # noqa: E402
import casestudy_stats as ST  # noqa: E402

WORDS = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten", 11: "eleven", 12: "twelve"}


def w(n: int) -> str:
    return WORDS.get(int(n), f"{int(n):,}")


def W(n: int) -> str:
    s = w(n)
    return s[0].upper() + s[1:]


def plural(n: int, one: str, many: str | None = None) -> str:
    return f"{w(n)} {one if n == 1 else (many or one + 's')}"


def md_table(df: pd.DataFrame, widths: list[int] | None = None) -> str:
    cols = list(df.columns)
    widths = widths or [3] * len(cols)
    seps = [("-" * w) if i < 3 else ("-" * (w - 1) + ":") for i, w in enumerate(widths)]
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(seps) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def table_case(s: pd.DataFrame) -> str:
    rows = []
    for r in s.itertuples():
        rows.append(
            {
                "Run": r.run,
                "Brief": r.label.replace(" brief", ""),
                "World": r.world_label,
                "Distinct tests before report": f"{r.tests:,}",
                "Effects reported (false)": f"{r.findings} ({r.findings_false})",
                "Claims committed (false)": f"{r.claims} ({r.claims_false})",
                "Certified (false)": f"{r.certified} ({r.certified_false})",
                "True claims not certified": f"{r.true_not_certified}",
            }
        )
    return (
        md_table(pd.DataFrame(rows), widths=[5, 17, 11, 9, 12, 12, 11, 11])
        + "\n\n: Table 4. The six case-study runs. Distinct tests are the distinct specifications an agent ran through the logged helper before its first "
        f"commit; the ledgers record {int(s.tests_all_calls.min())} to {int(s.tests_all_calls.max())} test calls per run in total, including repeats and later exploration. "
        f"Effects are the findings with p < 0.05 in the agent's unrefereed report; the {int(s.null_findings.sum())} null results reported with p ≥ 0.05 "
        f"({', '.join(f'{int(r.null_findings)} by {r.run}' for r in s.itertuples() if r.null_findings)}) are excluded and were all correct. "
        "Claims are those committed to the referee in either episode. 'False' means the oracle's true effect does not lie in the claimed direction by more "
        "than the claim's margin plus the tolerance in Appendix D. Every study's ledger, released folds and certificate signatures verified."
    )


def setup_values() -> dict:
    full = CS.full_data("standard")
    n_features = full.shape[1] - 2 - len(CS.NF.OUTCOMES)  # minus id, variant and outcomes
    return {
        "nf_rows": f"{len(full):,}",
        "nf_features": f"{n_features}",
        "nf_sealed_rows": "28,800",
        "nf_fold_rows": "9,600",
        "nf_explore_rows": "19,200",
    }


def main() -> None:
    s = ST.run_stats()
    V = setup_values()
    V["table_case"] = table_case(s)
    try:
        import casestudy_narrative as N  # written once the runs are complete
    except ImportError:
        N = None
    if N is not None:
        V.update(N.values(s, ST))
    out = ROOT / "results" / "casestudy_numbers.json"
    out.write_text(json.dumps({"values": V, "runs": s.to_dict(orient="records")}, indent=1, ensure_ascii=False, default=str))
    print("written", out, sorted(V))


if __name__ == "__main__":
    main()
