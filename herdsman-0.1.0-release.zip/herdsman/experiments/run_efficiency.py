"""Appendix C: how close the betting e-value comes to the oracle likelihood ratio.

For two-group binary outcomes with a real effect, compares the mean log e-value (flat
start and exploration-informed start) with the mean of z^2/2, the log of the oracle
Gaussian likelihood ratio at the true effect. Also tabulates the z needed by a
one-sided z-test and by an e-value at the levels the rolling seal uses.
Writes results/efficiency.csv and results/levels.csv.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

from herdsman.evalues import difference_evidence, prior_state

OUT = Path(__file__).resolve().parents[1] / "results"


def main(reps: int = 200):
    rng = np.random.default_rng(20261110)
    rows = []
    for n, p1, p0 in [(600, 0.40, 0.30), (800, 0.38, 0.30), (2000, 0.36, 0.30), (5000, 0.33, 0.30)]:
        z2, flat, informed = [], [], []
        for i in range(reps):
            a = rng.binomial(1, p1, n)
            b = rng.binomial(1, p0, n)
            z = (a.mean() - b.mean()) / math.sqrt(a.var(ddof=1) / n + b.var(ddof=1) / n)
            z2.append(z * z / 2)
            flat.append(difference_evidence(a, b, lower=0, upper=1, seed=i).log_e)
            # exploration estimate from an independent sample of the same size, as at commit
            ea, eb = rng.binomial(1, p1, n), rng.binomial(1, p0, n)
            start = prior_state(ea.mean() - eb.mean(), ea.var(ddof=1), n, eb.var(ddof=1), n)
            informed.append(difference_evidence(a, b, lower=0, upper=1, seed=i, state=start).log_e)
        rows.append(
            {
                "n_per_group": n,
                "effect": round(p1 - p0, 3),
                "mean_z": math.sqrt(2 * np.mean(z2)),
                "oracle_log_lr": float(np.mean(z2)),
                "log_e_flat": float(np.mean(flat)),
                "log_e_informed": float(np.mean(informed)),
                "gap_flat": float(np.mean(z2) - np.mean(flat)),
                "gap_informed": float(np.mean(z2) - np.mean(informed)),
            }
        )
    eff = pd.DataFrame(rows)
    eff.to_csv(OUT / "efficiency.csv", index=False)
    print(eff.round(3).to_string())
    mean_gap = float(eff["gap_informed"].mean())
    levels = []
    for slots in (10, 15, 20, 50):
        alpha_t = 0.10 / slots
        z_p = float(norm.isf(alpha_t))
        z_e = math.sqrt(2 * (math.log(1 / alpha_t) + mean_gap))
        levels.append({"slots": slots, "alpha_t": alpha_t, "threshold_e": 1 / alpha_t, "z_needed_pvalue": z_p, "z_needed_evalue": z_e, "assumed_gap_nats": mean_gap})
    lev = pd.DataFrame(levels)
    lev.to_csv(OUT / "levels.csv", index=False)
    print(lev.round(3).to_string())


if __name__ == "__main__":
    main()
