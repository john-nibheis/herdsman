"""Builds results/casestudy_console.html: a self-contained page for browsing every case-study run.

All data are read from the stored studies and the scored results; the page embeds them as JSON.
Usage: python casestudy_console.py
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import casestudy as CS  # noqa: E402
import casestudy_stats as ST  # noqa: E402

from herdsman import Referee, verify_document  # noqa: E402


def _num(x):
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return None
    return float(x)


def build_data() -> dict:
    scored = ST.load_scored()
    stats = ST.run_stats().set_index("run")
    runs = []
    for meta in ST.runs():
        run = meta["run_id"]
        s = scored[scored.run == run]
        ref = Referee(CS.ROOT / "runs" / run / "study")
        pub = ref.params["referee_public_key"]
        truth = {}
        for r in s[s.kind == "committed claim"].itertuples():
            cid = r.item.split(".")[0]
            truth.setdefault(cid, []).append((r.is_true, _num(r.true_value)))
        claims = []
        for c in ref.claims():
            t = truth.get(c["id"], [])
            is_true = None if not t or any(v is None or (isinstance(v, float) and math.isnan(v)) for v, _ in t) else any(v == True for v, _ in t)  # noqa: E712
            item = {
                "id": c["id"],
                "statement": c["statement"],
                "episode": c["episode"],
                "status": c["status"],
                "needed_log10": math.log10(c["threshold_e"]),
                "log10_e": c["log10_e"],
                "path": [round(p["log_e_cumulative"] / math.log(10), 3) for p in c["trajectory"]],
                "folds": [p["fold"] for p in c["trajectory"]],
                "is_true": is_true,
                "true_value": t[0][1] if len(t) == 1 else None,
                "family": c["family_claim"],
            }
            if c["status"] == "certified":
                cert = ref.certificate(c["id"])
                item["certificate"] = {
                    "ledger_seq": cert["commit"]["ledger_seq"],
                    "ledger_hash": cert["commit"]["ledger_hash"][:16],
                    "alpha_t": cert["commit"]["alpha_t"],
                    "certified_before": cert["commit"]["certified_before"],
                    "certified_fold": cert["evidence"]["certified_fold"],
                    "tests_before": cert["disclosure"]["exploratory_tests_logged_before_commit"],
                    "family_tests": cert["disclosure"]["same_family_tests_before_commit"],
                    "issued_at": cert["issued_at"],
                    "signature": cert["signature"]["value"][:24] if isinstance(cert.get("signature"), dict) else str(cert.get("signature"))[:24],
                    "signature_ok": verify_document(cert, pub)["ok"],
                }
            claims.append(item)
        findings = []
        for r in s[s.kind == "unrefereed report"].itertuples():
            findings.append(
                {
                    "item": r.item,
                    "statement": r.statement,
                    "p_value": _num(r.p_value),
                    "true_value": _num(r.true_value),
                    "is_true": None if r.is_true is None or (isinstance(r.is_true, float) and math.isnan(r.is_true)) else bool(r.is_true),
                    "null": getattr(r, "finding_type", "directional") == "null",
                }
            )
        st = stats.loc[run]
        runs.append(
            {
                "run": run,
                "persona": st["label"],
                "world": st["world_label"],
                "brief": CS.PERSONAS[meta["persona"]],
                "tests": int(st["tests"]),
                "significant": int(st["significant"]),
                "findings": findings,
                "claims": claims,
                "verify_ok": bool(st["verify_ok"]),
                "ledger_records": int(st["ledger_records"]),
                "public_key": pub[:16],
            }
        )
    return {"runs": runs, "setup": {"rows": 48000, "explore": 19200, "folds": 3, "fold_rows": 9600, "alpha": 0.10, "slots": 20}}


TEMPLATE = r"""<title>Northfell Case Study</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:wght@400..700&family=IBM+Plex+Sans:wght@400;600&family=IBM+Plex+Mono:wght@400;600&display=swap">
<style>
:root{--bg:#F5F4EF;--surface:#FCFBF8;--sunk:#ECEAE2;--ink:#0B2545;--body:#3C4A5C;--muted:#5E6B78;--rule:#DAD7CC;--accent:#1F8A8A;--accent-ink:#17696A;--accent-soft:#E3EFEE;--warn:#9A5B12;--warn-soft:#F6E7CF;--track:#E2E0D8}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#0D1828;--surface:#13233A;--sunk:#0A1422;--ink:#EEF2F6;--body:#C9D6E3;--muted:#9FB3C8;--rule:#27405C;--accent:#4FB3B0;--accent-ink:#7CCFCB;--accent-soft:#163A44;--warn:#E9B566;--warn-soft:#3A2C17;--track:#22374F;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#0D1828;--surface:#13233A;--sunk:#0A1422;--ink:#EEF2F6;--body:#C9D6E3;--muted:#9FB3C8;--rule:#27405C;--accent:#4FB3B0;--accent-ink:#7CCFCB;--accent-soft:#163A44;--warn:#E9B566;--warn-soft:#3A2C17;--track:#22374F;color-scheme:dark}
body{background:var(--bg);color:var(--body);font-family:'IBM Plex Sans',Arial,sans-serif;font-size:16px;line-height:1.55}
.wrap{max-width:1180px;margin:0 auto;padding-block:40px 64px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));display:flex;flex-direction:column;gap:32px}
h1,h2,h3{font-family:'Source Serif 4',Georgia,serif;color:var(--ink);font-weight:600;text-wrap:balance;margin:0}
h1{font-size:clamp(30px,5vw,44px);line-height:1.1}
h2{font-size:24px;line-height:1.2}
h3{font-size:19px}
p{margin:0}
.eyebrow{font-size:12px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--accent-ink)}
.lede{max-width:70ch}
.mono{font-family:'IBM Plex Mono','Courier New',monospace;font-variant-numeric:tabular-nums}
header{display:flex;flex-direction:column;gap:14px}
.facts{display:flex;flex-wrap:wrap;gap:8px 24px;margin:0;padding:14px 0 0;border-top:1px solid var(--rule)}
.facts div{display:flex;gap:8px;align-items:baseline}
.facts dt{font-size:13px;color:var(--muted)}
.facts dd{margin:0;font-weight:600;color:var(--ink)}
.tabs{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}
.tab{appearance:none;border:1px solid var(--rule);background:var(--surface);color:var(--body);border-radius:8px;padding:10px 14px;font:inherit;font-size:14px;text-align:left;cursor:pointer;display:flex;flex-direction:column;gap:2px;min-width:0}
.tab b{font-family:'IBM Plex Mono','Courier New',monospace;color:var(--ink)}
.tab[aria-selected="true"]{border-color:var(--accent);background:var(--accent-soft);box-shadow:inset 0 0 0 1px var(--accent)}
.tab:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.brief{background:var(--sunk);border-radius:10px;padding:16px 18px;display:flex;flex-direction:column;gap:6px;max-width:80ch}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.tile{background:var(--surface);border:1px solid var(--rule);border-radius:10px;padding:14px 16px;display:flex;flex-direction:column;gap:4px;min-width:0}
.tile .v{font-family:'Source Serif 4',Georgia,serif;font-size:32px;font-weight:600;color:var(--ink);line-height:1.1}
.tile .k{font-size:13px;color:var(--muted)}
.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,520px),1fr));gap:24px;align-items:start}
.panel{background:var(--surface);border:1px solid var(--rule);border-radius:12px;padding:18px;display:flex;flex-direction:column;gap:12px;min-width:0}
.panel>p.note{font-size:14px;color:var(--muted)}
ol.list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}
ol.list>li{border-top:1px solid var(--rule);padding:12px 0;display:flex;flex-direction:column;gap:6px;min-width:0}
ol.list>li:first-child{border-top:none}
.row{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center;font-size:13px;color:var(--muted)}
.id{font-family:'IBM Plex Mono','Courier New',monospace;font-size:13px;color:var(--ink);font-weight:600}
.stmt{color:var(--ink)}
.badge{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:600;border-radius:99px;padding:2px 10px;letter-spacing:.02em}
.b-true{background:var(--accent-soft);color:var(--accent-ink)}
.b-false{background:var(--warn-soft);color:var(--warn)}
.b-none{background:var(--sunk);color:var(--muted)}
.b-cert{background:var(--accent);color:var(--bg)}
.meter{position:relative;height:8px;background:var(--track);border-radius:99px;overflow:hidden;flex:1 1 140px;min-width:100px;max-width:260px}
.meter span{position:absolute;inset:0 auto 0 0;background:var(--accent);border-radius:99px}
details{border-top:1px dashed var(--rule);padding-top:8px}
summary{cursor:pointer;font-size:13px;color:var(--accent-ink);font-weight:600}
summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.cert{display:grid;grid-template-columns:max-content 1fr;gap:4px 14px;margin:10px 0 0;font-size:13px}
.cert dt{color:var(--muted)}
.cert dd{margin:0;font-family:'IBM Plex Mono','Courier New',monospace;color:var(--ink);overflow-wrap:anywhere}
.empty{font-size:14px;color:var(--muted);padding:8px 0}
footer{border-top:1px solid var(--rule);padding-top:18px;font-size:14px;color:var(--muted);display:flex;flex-direction:column;gap:8px;max-width:85ch}
</style>
<div class="wrap">
<header>
<p class="eyebrow">Herdsman · live AI analysts</p>
<h1>The Northfell case study</h1>
<p class="lede">Independent AI analyst agents analysed the same randomised lending experiment. Each first wrote the report an unrefereed analyst would deliver, then committed the claims it wanted certified to the referee, which tested them on sealed data the agent had never seen. The data are synthetic, so every finding and claim is scored against the exact truth.</p>
<dl class="facts" id="facts"></dl>
</header>
<nav class="tabs" role="tablist" aria-label="Analyst runs" id="tabs"></nav>
<section id="run" aria-live="polite"></section>
<footer>
<p><b>How to read this page.</b> A finding or claim is <i>true</i> if the generator's expected effect, computed by an oracle over 300,000 simulated applications, lies in the claimed direction by more than the claim's margin plus 0.002 (0.2 minutes for journey time). Evidence is shown on a log scale: the bar fills as a claim's accumulated e-value approaches the bar fixed when it was committed.</p>
<p>Northfell Business Finance is fictional. Every number on this page is read from the stored studies and the scored results; certificate signatures were checked against each study's referee key when the page was built.</p>
</footer>
</div>
<script>
const DATA = __DATA__;
const $ = (s, el = document) => el.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const fmtP = (p) => p == null ? "—" : (p < 1e-4 ? p.toExponential(1) : p.toPrecision(2));
const fmtE = (l) => l == null ? "—" : (l >= 6 ? `10^${l.toFixed(1)}` : Math.pow(10, l).toLocaleString("en-GB", {maximumFractionDigits: l < 1 ? 2 : 0}));
const truthBadge = (t) => t === true ? '<span class="badge b-true">True</span>' : t === false ? '<span class="badge b-false">False</span>' : '<span class="badge b-none">Not scored</span>';
const statusWord = {certified: "Certified", open: "Open", expired: "Not certified (study closed)", withdrawn: "Withdrawn", failed: "Not certified"};

function facts() {
  const s = DATA.setup;
  const items = [["Applications", s.rows.toLocaleString("en-GB")], ["Exploration", s.explore.toLocaleString("en-GB")], ["Sealed folds", `${s.folds} × ${s.fold_rows.toLocaleString("en-GB")}`], ["False discovery rate", `${Math.round(s.alpha * 100)}%`], ["Claim slots", s.slots], ["Runs", DATA.runs.length]];
  $("#facts").innerHTML = items.map(([k, v]) => `<div><dt>${k}</dt><dd class="mono">${v}</dd></div>`).join("");
}

function tabs(active) {
  $("#tabs").innerHTML = DATA.runs.map((r) => `<button class="tab" role="tab" id="tab-${r.run}" aria-selected="${r.run === active}" aria-controls="run" data-run="${r.run}"><b>${r.run}</b><span>${esc(r.persona)} · ${esc(r.world)}</span></button>`).join("");
  $("#tabs").querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => { location.hash = b.dataset.run; }));
}

function meter(c) {
  const frac = Math.max(0, Math.min(1, c.log10_e / c.needed_log10));
  return `<span class="meter" role="img" aria-label="Evidence ${fmtE(c.log10_e)} of ${fmtE(c.needed_log10)} needed"><span style="width:${(frac * 100).toFixed(1)}%"></span></span>`;
}

function certBlock(c) {
  if (!c.certificate) return "";
  const k = c.certificate;
  return `<details><summary>Certificate</summary><dl class="cert">
<dt>Committed at ledger record</dt><dd>${k.ledger_seq} · ${esc(k.ledger_hash)}…</dd>
<dt>Level fixed at commit</dt><dd>α_t = ${k.alpha_t.toPrecision(3)} (${k.certified_before} certified before)</dd>
<dt>Certified on fold</dt><dd>${k.certified_fold}</dd>
<dt>Tests logged before commit</dt><dd>${k.tests_before} (${k.family_tests} in the same family)</dd>
<dt>Issued</dt><dd>${esc(k.issued_at)}</dd>
<dt>Ed25519 signature</dt><dd>${esc(k.signature)}… ${k.signature_ok ? "valid" : "INVALID"}</dd>
</dl></details>`;
}

function render() {
  const id = (location.hash || "").slice(1);
  const run = DATA.runs.find((r) => r.run === id) || DATA.runs[0];
  tabs(run.run);
  const f = run.findings, c = run.claims;
  const fd = f.filter((x) => !x.null), fFalse = fd.filter((x) => x.is_true === false).length, nNull = f.length - fd.length;
  const cert = c.filter((x) => x.status === "certified");
  const cTrue = cert.filter((x) => x.is_true === true).length, cFalse = cert.filter((x) => x.is_true === false).length;
  const tiles = [[run.tests, "distinct tests before the report"], [run.significant, "of them significant at 5%"], [`${fd.length}`, `effects reported (${fFalse} false)${nNull ? `, plus ${nNull} null result${nNull > 1 ? "s" : ""}` : ""}`], [c.length, "claims committed"], [`${cert.length}`, `certified (${cFalse} false)`]];
  $("#run").innerHTML = `<div style="display:flex;flex-direction:column;gap:20px">
<div class="brief"><p class="eyebrow">Run ${run.run} · ${esc(run.persona)} · ${esc(run.world)} world</p><p>${esc(run.brief)}</p></div>
<div class="tiles">${tiles.map(([v, k]) => `<div class="tile"><span class="v mono">${v}</span><span class="k">${k}</span></div>`).join("")}</div>
<div class="cols">
<div class="panel"><h2>What the unrefereed analyst reported</h2><p class="note">Findings written before the referee was mentioned, with the analyst's own p-values.</p>
${f.length ? `<ol class="list">${f.map((x) => `<li><div class="row"><span class="id">${esc(x.item)}</span>${x.null ? '<span class="badge b-none">Null result</span>' + (x.is_true === true ? '<span class="badge b-true">Correct</span>' : x.is_true === false ? '<span class="badge b-false">Wrong</span>' : '') : truthBadge(x.is_true)}<span>p = <span class="mono">${fmtP(x.p_value)}</span></span><span>true effect <span class="mono">${x.true_value == null ? "—" : x.true_value.toFixed(3)}</span></span></div><span class="stmt">${esc(x.statement)}</span></li>`).join("")}</ol>` : `<p class="empty">This analyst reported no findings.</p>`}</div>
<div class="panel"><h2>What the referee certified</h2><p class="note">Claims committed to the referee, tested only on sealed folds. ${cTrue} of ${cert.length} certified claims are true.</p>
${c.length ? `<ol class="list">${c.map((x) => `<li><div class="row"><span class="id">${esc(x.id)}</span>${x.status === "certified" ? '<span class="badge b-cert">Certified</span>' : `<span class="badge b-none">${esc(statusWord[x.status] || x.status)}</span>`}${truthBadge(x.is_true)}<span>episode ${x.episode}</span></div><span class="stmt">${esc(x.statement)}</span><div class="row">${meter(x)}<span>evidence <span class="mono">${fmtE(x.log10_e)}</span> of <span class="mono">${fmtE(x.needed_log10)}</span> needed</span></div>${certBlock(x)}</li>`).join("")}</ol>` : `<p class="empty">No claims committed yet.</p>`}</div>
</div>
<p class="note" style="font-size:14px;color:var(--muted)">Ledger: ${run.ledger_records} hash-chained records, ${run.verify_ok ? "chain, released folds and signatures verified" : "VERIFICATION FAILED"}. Referee key ${esc(run.public_key)}…</p>
</div>`;
}

facts();
window.addEventListener("hashchange", render);
render();
</script>
"""


def main() -> None:
    data = build_data()
    html = TEMPLATE.replace("__DATA__", json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))
    out = ROOT / "results" / "casestudy_console.html"
    out.write_text(html)
    print("written", out, f"{len(html) / 1024:.0f} KB")


if __name__ == "__main__":
    main()
