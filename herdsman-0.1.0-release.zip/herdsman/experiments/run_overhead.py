"""Experiment 4: computational overhead of the referee.

Times (i) the e-value for one claim on folds of increasing size, (ii) ledger appends
and full-chain verification, (iii) an end-to-end episode on a 48,000-row study.
Writes results/overhead.csv.
"""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import northfell as NF  # noqa: E402

from herdsman import Ledger, Referee, difference_evidence  # noqa: E402


def best_of(fn, repeats=5):
    times = []
    for _ in range(repeats):
        start = time.perf_counter()
        fn()
        times.append(time.perf_counter() - start)
    return min(times)


def main():
    rows = []
    rng = np.random.default_rng(0)
    for n in (1_000, 10_000, 100_000, 1_000_000):
        a, b = rng.binomial(1, 0.31, n // 2).astype(float), rng.binomial(1, 0.30, n // 2).astype(float)
        seconds = best_of(lambda: difference_evidence(a, b, lower=0, upper=1, seed=1, n_orderings=16), repeats=3 if n >= 1_000_000 else 5)
        rows.append({"operation": "e-value for one claim (16 orderings)", "size": n, "seconds": seconds})
    with tempfile.TemporaryDirectory() as tmp:
        ledger = Ledger(Path(tmp) / "ledger.jsonl")
        payload = {"spec": {"outcome": "completed", "population": "device == 'mobile'", "focal": "variant == 'B'", "reference": "variant == 'A'"}, "result": {"z": 2.1, "p": 0.035}}
        start = time.perf_counter()
        for _ in range(2_000):
            ledger.append("explore", "agent", payload)
        rows.append({"operation": "ledger append (fsync each record)", "size": 2_000, "seconds": (time.perf_counter() - start) / 2_000})
        start = time.perf_counter()
        ledger.verify()
        rows.append({"operation": "verify full ledger chain", "size": 2_000, "seconds": time.perf_counter() - start})
        data = NF.generate(48_000, 1)
        referee = Referee.create(Path(tmp) / "study", Path(tmp) / "keys", data, outcomes=NF.OUTCOMES, bounds=NF.BOUNDS, horizon=20, seed=3)
        start = time.perf_counter()
        test = referee.explore_test({"outcome": "completed", "population": "device == 'mobile'", "focal": "variant == 'B'", "reference": "variant == 'A'"})
        rows.append({"operation": "logged exploratory test (19,200 rows)", "size": 19_200, "seconds": time.perf_counter() - start})
        specs = [
            {"outcome": "completed", "population": p, "focal": "variant == 'B'", "reference": "variant == 'A'"}
            for p in ["", "device == 'mobile'", "accounting_software == 'cloud'", "channel == 'broker'", "region == 'London'"]
        ] + [
            {"outcome": "arrears_6m", "population": "funded == 1", "focal": f, "reference": "rest"}
            for f in ["prior_ccj == 1", "sector == 'hospitality'", "years_trading < 2", "cash_buffer_days < 20", "region == 'Wales'"]
        ]
        start = time.perf_counter()
        for spec in specs:
            referee.commit_claim(spec)
        rows.append({"operation": "commit one claim (incl. exploration prior)", "size": 19_200, "seconds": (time.perf_counter() - start) / len(specs)})
        start = time.perf_counter()
        referee.close_episode()
        rows.append({"operation": "close episode: unseal 9,600 rows, 10 claims, sign certificates", "size": 9_600, "seconds": time.perf_counter() - start})
    out = pd.DataFrame(rows)
    out.to_csv(Path(__file__).resolve().parents[1] / "results" / "overhead.csv", index=False)
    print(out.to_string())


if __name__ == "__main__":
    main()
