"""Simulation library: subgroup-experiment worlds, scripted analyst agents and the
methods compared in the paper.

A *world* is a randomised experiment (variant v in {0, 1}) with six categorical
covariates and three binary outcomes. Treatment effects live only in *effect
regions* (conjunctions of covariate levels), and are always positive, so the truth
of any subgroup claim is known exactly: "v raises outcome o in subgroup S" is true
if and only if S overlaps an effect region for o; every "decrease" claim is false.

The rolling-seal engine here calls the same ``difference_evidence`` and ``ELond``
functions as the product, with the same seeding scheme.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field

import numpy as np

from herdsman.budget import ELond, GammaPolicy, bh, e_bh
from herdsman.evalues import BettingState, difference_evidence, prior_state

LEVELS = (3, 3, 6, 4, 3, 4)
PROBS = (
    (0.45, 0.45, 0.10),
    (0.50, 0.30, 0.20),
    tuple([1 / 6] * 6),
    (0.30, 0.30, 0.20, 0.20),
    (0.50, 0.30, 0.20),
    (0.25, 0.25, 0.25, 0.25),
)
FEATURES = ("device", "channel", "region", "tenure", "plan", "age_band")
OUTCOMES = ("convert", "retain", "upsell")
BASE = (0.30, 0.55, 0.12)
MIN_ARM = 30


@dataclass(frozen=True)
class Region:
    outcome: int
    conds: tuple  # ((feature, level), ...)
    delta: float


@dataclass(frozen=True)
class Claim:
    outcome: int
    conds: tuple
    direction: str  # 'increase' | 'decrease'


@dataclass
class World:
    kind: str
    regions: list = field(default_factory=list)


@dataclass
class Data:
    X: np.ndarray  # (n, 6) int8
    v: np.ndarray  # (n,) bool
    Y: np.ndarray  # (n, 3) int8

    def take(self, idx) -> "Data":
        return Data(self.X[idx], self.v[idx], self.Y[idx])

    @staticmethod
    def concat(parts) -> "Data":
        return Data(np.concatenate([p.X for p in parts]), np.concatenate([p.v for p in parts]), np.concatenate([p.Y for p in parts]))

    def __len__(self) -> int:
        return len(self.v)


# ---------------------------------------------------------------------------- worlds
def _random_conds(rng, size: int) -> tuple:
    feats = sorted(rng.choice(len(LEVELS), size=size, replace=False).tolist())
    return tuple((f, int(rng.integers(LEVELS[f]))) for f in feats)


def draw_world(kind: str, rng: np.random.Generator) -> World:
    if kind == "null":
        return World(kind, [])
    spec = {"sparse": (1, 1), "dense": (3, 3)}[kind]
    regions = []
    for _ in range(spec[0]):
        regions.append(Region(int(rng.integers(3)), _random_conds(rng, 1), float(rng.uniform(0.03, 0.06))))
    for _ in range(spec[1]):
        regions.append(Region(int(rng.integers(3)), _random_conds(rng, 2), float(rng.uniform(0.08, 0.15))))
    return World(kind, regions)


def generate(world: World, n: int, rng: np.random.Generator) -> Data:
    X = np.column_stack([rng.choice(L, size=n, p=P) for L, P in zip(LEVELS, PROBS)]).astype(np.int8)
    v = rng.random(n) < 0.5
    p = np.tile(np.asarray(BASE, float), (n, 1))
    p[:, 0] += 0.04 * (X[:, 0] == 1) - 0.03 * (X[:, 3] == 0)  # baseline differences unrelated to treatment
    p[:, 1] += 0.05 * (X[:, 4] == 2) - 0.04 * (X[:, 5] == 3)
    p[:, 2] += 0.03 * (X[:, 1] == 2)
    for r in world.regions:
        inside = np.ones(n, dtype=bool)
        for f, level in r.conds:
            inside &= X[:, f] == level
        p[:, r.outcome] += r.delta * (inside & v)
    Y = (rng.random((n, 3)) < np.clip(p, 0.0, 1.0)).astype(np.int8)
    return Data(X, v, Y)


def is_true(claim: Claim, world: World) -> bool:
    if claim.direction != "increase":
        return False
    given = dict(claim.conds)
    for r in world.regions:
        if r.outcome == claim.outcome and all(given.get(f, level) == level for f, level in r.conds):
            return True
    return False


# ---------------------------------------------------------------------------- exploratory tests
def _phi_sf(z):
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def subgroup_tests(data: Data, order: int) -> list[tuple]:
    """All tests of v on each outcome within every subgroup defined by ``order`` covariates.

    Returns tuples (outcome, conds, estimate, z, p_two_sided, n1, n0, mean1, mean0)."""
    out = []
    X, v, Y = data.X, data.v, data.Y
    for feats in itertools.combinations(range(len(LEVELS)), order):
        dims = tuple(LEVELS[f] for f in feats)
        if feats:
            code = np.ravel_multi_index(tuple(X[:, f] for f in feats), dims)
            ncode = int(np.prod(dims))
        else:
            code = np.zeros(len(v), dtype=np.int64)
            ncode = 1
        key = code * 2 + v
        counts = np.bincount(key, minlength=2 * ncode).reshape(ncode, 2)
        n0, n1 = counts[:, 0], counts[:, 1]
        ok = (n0 >= MIN_ARM) & (n1 >= MIN_ARM)
        for o in range(Y.shape[1]):
            sums = np.bincount(key, weights=Y[:, o], minlength=2 * ncode).reshape(ncode, 2)
            with np.errstate(divide="ignore", invalid="ignore"):
                m0, m1 = sums[:, 0] / n0, sums[:, 1] / n1
                se = np.sqrt(m1 * (1 - m1) / n1 + m0 * (1 - m0) / n0)
                z = (m1 - m0) / se
            for c in np.nonzero(ok & (se > 0))[0]:
                levels = np.unravel_index(int(c), dims) if feats else ()
                conds = tuple((f, int(l)) for f, l in zip(feats, levels))
                zc = float(z[c])
                out.append((o, conds, float(m1[c] - m0[c]), zc, min(1.0, 2 * _phi_sf(abs(zc))), int(n1[c]), int(n0[c]), float(m1[c]), float(m0[c])))
    return out


def as_claim(test: tuple) -> Claim:
    return Claim(test[0], test[1], "increase" if test[2] > 0 else "decrease")


# ---------------------------------------------------------------------------- scripted analysts
def analyst_diligent(data: Data, k: int = 10, exclude=frozenset()):
    """Overall plus every single-covariate subgroup, all outcomes; commits the k strongest."""
    tests = subgroup_tests(data, 0) + subgroup_tests(data, 1)
    return tests, _top_claims(tests, k, exclude)


def analyst_forking(data: Data, k: int = 15, exclude=frozenset()):
    """Adds every two-covariate subgroup: the garden of forking paths."""
    tests = subgroup_tests(data, 0) + subgroup_tests(data, 1) + subgroup_tests(data, 2)
    return tests, _top_claims(tests, k, exclude)


def analyst_pressured(data: Data, k: int = 15, wins: int = 8, threshold: float = 0.01, exclude=frozenset()):
    """Keeps widening the search (three-way subgroups) until it has ``wins`` results below ``threshold``."""
    tests = subgroup_tests(data, 0) + subgroup_tests(data, 1) + subgroup_tests(data, 2)
    if sum(1 for t in tests if t[4] < threshold) < wins:
        tests = tests + subgroup_tests(data, 3)
    return tests, _top_claims(tests, k, exclude)


def _top_claims(tests, k, exclude):
    ranked = sorted(tests, key=lambda t: t[4])
    claims, seen = [], set(exclude)
    for t in ranked:
        c = as_claim(t)
        if c in seen:
            continue
        seen.add(c)
        claims.append((c, t))
        if len(claims) == k:
            break
    return claims


# ---------------------------------------------------------------------------- evaluation on sealed data
def _groups(claim: Claim, data: Data):
    mask = np.ones(len(data), dtype=bool)
    for f, level in claim.conds:
        mask &= data.X[:, f] == level
    y = data.Y[mask, claim.outcome].astype(float)
    treated = data.v[mask]
    return y[treated], y[~treated]


def fold_evidence(claim: Claim, fold: Data, seed: int, t: int, k: int, state: BettingState, n_orderings: int = 16):
    focal, reference = _groups(claim, fold)
    return difference_evidence(
        focal,
        reference,
        lower=0.0,
        upper=1.0,
        direction=claim.direction,
        seed=np.random.SeedSequence([seed, t, k, 0]),
        n_orderings=n_orderings,
        state=state,
    )


def claim_prior(claim: Claim, test: tuple) -> BettingState:
    """Starting bet from the exploration test, exactly as the referee builds it at commit."""
    m1, m0, n1, n0 = test[7], test[8], test[5], test[6]
    return prior_state(test[2], m1 * (1 - m1) * n1 / max(n1 - 1, 1), n1, m0 * (1 - m0) * n0 / max(n0 - 1, 1), n0, direction=claim.direction)


def holdout_pvalue(claim: Claim, holdout: Data) -> float:
    """One-sided z-test p-value in the claimed direction."""
    focal, reference = _groups(claim, holdout)
    if len(focal) < 2 or len(reference) < 2:
        return 1.0
    m1, m0 = focal.mean(), reference.mean()
    se = math.sqrt(m1 * (1 - m1) / len(focal) + m0 * (1 - m0) / len(reference))
    if se == 0:
        return 1.0
    z = (m1 - m0) / se
    return _phi_sf(z if claim.direction == "increase" else -z)


def rolling_seal(agent, d0: Data, folds: list[Data], *, alpha: float, horizon: int, seed: int, episodes: int, n_orderings: int = 16, accumulate: bool = True, policy: GammaPolicy | None = None, prior: bool = True):
    """Run the rolling-seal protocol with an agent that may commit claims in each episode.

    ``agent(exploration_data, already_committed)`` returns (tests, [(claim, test), ...]).
    Returns the list of claim entries and the exploratory tests per episode."""
    elond = ELond(alpha, policy or GammaPolicy.uniform(horizon))
    entries: list[dict] = []
    certified = 0
    released: list[Data] = []
    tests_log = []
    for k, fold in enumerate(folds, start=1):
        if k <= episodes:
            exploration = Data.concat([d0, *released]) if released else d0
            tests, chosen = agent(exploration, frozenset(e["claim"] for e in entries))
            tests_log.append(tests)
            for claim, test in chosen:
                t = len(entries) + 1
                level = elond.level(t, certified)
                if level <= 0:
                    continue
                start = claim_prior(claim, test) if prior else BettingState()
                entries.append({"claim": claim, "t": t, "alpha": level, "log_e": 0.0, "state": start, "status": "open", "episode": k, "test": test, "fold": None})
        for e in entries:
            if e["status"] != "open":
                continue
            if not accumulate and e["episode"] != k:
                continue
            ev = fold_evidence(e["claim"], fold, seed, e["t"], k, e["state"], n_orderings)
            e["log_e"] += ev.log_e
            e["state"] = ev.state
            if e["log_e"] >= -math.log(e["alpha"]):
                e["status"] = "certified"
                e["fold"] = k
                certified += 1
        released.append(fold)
    return entries, tests_log


def single_seal_ebh(chosen, holdout: Data, *, alpha: float, seed: int, n_orderings: int = 16, prior: bool = True):
    """e-BH on e-values computed on the whole holdout at once. ``chosen`` holds (claim, test) pairs."""
    evalues = []
    for i, (c, test) in enumerate(chosen):
        start = claim_prior(c, test) if prior else BettingState()
        evalues.append(math.exp(min(fold_evidence(c, holdout, seed, i + 1, 1, start, n_orderings).log_e, 700)))
    return e_bh(evalues, alpha)


# ---------------------------------------------------------------------------- scoring
def score(discoveries, world: World) -> dict:
    """discoveries: iterable of Claim. Returns R, V, T, FDP."""
    discoveries = list(discoveries)
    v = sum(1 for c in discoveries if not is_true(c, world))
    r = len(discoveries)
    return {"R": r, "V": v, "T": r - v, "FDP": v / r if r else 0.0}


def split(data: Data, exploration_fraction: float, n_folds: int, rng: np.random.Generator):
    n = len(data)
    order = rng.permutation(n)
    n0 = int(round(exploration_fraction * n))
    bounds = np.linspace(n0, n, n_folds + 1).round().astype(int)
    return data.take(order[:n0]), [data.take(order[bounds[i] : bounds[i + 1]]) for i in range(n_folds)]
