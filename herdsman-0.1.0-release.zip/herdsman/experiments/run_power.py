"""Experiment 3: power, data allocation and budget shape.

Part A  exploration fraction sweep (forking analyst, 15 claims, 3 folds)
Part B  budget shape: matched uniform horizon, over-provisioned horizon, harmonic, decaying
Part C  multi-episode analyst: number of folds/episodes, with and without evidence accumulation

Writes results/power_*.csv.
"""
from __future__ import annotations

import argparse
import math
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import simlib as S  # noqa: E402

from herdsman.budget import GammaPolicy, bh, by  # noqa: E402

ALPHA = 0.10
N_ROWS = 40_000


def _world(kind, rep, seed, salt):
    rng = np.random.default_rng([seed, salt, ("null", "sparse", "dense").index(kind), rep])
    world = S.draw_world(kind, rng)
    return world, S.generate(world, N_ROWS, rng), rng


def part_a(args):
    kind, frac, rep, seed = args
    world, data, rng = _world(kind, rep, seed, 1)
    d0, folds = S.split(data, frac, 3, rng)
    holdout = S.Data.concat(folds)
    tests, chosen = S.analyst_forking(d0, k=15)
    claims = [c for c, _ in chosen]
    ev_seed = int(rng.integers(2**62))
    p_hold = [S.holdout_pvalue(c, holdout) for c in claims]
    entries, _ = S.rolling_seal(lambda d, e: (tests, chosen), d0, folds, alpha=ALPHA, horizon=15, seed=ev_seed, episodes=1)
    out = []
    committed_true = sum(S.is_true(c, world) for c in claims)
    for method, found in {
        "herdsman": [e["claim"] for e in entries if e["status"] == "certified"],
        "holdout_bh": [c for c, keep in zip(claims, bh(p_hold, ALPHA)) if keep],
        "holdout_by": [c for c, keep in zip(claims, by(p_hold, ALPHA)) if keep],
        "single_seal_ebh": [c for c, keep in zip(claims, S.single_seal_ebh(chosen, holdout, alpha=ALPHA, seed=ev_seed)) if keep],
    }.items():
        out.append({"part": "A", "world": kind, "setting": frac, "rep": rep, "method": method, "committed_true": committed_true, **S.score(found, world)})
    return out


POLICIES = {
    "uniform_15": GammaPolicy.uniform(15),
    "uniform_50": GammaPolicy.uniform(50),
    "harmonic_15": GammaPolicy.harmonic(15),
    "decaying": GammaPolicy.decaying(),
}


def part_b(args):
    kind, rep, seed = args
    world, data, rng = _world(kind, rep, seed, 2)
    d0, folds = S.split(data, 0.4, 3, rng)
    tests, chosen = S.analyst_forking(d0, k=15)
    ev_seed = int(rng.integers(2**62))
    committed_true = sum(S.is_true(c, world) for c, _ in chosen)
    out = []
    for name, policy in POLICIES.items():
        entries, _ = S.rolling_seal(lambda d, e: (tests, chosen), d0, folds, alpha=ALPHA, horizon=15, seed=ev_seed, episodes=1, policy=policy)
        found = [e["claim"] for e in entries if e["status"] == "certified"]
        out.append({"part": "B", "world": {"null": "global_null"}.get(kind, kind), "setting": name, "rep": rep, "method": "herdsman", "committed_true": committed_true, **S.score(found, world)})
    return out


def part_c(args):
    kind, n_folds, accumulate, rep, seed = args
    world, data, rng = _world(kind, rep, seed, 3)
    d0, folds = S.split(data, 0.4, n_folds, rng)
    per_episode = math.ceil(30 / n_folds)
    ev_seed = int(rng.integers(2**62))

    def agent(d, excl):
        return S.analyst_forking(d, k=per_episode, exclude=excl)

    entries, _ = S.rolling_seal(agent, d0, folds, alpha=ALPHA, horizon=per_episode * n_folds, seed=ev_seed, episodes=n_folds, accumulate=accumulate)
    found = [e["claim"] for e in entries if e["status"] == "certified"]
    committed_true = sum(S.is_true(e["claim"], world) for e in entries)
    return [{"part": "C", "world": kind, "setting": f"K={n_folds}, {'accumulate' if accumulate else 'one-shot'}", "rep": rep, "method": "herdsman", "committed_true": committed_true, **S.score(found, world)}]


def run(fn, jobs, workers):
    rows = []
    with Pool(workers) as pool:
        for chunk in pool.imap_unordered(fn, jobs, chunksize=4):
            rows.extend(chunk)
    return rows


def summarise(raw):
    def agg(g):
        n = len(g)
        share = (g["T"] / g["committed_true"].where(g["committed_true"] > 0)).dropna()
        return pd.Series(
            {
                "reps": n,
                "FDR": g["FDP"].mean(),
                "FDR_se": g["FDP"].std(ddof=1) / math.sqrt(n),
                "mean_true": g["T"].mean(),
                "mean_false": g["V"].mean(),
                "mean_committed_true": g["committed_true"].mean(),
                "share_true_claims_certified": share.mean() if len(share) else float("nan"),
            }
        )

    return raw.groupby(["part", "world", "setting", "method"], sort=False).apply(agg, include_groups=False).reset_index()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20261109)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "results"))
    args = parser.parse_args()
    start = time.time()
    rows = []
    jobs_a = [(w, f, r, args.seed) for w in ("sparse", "dense") for f in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7) for r in range(args.reps)]
    rows += run(part_a, jobs_a, args.workers)
    print(f"part A done {time.time() - start:.0f}s", flush=True)
    jobs_b = [(w, r, args.seed) for w in ("null", "sparse", "dense") for r in range(args.reps)]
    rows += run(part_b, jobs_b, args.workers)
    print(f"part B done {time.time() - start:.0f}s", flush=True)
    jobs_c = [(w, k, acc, r, args.seed) for w in ("sparse", "dense") for k in (2, 3, 4, 6) for acc in (True, False) for r in range(max(args.reps // 2, 50))]
    rows += run(part_c, jobs_c, args.workers)
    print(f"part C done {time.time() - start:.0f}s", flush=True)
    raw = pd.DataFrame(rows)
    out = Path(args.out)
    raw.to_csv(out / "power_raw.csv", index=False)
    summary = summarise(raw)
    summary.to_csv(out / "power_summary.csv", index=False)
    print(summary.round(3).to_string())


if __name__ == "__main__":
    main()
