"""Per-run statistics for the Northfell case study, computed from the scored results and the studies.

Every number used in the paper, notebook, playbook, deck and site about the case study comes from
``run_stats()``; the prose that surrounds those numbers lives in ``casestudy_numbers.py``.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import casestudy as CS  # noqa: E402

from herdsman import Referee, verify_document  # noqa: E402

PERSONA_LABEL = {
    "neutral": "Neutral",
    "pressured": "Pressured",
    "sceptical": "Sceptical",
    "segment_hunt": "Segment-hunting brief",
}
WORLD_LABEL = {"standard": "Standard", "nowins": "No wins"}
RUN_ORDER = ["N1", "P1", "S1", "N2", "P2", "H1"]


def load_scored() -> pd.DataFrame:
    return pd.read_csv(ROOT / "results" / "casestudy_scored.csv", keep_default_na=False, na_values=[""])


def runs() -> list[dict]:
    metas = []
    for path in sorted((CS.ROOT / "runs").glob("*/meta.json")):
        meta = json.loads(path.read_text(encoding="utf-8"))
        meta.setdefault("world", "standard")
        metas.append(meta)
    order = {r: i for i, r in enumerate(RUN_ORDER)}
    return sorted(metas, key=lambda m: order.get(m["run_id"], 99))


def run_stats() -> pd.DataFrame:
    scored = load_scored()
    rows = []
    for meta in runs():
        run = meta["run_id"]
        s = scored[scored.run == run]
        allfind = s[s.kind == "unrefereed report"]
        ftype = allfind["finding_type"] if "finding_type" in allfind.columns else pd.Series("directional", index=allfind.index)
        unref = allfind[ftype != "null"]
        nulls = allfind[ftype == "null"]
        claims = s[s.kind == "committed claim"]
        disc = s[s.kind == "disclosure"]
        ref = Referee(CS.ROOT / "runs" / run / "study")
        claim_docs = ref.claims()
        ph1 = phase1_tests(ref)
        verify = ref.verify()
        # one row per claim (family members share a status)
        top = claims.assign(claim=claims["item"].str.split(".").str[0])
        per_claim = top.groupby("claim").agg(status=("status", "first"), episode=("episode", "first"), any_true=("is_true", lambda x: bool((x == True).any())), all_scored=("is_true", lambda x: bool(x.notna().all())))
        cert = per_claim[per_claim.status == "certified"]
        rows.append(
            {
                "run": run,
                "persona": meta["persona"],
                "world": meta["world"],
                "label": f"{PERSONA_LABEL.get(meta['persona'], meta['persona'])}",
                "world_label": WORLD_LABEL.get(meta["world"], meta["world"]),
                "tests": ph1["distinct"],
                "test_calls": ph1["calls"],
                "significant": ph1["significant"],
                "tests_all_calls": int(disc["tests_logged"].iloc[0]) if len(disc) else 0,
                "families": int(disc["families"].iloc[0]) if len(disc) else 0,
                "findings": int(len(unref)),
                "findings_true": int((unref.is_true == True).sum()),
                "findings_false": int((unref.is_true == False).sum()),
                "findings_unscored": int(unref.is_true.isna().sum()),
                "null_findings": int(len(nulls)),
                "null_correct": int((nulls.is_true == True).sum()),
                "null_wrong": int((nulls.is_true == False).sum()),
                "claims": int(len(per_claim)),
                "claims_ep1": int((per_claim.episode == 1).sum()),
                "claims_ep2": int((per_claim.episode == 2).sum()),
                "claims_true": int(per_claim.any_true.sum()),
                "claims_false": int(((~per_claim.any_true) & per_claim.all_scored).sum()),
                "certified": int(len(cert)),
                "certified_true": int(cert.any_true.sum()),
                "certified_false": int(((~cert.any_true) & cert.all_scored).sum()),
                "true_not_certified": int((per_claim.any_true & (per_claim.status != "certified")).sum()),
                "false_not_certified": int(((~per_claim.any_true) & per_claim.all_scored & (per_claim.status != "certified")).sum()),
                "verify_ok": bool(verify["ok"]),
                "ledger_records": int(verify["ledger"]["records"]),
                "certificates": len(verify["certificates"]),
                "signatures_ok": int(sum(c["signature_ok"] for c in verify["certificates"])),
                "study_closed": any(c["status"] in ("certified", "expired", "failed") for c in claim_docs) and not ref.budget().get("accepting_claims", True),
            }
        )
    return pd.DataFrame(rows)


def phase1_tests(ref: Referee) -> dict:
    """Tests logged before the agent's first commit, i.e. behind its unrefereed report."""
    from herdsman.canonical import canonical_json

    records = list(ref.ledger.records())
    first_commit = next((r["seq"] for r in records if r["type"] == "commit"), None)
    calls = [r for r in records if r["type"] == "explore" and (first_commit is None or r["seq"] < first_commit)]
    seen, significant = {}, 0
    for r in calls:
        key = canonical_json(r["payload"]["spec"])
        if key in seen:
            continue
        p = r["payload"].get("result", {}).get("p_two_sided")
        seen[key] = p
        significant += int(p is not None and p < 0.05)
    return {"calls": len(calls), "distinct": len(seen), "significant": significant}


def example_certificate(run: str | None = None) -> dict:
    """The certificate of the certified claim with the smallest evidence margin, from the given run or any."""
    best = None
    for meta in runs():
        if run and meta["run_id"] != run:
            continue
        ref = Referee(CS.ROOT / "runs" / meta["run_id"] / "study")
        for c in ref.claims():
            if c["status"] != "certified":
                continue
            margin = c["log10_e"] - math.log10(c["threshold_e"])
            if best is None or margin < best[0]:
                best = (margin, meta["run_id"], c["id"])
    if best is None:
        raise ValueError("no certified claim")
    _, run_id, cid = best
    ref = Referee(CS.ROOT / "runs" / run_id / "study")
    cert = ref.certificate(cid)
    ok = verify_document(cert, ref.params["referee_public_key"])["ok"]
    return {"run": run_id, "claim_id": cid, "certificate": cert, "signature_ok": ok}


if __name__ == "__main__":
    pd.set_option("display.width", 220)
    print(run_stats().to_string())
