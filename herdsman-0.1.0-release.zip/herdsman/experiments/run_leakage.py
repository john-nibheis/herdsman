"""Experiment 2: the holdout-reuse attack (after Dwork et al., 2015).

Global null: 200 noise features, a binary outcome independent of all of them.
Phase 1: the analyst commits 200 single-feature claims and sees what the referee
releases about them. Phase 2: it builds a composite score from what it learned and
claims that the score predicts the outcome. The composite is null by construction.

Arms
  reuse/estimates   one 20k holdout; per-claim holdout estimates are released
  reuse/bits        one 20k holdout; only "evidence grew (e > 1)" bits are released
  reuse/certified   one 20k holdout; only certification decisions are released
  rolling/full      rolling seal: phase 1 on fold 1 (10k), fold 1 then released in full;
                    the composite is built from exploration + fold 1 and tested on fold 2

Writes results/leakage_raw.csv and results/leakage_summary.csv.
"""
from __future__ import annotations

import argparse
import math
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import pandas as pd

from herdsman.budget import ELond, GammaPolicy
from herdsman.evalues import BettingState, difference_evidence

D = 200
N_EXPLORE, N_FOLD = 10_000, 10_000
ALPHA = 0.10
HORIZON = D + 1


def _phi_sf(z):
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def _estimates(X, y):
    high = X > 0
    n_high = high.sum(axis=0)
    n_low = len(y) - n_high
    s_high = y @ high
    m_high = s_high / n_high
    m_low = (y.sum() - s_high) / n_low
    se = np.sqrt(m_high * (1 - m_high) / n_high + m_low * (1 - m_low) / n_low)
    return m_high - m_low, (m_high - m_low) / se


def _evidence(x, y, direction, seed, n_orderings, state=None):
    return difference_evidence(y[x > 0], y[x <= 0], lower=0, upper=1, direction=direction, seed=seed, n_orderings=n_orderings, state=state)


def _composite_outcome(score, y, alpha_t, seed):
    ev = _evidence(score, y, "increase", seed, 16)
    est, z = _estimates(score[:, None], y)
    return ev.log_e, bool(ev.log_e >= -math.log(alpha_t)), bool(_phi_sf(float(z[0])) < 0.05)


def one_rep(args):
    rep, base_seed = args
    rng = np.random.default_rng([base_seed, rep])
    n = N_EXPLORE + 2 * N_FOLD
    X = rng.standard_normal((n, D)).astype(np.float32)
    y = (rng.random(n) < 0.3).astype(float)
    e0 = slice(0, N_EXPLORE)
    f1 = slice(N_EXPLORE, N_EXPLORE + N_FOLD)
    f2 = slice(N_EXPLORE + N_FOLD, n)
    hold = slice(N_EXPLORE, n)
    seed = int(rng.integers(2**62))
    elond = ELond(ALPHA, GammaPolicy.uniform(HORIZON))

    est0, _ = _estimates(X[e0], y[e0])
    directions = np.where(est0 > 0, 1.0, -1.0)  # phase-1 claims follow the exploration sign
    rows = []

    # ---------------- reuse arms: phase 1 on the whole holdout
    est_h, _ = _estimates(X[hold], y[hold])
    log_e = np.array(
        [
            _evidence(X[hold][:, j], y[hold], "increase" if directions[j] > 0 else "decrease", np.random.SeedSequence([seed, j + 1, 1, 0]), 2).log_e
            for j in range(D)
        ]
    )
    certified = 0
    cert_flags = np.zeros(D, dtype=bool)
    for j in range(D):  # e-LOND in commit order
        if log_e[j] >= -math.log(elond.level(j + 1, certified)):
            cert_flags[j] = True
            certified += 1
    alpha_composite = elond.level(D + 1, certified)
    weights = {
        "reuse/estimates": np.sign(est_h),
        "reuse/bits": directions * (log_e > 0),
        "reuse/certified": directions * cert_flags,
    }
    for arm, w in weights.items():
        if not np.any(w):
            rows.append({"rep": rep, "arm": arm, "features_used": 0, "log_e": 0.0, "certified": False, "naive_p05": False, "phase1_certified": int(certified)})
            continue
        score = X[hold] @ w.astype(np.float32)
        le, cert, naive = _composite_outcome(score, y[hold], alpha_composite, np.random.SeedSequence([seed, D + 1, 1, 0]))
        rows.append({"rep": rep, "arm": arm, "features_used": int(np.count_nonzero(w)), "log_e": le, "certified": cert, "naive_p05": naive, "phase1_certified": int(certified)})

    # ---------------- rolling seal: phase 1 on fold 1, composite on fresh fold 2
    log_e1 = np.array(
        [
            _evidence(X[f1][:, j], y[f1], "increase" if directions[j] > 0 else "decrease", np.random.SeedSequence([seed, j + 1, 1, 0]), 2).log_e
            for j in range(D)
        ]
    )
    certified = 0
    for j in range(D):
        if log_e1[j] >= -math.log(elond.level(j + 1, certified)):
            certified += 1
    alpha_composite = elond.level(D + 1, certified)
    released = slice(0, N_EXPLORE + N_FOLD)  # exploration plus the spent fold, in full
    est_r, _ = _estimates(X[released], y[released])
    score = X[f2] @ np.sign(est_r).astype(np.float32)
    le, cert, naive = _composite_outcome(score, y[f2], alpha_composite, np.random.SeedSequence([seed, D + 1, 2, 0]))
    rows.append({"rep": rep, "arm": "rolling/full", "features_used": D, "log_e": le, "certified": cert, "naive_p05": naive, "phase1_certified": int(certified)})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reps", type=int, default=400)
    parser.add_argument("--seed", type=int, default=20261108)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "results"))
    args = parser.parse_args()
    start = time.time()
    rows = []
    with Pool(args.workers) as pool:
        for i, chunk in enumerate(pool.imap_unordered(one_rep, [(r, args.seed) for r in range(args.reps)], chunksize=2)):
            rows.extend(chunk)
            if (i + 1) % 50 == 0:
                print(f"{i + 1}/{args.reps} reps, {time.time() - start:.0f}s", flush=True)
    raw = pd.DataFrame(rows)
    out = Path(args.out)
    raw.to_csv(out / "leakage_raw.csv", index=False)
    summary = (
        raw.groupby("arm", sort=False)
        .agg(
            reps=("rep", "size"),
            false_certification_rate=("certified", "mean"),
            naive_holdout_p05_rate=("naive_p05", "mean"),
            median_log10_e=("log_e", lambda s: float(np.median(s) / math.log(10))),
            mean_features_used=("features_used", "mean"),
            phase1_false_certifications=("phase1_certified", "mean"),
        )
        .reset_index()
    )
    summary["false_certification_se"] = np.sqrt(summary["false_certification_rate"] * (1 - summary["false_certification_rate"]) / summary["reps"])
    summary.to_csv(out / "leakage_summary.csv", index=False)
    print(summary.round(4).to_string())
    print(f"done in {time.time() - start:.0f}s")


if __name__ == "__main__":
    main()
