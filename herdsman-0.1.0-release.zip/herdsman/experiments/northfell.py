"""Northfell Business Finance: a synthetic SME lending journey experiment with a known truth.

Northfell (fictional) randomised 48,000 small-business loan applications between its
current application journey (A) and a new open-banking pre-fill journey (B). The data
mix real effects, proxies and plausible-looking noise:

Real effects of journey B
  completion          +6 points for mobile applicants, +4 points for cloud-accounting users (additive)
  minutes in journey  -6 minutes for cloud users, +3 minutes for applicants with no accounting software
  6-month arrears     +0.75 on the log-odds scale for broker-introduced funded loans (a hidden harm)
Real drivers of arrears among funded loans
  prior CCJ (+), years trading (-), cash buffer (-), hospitality (+), construction (+), turnover band (-),
  and proxies of turnover (employees, VAT registration, requested amount)
Everything else (region, weekday, hour, browser, e-mail domain, logo upload, referral code,
marketing consent, form language, company-name length, director count) has no effect.

``Oracle`` computes the true value of any claim the referee can express by averaging the
generator's expected outcomes over a large independent population, weighting for the
completion and approval states that ``completed`` and ``funded`` filters condition on.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import pandas as pd

from herdsman.claims import Claim
from herdsman.filters import Filter

REGIONS = {
    "Scotland": 0.09, "North East": 0.04, "North West": 0.11, "Yorkshire": 0.08, "East Midlands": 0.07,
    "West Midlands": 0.09, "East of England": 0.09, "London": 0.17, "South East": 0.14, "South West": 0.07,
    "Wales": 0.04, "Northern Ireland": 0.01,
}
SECTORS = {
    "retail": 0.16, "hospitality": 0.12, "construction": 0.15, "professional services": 0.20,
    "manufacturing": 0.09, "transport": 0.08, "health": 0.07, "other": 0.13,
}
BANDS = ["<100k", "100k-250k", "250k-1m", "1m-5m", ">5m"]
OUTCOMES = ["completed", "funded", "arrears_6m", "minutes_in_journey"]
BOUNDS = {"minutes_in_journey": (0.0, 120.0)}

DESCRIPTIONS = {
    "application_id": "Application reference",
    "variant": "Randomised journey: A = current, B = open-banking pre-fill",
    "channel": "How the application arrived: direct, broker or partner",
    "device": "Device used to start the application",
    "region": "Business location (UK region)",
    "sector": "Business sector",
    "accounting_software": "Accounting software the business uses: cloud, desktop or none",
    "years_trading": "Years since incorporation",
    "turnover_band": "Annual turnover band (1 = under 100k ... 5 = over 5m)",
    "turnover_label": "Annual turnover band label",
    "employees": "Number of employees",
    "vat_registered": "1 if VAT registered",
    "prior_ccj": "1 if a County Court Judgment was recorded in the last six years",
    "cash_buffer_days": "Days of operating costs covered by cash at application",
    "director_count": "Number of directors",
    "requested_amount_k": "Loan amount requested, in thousands of pounds",
    "application_weekday": "Day of week the application started",
    "started_hour": "Hour of day the application started (0-23)",
    "email_domain": "Applicant e-mail domain type",
    "browser": "Browser used",
    "logo_uploaded": "1 if the business uploaded a logo to its profile",
    "referral_code_used": "1 if a referral code was entered",
    "marketing_consent": "1 if the applicant consented to marketing",
    "form_language": "Language of the application form: en or cy (Welsh)",
    "company_name_length": "Characters in the registered company name",
    "completed": "1 if the application was completed and submitted",
    "funded": "1 if the loan was approved and paid out",
    "arrears_6m": "For funded loans: 1 if 30+ days in arrears within six months (blank if not funded)",
    "minutes_in_journey": "Minutes spent in the application journey",
}


def _choice(rng, mapping, n):
    keys = list(mapping)
    p = np.array([mapping[k] for k in keys], float)
    return np.array(keys, dtype=object)[rng.choice(len(keys), size=n, p=p / p.sum())]


def features(n: int, rng: np.random.Generator) -> pd.DataFrame:
    channel = _choice(rng, {"direct": 0.55, "broker": 0.30, "partner": 0.15}, n)
    device = _choice(rng, {"mobile": 0.45, "desktop": 0.50, "tablet": 0.05}, n)
    region = _choice(rng, REGIONS, n)
    sector = _choice(rng, SECTORS, n)
    software = _choice(rng, {"cloud": 0.55, "desktop": 0.20, "none": 0.25}, n)
    years = np.clip(np.round(np.exp(rng.normal(1.6, 0.9, n)) * 4) / 4, 0.25, 40.0)
    latent = 0.6 * (np.log(years) - 1.6) / 0.9 + 0.8 * rng.standard_normal(n)
    band = np.digitize(latent, np.quantile(latent, [0.25, 0.55, 0.82, 0.95])) + 1
    employees = np.maximum(1, np.round(np.array([2, 5, 12, 35, 90])[band - 1] * np.exp(rng.normal(0, 0.5, n)))).astype(int)
    vat = (rng.random(n) < np.array([0.15, 0.75, 0.97, 0.99, 1.0])[band - 1]).astype(int)
    amount = np.clip(np.round(np.array([15, 35, 80, 180, 320])[band - 1] * np.exp(rng.normal(0, 0.45, n))), 5, 500)
    weekday = _choice(rng, {"Mon": 0.18, "Tue": 0.18, "Wed": 0.17, "Thu": 0.17, "Fri": 0.15, "Sat": 0.08, "Sun": 0.07}, n)
    hour = np.clip(np.round(rng.normal(12, 3.5, n)), 0, 23).astype(int)
    language = np.where(region == "Wales", np.where(rng.random(n) < 0.35, "cy", "en"), np.where(rng.random(n) < 0.003, "cy", "en"))
    return pd.DataFrame(
        {
            "channel": channel,
            "device": device,
            "region": region,
            "sector": sector,
            "accounting_software": software,
            "years_trading": years,
            "turnover_band": band,
            "turnover_label": np.array(BANDS, dtype=object)[band - 1],
            "employees": employees,
            "vat_registered": vat,
            "prior_ccj": (rng.random(n) < 0.06).astype(int),
            "cash_buffer_days": np.clip(np.round(rng.gamma(1.6, 22.0, n)), 0, 180),
            "director_count": rng.choice([1, 2, 3, 4], size=n, p=[0.45, 0.35, 0.15, 0.05]),
            "requested_amount_k": amount,
            "application_weekday": weekday,
            "started_hour": hour,
            "email_domain": _choice(rng, {"gmail": 0.35, "outlook": 0.15, "company": 0.40, "other": 0.10}, n),
            "browser": _choice(rng, {"chrome": 0.55, "safari": 0.30, "edge": 0.10, "firefox": 0.05}, n),
            "logo_uploaded": (rng.random(n) < 0.30).astype(int),
            "referral_code_used": (rng.random(n) < 0.12).astype(int),
            "marketing_consent": (rng.random(n) < 0.48).astype(int),
            "form_language": language,
            "company_name_length": rng.integers(5, 41, size=n),
        }
    )


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def expectations(f: pd.DataFrame, b_wins: bool = True) -> dict:
    """Expected outcomes for each row under each journey.

    With ``b_wins=False`` (the "no wins" world) journey B has no effect on completion or
    journey time; its harm to broker arrears remains."""
    mobile = (f["device"] == "mobile").to_numpy()
    tablet = (f["device"] == "tablet").to_numpy()
    cloud = (f["accounting_software"] == "cloud").to_numpy()
    none = (f["accounting_software"] == "none").to_numpy()
    broker = (f["channel"] == "broker").to_numpy()
    partner = (f["channel"] == "partner").to_numpy()
    hosp = (f["sector"] == "hospitality").to_numpy()
    cons = (f["sector"] == "construction").to_numpy()
    years = np.minimum(f["years_trading"].to_numpy(float), 20.0)
    cash = f["cash_buffer_days"].to_numpy(float)
    ccj = f["prior_ccj"].to_numpy(float)
    band = f["turnover_band"].to_numpy(float)
    pc_a = 0.62 + 0.08 * broker + 0.03 * partner - 0.07 * mobile - 0.04 * tablet + 0.05 * cloud - 0.06 * none
    m_a = 24.0 + 7.0 * mobile + 3.0 * tablet - 3.0 * cloud + 5.0 * none
    if b_wins:
        pc_b = pc_a + 0.06 * mobile + 0.04 * cloud
        m_b = m_a - 6.0 * cloud + 3.0 * none
    else:
        pc_b = pc_a.copy()
        m_b = m_a.copy()
    pa = _sigmoid(1.1 + 0.07 * years + 0.012 * cash - 1.6 * ccj - 0.5 * hosp + 0.25 * (band - 3))
    risk = -3.0 - 0.06 * years - 0.012 * cash + 1.2 * ccj + 0.6 * hosp + 0.35 * cons - 0.15 * (band - 3)
    return {
        "pc": {"A": pc_a, "B": pc_b},
        "minutes": {"A": m_a, "B": m_b},
        "pa": pa,
        "parr": {"A": _sigmoid(risk), "B": _sigmoid(risk + 0.75 * broker)},
    }


def generate(n: int = 48_000, seed: int = 20261107, b_wins: bool = True) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    f = features(n, rng)
    variant = np.where(rng.random(n) < 0.5, "B", "A")
    ex = expectations(f, b_wins)
    is_b = variant == "B"
    pc = np.where(is_b, ex["pc"]["B"], ex["pc"]["A"])
    completed = rng.random(n) < pc
    approved = rng.random(n) < ex["pa"]
    funded = completed & approved
    parr = np.where(is_b, ex["parr"]["B"], ex["parr"]["A"])
    arrears = np.where(funded, (rng.random(n) < parr).astype(float), np.nan)
    mean_minutes = np.where(is_b, ex["minutes"]["B"], ex["minutes"]["A"])
    minutes = np.clip(np.round(mean_minutes * rng.gamma(6.0, 1.0 / 6.0, n), 1), 1.0, 120.0)
    out = f.copy()
    out.insert(0, "variant", variant)
    out.insert(0, "application_id", [f"NF{100000 + i}" for i in range(n)])
    out["completed"] = completed.astype(int)
    out["funded"] = funded.astype(int)
    out["arrears_6m"] = arrears
    out["minutes_in_journey"] = minutes
    return out


@dataclass
class Truth:
    value: float  # true difference (focal - reference) or mean - value, in the claim's orientation (positive = claim direction)
    true: bool
    supported: bool
    note: str = ""


class Oracle:
    """Exact-in-expectation truth for claims about the Northfell population."""

    OUTCOME_COLUMNS = {"completed", "funded", "arrears_6m", "minutes_in_journey"}
    TOLERANCE = {"completed": 0.002, "funded": 0.002, "arrears_6m": 0.002, "minutes_in_journey": 0.2}

    def __init__(self, n: int = 300_000, seed: int = 99, b_wins: bool = True):
        rng = np.random.default_rng(seed)
        f = features(n, rng)
        ex = expectations(f, b_wins)
        parts = []
        for v in ("A", "B"):
            pc, pa = ex["pc"][v], ex["pa"]
            for completed, funded, weight in ((0, 0, 1 - pc), (1, 0, pc * (1 - pa)), (1, 1, pc * pa)):
                part = f.copy()
                part["variant"] = v
                part["completed"] = completed
                part["funded"] = funded
                part["arrears_6m"] = ex["parr"][v] if funded else np.nan
                part["minutes_in_journey"] = ex["minutes"][v]
                part["_w"] = 0.5 * weight
                parts.append(part)
        frame = pd.concat(parts, ignore_index=True)
        for column in frame.columns:
            if frame[column].dtype == object:
                frame[column] = frame[column].astype("category")
        self.frame = frame
        self.weights = frame["_w"].to_numpy()

    def evaluate(self, claim: Claim) -> Truth:
        unsupported = claim.referenced_columns() & {"arrears_6m", "minutes_in_journey"}
        if unsupported:
            return Truth(float("nan"), False, False, f"filters on {sorted(unsupported)} are not supported by the oracle")
        frame = claim.with_derived(self.frame) if claim.derived else self.frame
        focal, reference = claim.groups(frame)
        y = frame[claim.outcome].to_numpy(float)
        w = self.weights

        def mean(mask):
            total = w[mask].sum()
            return float((w[mask] * y[mask]).sum() / total) if total > 0 else float("nan")

        if reference is None:
            raw = mean(focal) - float(claim.value)
            value = raw if claim.direction == "increase" else -raw
            margin = 0.0
        else:
            raw = mean(focal) - mean(reference)
            value = raw if claim.direction == "increase" else -raw
            margin = float(claim.margin or 0.0)
        tol = self.TOLERANCE[claim.outcome]
        return Truth(value, bool(value > margin + tol), True)  # a negative margin is a non-inferiority claim


def data_dictionary_markdown(frame: pd.DataFrame) -> str:
    lines = ["# Northfell application journey experiment: data dictionary", "", "| Column | Type | Description |", "|---|---|---|"]
    for column in frame.columns:
        kind = "number" if pd.api.types.is_numeric_dtype(frame[column]) else "text"
        lines.append(f"| `{column}` | {kind} | {DESCRIPTIONS.get(column, '')} |")
    return "\n".join(lines) + "\n"
