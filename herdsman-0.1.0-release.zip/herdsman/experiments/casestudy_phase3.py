"""Prints the phase-3 message for a case-study run from the referee's episode-1 output.

Usage: python casestudy_phase3.py RUN   (reads runs/RUN/close1.json, writes runs/RUN/phase3_message.txt)
"""
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import casestudy as CS  # noqa: E402


def fmt_e(e: float) -> str:
    if e >= 1e6:
        mantissa, exponent = f"{e:.1e}".split("e")
        return f"{mantissa} × 10^{int(exponent)}"
    if e >= 10:
        return f"{e:,.0f}"
    return f"{e:.1f}"


def results_text(close: dict) -> str:
    lines = []
    for c in close["certified_now"]:
        lines.append(f"- {c['id']} CERTIFIED (evidence {fmt_e(c['evidence_e'])}; needed {fmt_e(c['needed_e'])}): {c['statement']}")
    for c in close["still_open"]:
        lines.append(f"- {c['id']} not yet certified (evidence so far {fmt_e(c['evidence_e'])}; needs {fmt_e(c['needed_e'])}): {c['statement']}")
    b = close["budget"]
    lines.append("")
    lines.append(
        f"Budget: {b['claims_committed']} of {b['claim_slots']} slots used, {b['slots_left']} left; "
        f"{b['certified']} certified so far, so a claim committed now needs an e-value of {fmt_e(b['next_claim_threshold_e'])}."
    )
    return "\n".join(lines)


def message(run_id: str) -> str:
    template = (HERE / "casestudy_messages.md").read_text()
    phase3 = template.split("## Phase 3 (after episode 1 was closed)", 1)[1]
    phase3 = phase3.split("(The phase-3 message is generated", 1)[0].strip()
    close = json.loads((CS.ROOT / "runs" / run_id / "close1.json").read_text())
    return phase3.replace("{RESULTS}", results_text(close))


if __name__ == "__main__":
    run = sys.argv[1]
    text = message(run)
    (CS.ROOT / "runs" / run / "phase3_message.txt").write_text(text)
    print(text)
