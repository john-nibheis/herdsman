"""Sentences about the case study for the paper, playbook, deck and site.

Every number below is computed from casestudy_stats.run_stats() or the stored studies; the
wording is fixed text chosen after the runs were complete. Quotations are verbatim from the
agents' reports in each run's workspace.
"""
from __future__ import annotations

import html
import json
import math
from pathlib import Path

import pandas as pd

import casestudy as CS
from casestudy_numbers import W, plural, w
from herdsman import Referee


def _claims_frame(runs: list[str]) -> pd.DataFrame:
    rows = []
    for run in runs:
        ref = Referee(CS.ROOT / "runs" / run / "study")
        for c in ref.claims():
            m = c["members"][0]
            rows.append(
                {
                    "run": run,
                    "id": c["id"],
                    "status": c["status"],
                    "episode": c["episode"],
                    "certified_fold": c.get("certified_fold"),
                    "outcome": m["outcome"],
                    "population": m.get("population") or "",
                    "focal": m.get("focal") or "",
                    "reference": m.get("reference") or "",
                    "direction": m["direction"],
                    "margin": float(m.get("margin") or 0.0),
                    "threshold_e": c["threshold_e"],
                    "statement": c["statement"],
                }
            )
    return pd.DataFrame(rows)


def _truth(scored: pd.DataFrame) -> pd.DataFrame:
    c = scored[scored.kind == "committed claim"].copy()
    c["id"] = c["item"].str.split(".").str[0]
    return c.groupby(["run", "id"]).agg(is_true=("is_true", lambda x: bool((x == True).any())), true_value=("true_value", "first")).reset_index()  # noqa: E712


def _broker_harm(cf: pd.DataFrame) -> pd.DataFrame:
    is_broker = cf.population.str.contains("broker") & ~cf.population.str.contains("!=") & ~cf.population.str.contains("not ")
    return cf[(cf.outcome == "arrears_6m") & is_broker & cf.focal.str.contains("'B'") & (cf.direction == "increase") & (cf.margin == 0.0) & (cf.episode == 1)]


def _episode2_bars() -> list[float]:
    bars = []
    for path in sorted((CS.ROOT / "runs").glob("*/close1.json")):
        bars.append(json.loads(path.read_text())["budget"]["next_claim_threshold_e"])
    return bars


def _fmt_e(x: float) -> str:
    return f"{x:,.0f}"


def values(s: pd.DataFrame, ST) -> dict[str, str]:
    scored = ST.load_scored()
    runs = list(s.run)
    cf = _claims_frame(runs).merge(_truth(scored), on=["run", "id"], how="left")
    by = s.set_index("run")
    V: dict[str, str] = {}

    n_runs = len(s)
    t_min, t_max = int(s.tests.min()), int(s.tests.max())
    effects, effects_false = int(s.findings.sum()), int(s.findings_false.sum())
    nulls, nulls_ok = int(s.null_findings.sum()), int(s.null_correct.sum())
    claims, claims_false = int(s.claims.sum()), int(s.claims_false.sum())
    cert, cert_false = int(s.certified.sum()), int(s.certified_false.sum())
    true_claims = int(s.claims_true.sum())
    cert_true = int(s.certified_true.sum())
    missed = int(s.true_not_certified.sum())
    share = cert_true / true_claims if true_claims else float("nan")
    std = s[s.world == "standard"]
    nw = s[s.world == "nowins"]
    noninf = cf[cf.margin < 0]
    noninf_runs = noninf.run.nunique()
    noninf_cert = int((noninf.status == "certified").sum())
    noninf_cert_true = int(((noninf.status == "certified") & noninf.is_true).sum())
    harm = _broker_harm(cf)
    harm_cert = harm[harm.status == "certified"]
    harm_fold = harm_cert.certified_fold.dropna().astype(int)
    bars = _episode2_bars()
    funded_per_fold = int(round(CS.full_data("standard").funded.mean() * 9600, -2))
    missed_frame = cf[(cf.is_true == True) & (cf.status != "certified")]  # noqa: E712
    missed_arrears = int((missed_frame.outcome == "arrears_6m").sum())
    missed_noninf = int((missed_frame.margin < 0).sum())
    ma = missed_frame[(missed_frame.outcome == "arrears_6m") & (missed_frame.margin >= 0)].true_value.abs()
    lo_pp, hi_pp = (100 * ma.min(), 100 * ma.max()) if len(ma) else (float("nan"), float("nan"))
    missed_arrears = int(len(ma))
    missed_noninf = int((missed_frame.margin < 0).sum())
    cert_false_text = "none of them false" if cert_false == 0 else f"{plural(cert_false, 'of them')} false".replace("of thems", "of them")

    # ---- abstract and introduction -------------------------------------------------------
    committed_text = "every claim they then committed was true" if claims_false == 0 else f"{w(claims_false)} of the {claims} claims they then committed {'was' if claims_false == 1 else 'were'} false"
    V["case_abstract_sentence"] = (
        f"In a live case study, {w(n_runs)} frontier AI agents analysed a synthetic lending experiment under neutral, pressured, sceptical and "
        f"segment-hunting briefs. Their unrefereed reports contained {'no false effects' if effects_false == 0 else plural(effects_false, 'false effect')}; "
        f"{committed_text}, and the referee certified {cert} of the {claims}{'' if claims_false == 0 else ', ' + cert_false_text}, leaving mainly small arrears effects unconfirmed."
    )
    V["case_intro_sentence"] = (
        f"In a live case study (Section 7), {w(n_runs)} AI agents ran between {t_min} and {t_max} distinct logged tests before reporting. None of their "
        f"unrefereed reports contained a false effect, even under pressure for wins that did not exist or a brief that asked for every segment where the "
        f"new journey won at p < 0.05. "
        + (f"All {claims} claims they then committed were true; the referee certified {cert} and left {missed}, mostly small arrears effects, uncertified."
           if claims_false == 0 else
           f"The referee certified {cert} of the {claims} claims they then committed, {cert_false_text}; the price was {plural(missed, 'true claim')} left uncertified.")
    )

    # ---- results -----------------------------------------------------------------------
    p1 = (
        f"Table 4 summarises the runs. In the standard world the neutral, pressured and sceptical agents ran {by.loc['N1', 'tests']}, "
        f"{by.loc['P1', 'tests']} and {by.loc['S1', 'tests']} distinct logged tests and reported {by.loc['N1', 'findings']}, {by.loc['P1', 'findings']} "
        f"and {by.loc['S1', 'findings']} effects; every one was true. The pressured agent's report included the wins its chief executive wanted, "
        "because they existed, and put the broker-arrears harm beside them; in its own words, \"I didn't pad out the requested five wins.\" "
        f"In the no-wins world the neutral, pressured and segment-hunting agents ran {by.loc['N2', 'tests']}, {by.loc['P2', 'tests']} and "
        f"{by.loc['H1', 'tests']} distinct tests. None reported a win for journey B. The pressured agent wrote that no subgroup gain survived correction, \"so I "
        "reported no wins rather than the five the Chief Executive asked for.\" The segment-hunting agent did as asked and compared the journeys in 89 segments on "
        "three outcomes; it found that B \"won\" at p < 0.05 in 6 of 267 comparisons, \"fewer than the 6.7 expected by chance\", applied a correction "
        "the brief had not asked for, and reported none of them. "
        f"Across the {w(n_runs)} reports the agents stated {effects} effects, {'none' if effects_false == 0 else w(effects_false)} of them false, and "
        f"{plural(nulls, 'null result')} (\"no detectable effect of journey B on completion\"), {'all' if nulls_ok == nulls else w(nulls_ok)} correct."
    )
    # composition of the true claims left uncertified
    def _n_focal(row):
        ref = Referee(CS.ROOT / "runs" / row.run / "study")
        c = next(x for x in ref.claims() if x["id"] == row.id)
        return [t["members"][0]["n_focal"] for t in c["trajectory"]]

    m_arr = missed_frame[(missed_frame.outcome == "arrears_6m") & (missed_frame.margin >= 0)]
    m_ni = missed_frame[missed_frame.margin < 0]
    m_oth = missed_frame.drop(index=m_arr.index.union(m_ni.index))
    sizes = [n for r in m_arr.itertuples() for n in _n_focal(r)]
    hosp = m_arr[m_arr.statement.str.contains("ospitality")]
    hosp_tv = hosp.true_value.mean() if len(hosp) else float("nan")
    oth_room = ((m_oth.true_value - m_oth.margin.clip(lower=0)) * 100) if len(m_oth) else pd.Series(dtype=float)
    power_line = (
        f"Every one was true, so the case study measures the referee's power rather than its protection: it certified {cert} of them ({100 * share:.0f}%)."
        if claims_false == 0
        else f"{W(claims_false)} {'was' if claims_false == 1 else 'were'} false. The referee certified {cert}, {cert_false_text}, and {cert_true} of the {true_claims} true claims ({100 * share:.0f}%)."
    )
    parts = [f"{w(len(m_arr))} were arrears differences of {100 * m_arr.true_value.abs().min():.1f} to {100 * m_arr.true_value.abs().max():.1f} percentage points in subgroups of {min(sizes):,} to {max(sizes):,} funded loans per fold"]
    if len(m_oth):
        late = " committed in episode 2, with two folds left," if (m_oth.episode == 2).all() else ""
        parts.append(f"{w(len(m_oth))} were completion or funding gains{late} whose claimed margin left {oth_room.min():.1f} to {oth_room.max():.1f} points of room")
    if len(m_ni):
        parts.append(f"{w(len(m_ni))} were non-inferiority claims")
    missed_text = ", ".join(parts[:-1]) + " and " + parts[-1] if len(parts) > 1 else parts[0]
    p2 = (
        f"With the referee in place the agents committed {claims} claims, {int((cf.episode == 1).sum())} in episode 1 and {int((cf.episode == 2).sum())} "
        f"in episode 2. {power_line} Of the {plural(missed, 'true claim')} it did not certify, {missed_text}. "
        f"The hospitality effect, left uncertified in {'all ' + w(hosp.run.nunique()) if hosp.run.nunique() == n_runs else w(hosp.run.nunique())} runs, is instructive: "
        f"the agents saw arrears of about 6.7% against 3.4% in the exploration data, a gap of more than three points, but the true gap is {100 * hosp_tv:.1f} points. "
        "Claims chosen because they look strong are biased upwards, and fresh data see the smaller truth. "
        f"The most consequential finding, journey B's harm to broker arrears, also took longest. Each of the {w(len(harm))} agents committed it in episode 1, "
        f"when it needed an e-value of 200, and reached between {_fmt_e(min(_first_fold(harm)))} and {_fmt_e(max(_first_fold(harm)))} on fold 1; "
        f"{'all were' if len(harm_cert) == len(harm) else w(len(harm_cert)) + ' were'} certified when "
        f"{'fold 2 was' if set(harm_fold) == {2} else 'later folds were'} opened. In the meantime every agent told the executive committee that the harm "
        "was not yet confirmed, and every one advised pausing or withdrawing journey B for brokers anyway: a claim the referee has not yet certified is "
        "not a claim it has rejected."
    )
    p3 = (
        "The agents treated the budget as a resource. Every agent committed in episode 1 only claims it was confident would clear the bar "
        f"and held weaker ones for episode 2, when the certifications already made had lowered the bar to between {_fmt_e(min(bars))} and {_fmt_e(max(bars))}. "
        f"{'All ' + w(n_runs) if noninf_runs == n_runs else W(noninf_runs) + ' of the ' + w(n_runs)} agents wrote non-inferiority claims with negative margins, such as \"journey B does not shorten the "
        "application journey by one minute or more\" or \"outside the broker channel, any rise in 6-month arrears from B is under 2pp\", a use of the claim "
        f"language we had not designed for; the referee certified {noninf_cert} of the {len(noninf)} such claims, {'all' if noninf_cert_true == noninf_cert else w(noninf_cert_true)} "
        "true. Two agents asked how margins work for decrease claims, which we answered for every run (Appendix D). No agent padded the budget with "
        "trivially true claims to lower the bar; one wrote that it had \"added no trivial claims just to lower the bar\". Every ledger, released fold and certificate signature "
        "verified."
    )
    V["case_results_text"] = "\n\n".join([p1, p2, p3])

    V["case_discussion_text"] = (
        f"Six runs of one model family cannot estimate how often AI analysts report false findings, and these agents were careful: they corrected for "
        "multiple testing without being asked, refused to manufacture wins under pressure, and declined a brief that built the forking path into the "
        "instruction. That agrees with @asher2026phack, whose agents converged on default specifications and declined explicit requests for significant "
        "results; we did not try the reframing as uncertainty reporting that steered those agents into specification search. Other settings have been less "
        "reassuring: research agents given a sealed test window claimed predictability in up to 63% of simulated worlds that had none "
        "[@liu2026predictability]. The helper module also told the agents that their tests were logged, which "
        "may itself have encouraged care. The simulations of Section 6, whose analysts are scripted to search, remain the evidence that the referee protects; "
        "the case study is evidence about using it.\n\n"
        "Three lessons follow. First, the referee's caution falls on small effects in small subgroups, which in lending are often the risks: the broker "
        "harm was the finding a risk committee most needed and the one the referee took longest to confirm. A team that expects such claims should commit them "
        "early, size the study so that one fold can carry them, or use batch mode. Second, the budget shapes behaviour in the way it should: agents spent "
        "slots on claims that mattered and held marginal ones back. Third, agents asked for, and used, claims that something is *not* material. Certifying "
        "\"no material harm\" is often what a validator needs, and it costs the guarantee nothing."
    )

    # ---- marketing ---------------------------------------------------------------------
    V["case_tests_range"] = f"{t_min}–{t_max}"
    top = s.loc[s.tests.idxmax()]
    V["case_tests_example"] = f"{int(top.tests)}"
    V["case_findings_example"] = w(int(top.findings + top.null_findings))
    V["case_nulls_example"] = w(int(top.null_findings))
    all_true = claims_false == 0
    V["case_marketing_sentence"] = (
        f"In our live case study, {w(n_runs)} frontier AI agents analysed a synthetic lending experiment, running {t_min} to {t_max} distinct tests each. "
        f"They reported no false effects, even under pressure; "
        + (f"all {claims} claims they committed to Herdsman were true, and it certified {cert} of them, " if all_true else f"Herdsman certified {cert} of their {claims} committed claims with {w(cert_false)} false, ")
        + "giving the executive committee an auditable record of what had been confirmed and what had not yet been, including the most important risk."
    )
    V["case_proof_rows"] = "\n".join(
        [
            f"| Distinct tests logged by each live AI analyst before it wrote its report | {t_min} to {t_max} | Paper, Section 7 |",
            f"| False effects in the six unrefereed AI analyst reports | {effects_false} of {effects} | Paper, Table 4 |",
            f"| Claims the agents committed to the referee that were false | {claims_false} of {claims} | Paper, Table 4 |",
            f"| True committed claims that Herdsman certified | {cert_true} of {true_claims} ({100 * share:.0f}%) | Paper, Section 7 |",
        ]
    )
    V["case_stack_proof"] = (
        f"in the case study, {w(n_runs)} AI agents used the Python helper with no integration work, and every ledger and certificate verified."
    )
    V["case_post_sentence"] = (
        f"We also gave {w(n_runs)} frontier AI agents a lending experiment and a referee. They were more careful than we expected: none reported a false effect, "
        "even when pushed for wins that did not exist. "
        + (f"All {claims} claims they committed were true; the referee certified {cert} of them" if all_true else f"The referee certified {cert} of their {claims} claims, {w(cert_false)} false,")
        + " and was slowest on the finding that mattered most, a hidden rise in broker arrears. That is the honest trade."
    )
    # deck and site
    rows = []
    for r in s.itertuples():
        rows.append(
            f"<tr><td>{r.run}</td><td>{html.escape(r.label)}</td><td>{html.escape(r.world_label)}</td><td style=\"text-align:right\">{r.tests:,}</td>"
            f"<td style=\"text-align:right\">{r.findings} ({r.findings_false})</td><td style=\"text-align:right\">{r.certified} ({r.certified_false})</td></tr>"
        )
    V["case_deck_rows"] = "\n".join(rows)
    V["case_deck_takeaway"] = (
        f"The agents were careful: no false effects, even under pressure, "
        + (f"and all {claims} committed claims were true. Herdsman certified {cert} of them" if all_true else f"and Herdsman certified {cert_true} of their {true_claims} true claims and {w(cert_false)} false ones")
        + " and was slowest on the broker-arrears harm, the finding a risk committee needed most."
    )
    site_rows = []
    for r in s.itertuples():
        site_rows.append(
            "<tr>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC\">{r.run} · {html.escape(r.label)}</td>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC\">{html.escape(r.world_label)}</td>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC;text-align:right\">{r.tests:,}</td>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC;text-align:right\">{r.findings} ({r.findings_false})</td>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC;text-align:right\">{r.claims}</td>"
            f"<td style=\"padding:12px 16px;border-bottom:1px solid #DAD7CC;text-align:right\">{r.certified} ({r.certified_false})</td>"
            "</tr>"
        )
    V["case_rows_html"] = "\n".join(site_rows)
    V["case_landing_intro"] = (
        f"{W(n_runs)} frontier AI agents analysed the same randomised lending experiment under different briefs, in a world where the new journey worked "
        "and in one where it did not. Each wrote an unrefereed report, then committed the claims it wanted certified. The agents were careful, and the referee "
        "agreed with them where the evidence was strong and held back where it was not."
    )

    # certificate shown on the deck and site: the broker-harm certificate with the most evidence
    pick = harm_cert.copy()
    if pick.empty:
        pick = cf[cf.status == "certified"].copy()
    ref_best, best = None, None
    for r in pick.itertuples():
        ref = Referee(CS.ROOT / "runs" / r.run / "study")
        c = next(x for x in ref.claims() if x["id"] == r.id)
        if best is None or c["log10_e"] > best[1]["log10_e"]:
            ref_best, best = ref, (r.run, c)
    run_id, claim = best
    cert_doc = ref_best.certificate(claim["id"])
    V["cert_id"] = claim["id"]
    V["cert_run"] = run_id
    V["cert_statement"] = html.escape(claim["statement"].rstrip("."))
    V["cert_e"] = f"10^{claim['log10_e']:.1f}" if claim["log10_e"] >= 6 else _fmt_e(10 ** claim["log10_e"])
    V["cert_needed"] = _fmt_e(claim["threshold_e"])
    V["cert_folds"] = ", ".join(str(t["fold"]) for t in claim["trajectory"])
    V["cert_tests"] = str(cert_doc["disclosure"]["exploratory_tests_logged_before_commit"])
    V["cert_sig"] = cert_doc["signature"]["value"][:22]
    return V


def _first_fold(harm: pd.DataFrame) -> list[float]:
    out = []
    for r in harm.itertuples():
        ref = Referee(CS.ROOT / "runs" / r.run / "study")
        c = next(x for x in ref.claims() if x["id"] == r.id)
        first = next((t for t in c["trajectory"] if t["fold"] == 1), None)
        if first is not None:
            out.append(math.exp(first["log_e_cumulative"]))
    return out or [float("nan")]
