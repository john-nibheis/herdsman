"""Packages two bundles.

dist/herdsman-0.1.0-release.zip is the product release: the repository (code, tests, notebooks, paper,
marketing sources and results) plus, for every case-study run, its audit bundle, HTML report, the
agent's deliverables and replies. It is safe to publish with the open-source code.

dist/herdsman-investor-pack.zip holds the investor materials: the business case, investment memorandum,
content pack, financial model (workbook, notebook and code) and the pitch-deck files. These are
financial promotions, so they are kept out of the product release and must be circulated only to
exempt investors once the company's solicitor has approved them.

Excluded from both: caches, keys, sealed vaults, the private generator outputs and the agents' data copies.
Usage: python scripts/package.py
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASE = Path("/home/claude/casestudy")
sys.path.insert(0, str(ROOT / "src"))
from herdsman import Referee  # noqa: E402

EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".ipynb_checkpoints", "dist", ".git", "build", "out"}
EXCLUDE_SUFFIX = {".pyc", ".log"}
INVESTOR_ONLY = {Path("business"), Path("notebooks/04_financial_model.ipynb"), Path("notebooks/make_financial_model.py")}
WORKSPACE_KEEP = {".json", ".md", ".py", ".txt"}
WORKSPACE_KEEP_CSV = {"test_log.csv", "analysis_results.csv", "segment_scan_results.csv", "early_warning_results.csv", "heterogeneity_results.csv", "overall_results.csv"}
INVESTOR_README = """Herdsman Ltd: investor pack

RESTRICTED. These documents are financial promotions. Send them only to investment professionals and to
high-net-worth or sophisticated investors who have signed the investor statement the Financial Promotion
Order requires, and only after the company's solicitor has approved them. Do not publish them with the
open-source code.

out/Herdsman_Investment_Memorandum_DRAFT.docx   investment memorandum (draft for solicitor review)
out/Herdsman_Investor_Content_Pack.docx         pitches, templates, FAQ, checklists (items labelled by audience)
out/Herdsman_Investor_Business_Case.docx        business case
out/Herdsman_financial_model.xlsx               model inputs and outputs
out/investor_deck/project/                      pitch-deck files (the deck itself is a Slides artifact)
notebooks/04_financial_model.ipynb              executed financial-model notebook
business/*.py, *_template.md, *_src.html        the code and templates that regenerate every figure
"""


def is_investor_only(rel: Path) -> bool:
    return any(rel == p or p in rel.parents for p in INVESTOR_ONLY)


def repo_files():
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if path.is_dir() or any(part in EXCLUDE_DIRS or part.endswith(".egg-info") for part in rel.parts):
            continue
        if path.suffix in EXCLUDE_SUFFIX or is_investor_only(rel):
            continue
        yield path, Path("herdsman") / rel


def release(dist: Path) -> Path:
    out = dist / "herdsman-0.1.0-release.zip"
    bundles = dist / "audit_bundles"
    bundles.mkdir(exist_ok=True)
    n = 0
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for src, arc in repo_files():
            zf.write(src, arc)
            n += 1
        for out_file in ("Herdsman_GTM_playbook.docx", "playbook.md"):
            p = ROOT / "marketing" / "out" / out_file
            if p.exists():
                zf.write(p, Path("herdsman/marketing/out") / out_file)
        for run_dir in sorted((CASE / "runs").glob("*")):
            run = run_dir.name
            base = Path("casestudy") / run
            ref = Referee(run_dir / "study")
            bundle = ref.audit_bundle(bundles / f"{run}_audit.zip")
            zf.write(bundle, base / f"{run}_audit.zip")
            for name in ("meta.json", "report.html", "close1.json", "phase3_message.txt"):
                if (run_dir / name).exists():
                    zf.write(run_dir / name, base / name)
            ws = run_dir / "workspace"
            for p in sorted(ws.rglob("*")):
                rel = p.relative_to(ws)
                if p.is_dir() or "data" in rel.parts or "__pycache__" in rel.parts:
                    continue
                if p.suffix in WORKSPACE_KEEP or p.name in WORKSPACE_KEEP_CSV:
                    zf.write(p, base / "workspace" / rel)
            reply = CASE / "replies" / f"{run}.md"
            if reply.exists():
                zf.write(reply, base / "agent_replies.md")
        zf.write(ROOT / "experiments" / "casestudy_messages.md", Path("casestudy") / "messages_sent.md")
        for name in ("market.md", "literature.md", "verification.md"):
            src = Path("/home/claude/research") / name
            if src.exists():
                zf.write(src, Path("research") / name)
    print(f"written {out} ({out.stat().st_size / 1e6:.1f} MB, {n} repository files)")
    return out


def investor_pack(dist: Path) -> Path:
    out = dist / "herdsman-investor-pack.zip"
    biz = ROOT / "business"
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("README.txt", INVESTOR_README)
        for name in ("Herdsman_Investment_Memorandum_DRAFT.docx", "Herdsman_Investor_Content_Pack.docx", "Herdsman_Investor_Business_Case.docx", "Herdsman_financial_model.xlsx"):
            p = biz / "out" / name
            if p.exists():
                zf.write(p, Path("out") / name)
        for p in sorted((biz / "out" / "investor_deck").rglob("*")):
            if p.is_file():
                zf.write(p, Path("out") / p.relative_to(biz / "out"))
        for p in sorted(biz.glob("*")):
            if p.is_file() and p.suffix in {".py", ".md", ".html"}:
                zf.write(p, Path("business") / p.name)
        for name in ("04_financial_model.ipynb", "make_financial_model.py"):
            zf.write(ROOT / "notebooks" / name, Path("notebooks") / name)
    print(f"written {out} ({out.stat().st_size / 1e6:.1f} MB)")
    return out


def main() -> None:
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    release(dist)
    investor_pack(dist)


if __name__ == "__main__":
    main()
