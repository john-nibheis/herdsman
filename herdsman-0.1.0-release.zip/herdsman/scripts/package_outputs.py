"""Collects the latest Herdsman outputs into one zip with an index and a SHA-256 manifest.

Usage: python scripts/package_outputs.py   (writes dist/Herdsman_outputs_<date>.zip)
"""
from __future__ import annotations

import hashlib
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASE = Path("/home/claude/casestudy")
RESEARCH = Path("/home/claude/research")
STAMP = date.today().isoformat()
TOP = f"Herdsman_outputs_{STAMP}"

FILES: list[tuple[Path, str]] = [
    (ROOT / "paper" / "paper.pdf", "1_research/Refereeing_the_Robot_Analyst.pdf"),
    (ROOT / "paper" / "paper.docx", "1_research/Refereeing_the_Robot_Analyst.docx"),
    *[(RESEARCH / n, f"1_research/research_notes/{n}") for n in ("market.md", "literature.md", "verification.md")],
    (ROOT / "results" / "casestudy_console.html", "2_case_study/Northfell_case_study_console.html"),
    *[(CASE / "runs" / r / "report.html", f"2_case_study/run_reports/{r}_report.html") for r in ("N1", "P1", "S1", "N2", "P2", "H1")],
    *[(ROOT / "dist" / "audit_bundles" / f"{r}_audit.zip", f"2_case_study/audit_bundles/{r}_audit.zip") for r in ("N1", "P1", "S1", "N2", "P2", "H1")],
    *[(ROOT / "notebooks" / n, f"3_notebooks/{n}") for n in ("01_case_study_northfell.ipynb", "02_experiments.ipynb", "03_quickstart.ipynb")],
    (ROOT / "dist" / "herdsman-0.1.0-release.zip", "4_product/herdsman-0.1.0-release.zip"),
    (ROOT / "marketing" / "out" / "Herdsman_GTM_playbook.docx", "5_marketing/Herdsman_GTM_playbook.docx"),
    (ROOT / "business" / "out" / "Herdsman_explained.docx", "5_marketing/Herdsman_explained.docx"),
    (ROOT / "business" / "out" / "Herdsman_Investment_Memorandum_DRAFT.docx", "6_investor_restricted/Herdsman_Investment_Memorandum_DRAFT.docx"),
    (ROOT / "business" / "out" / "Herdsman_Investor_Content_Pack.docx", "6_investor_restricted/Herdsman_Investor_Content_Pack.docx"),
    (ROOT / "business" / "out" / "Herdsman_Investor_Business_Case.docx", "6_investor_restricted/Herdsman_Investor_Business_Case.docx"),
    (ROOT / "business" / "out" / "Herdsman_financial_model.xlsx", "6_investor_restricted/Herdsman_financial_model.xlsx"),
    (ROOT / "notebooks" / "04_financial_model.ipynb", "6_investor_restricted/04_financial_model.ipynb"),
]
TREES = [  # artifact source folders: (folder, destination)
    (ROOT / "marketing" / "out" / "deck" / "project", "5_marketing/customer_deck_source"),
    (ROOT / "marketing" / "out" / "site" / "project", "5_marketing/website_source"),
    (ROOT / "business" / "out" / "investor_deck" / "project", "6_investor_restricted/investor_deck_source"),
]

README = f"""Herdsman outputs, latest versions as at {STAMP}

CIRCULATION. Until the launch gates are cleared (employer consent, University of Edinburgh
confirmation, the patent decision, the name and the licence), treat everything here as confidential.
Publishing the paper, the code or the customer materials would end the option of a UK or European
patent. After launch, folders 1 to 5 can become public. Folder 6 holds financial promotions: send
those only to exempt investors, once the company's solicitor has approved them.

1_research            The research paper (PDF and Word) and the sourced research notes behind it.
2_case_study          The Northfell case study: interactive console, the six runs' HTML reports and
                      their audit bundles, which a validator can verify without keys or data.
3_notebooks           Executed notebooks: case study, experiments and quickstart.
4_product             The code release: package, tests, notebooks, paper and marketing sources.
                      It deliberately excludes the investor materials.
5_marketing           Go-to-market playbook (internal), "Herdsman explained" (one-, three-, five- and
                      ten-minute scripts, for anyone once launched), and the source files of the
                      customer deck and the website. The decks and the website are live artifacts;
                      these folders hold their source files.
6_investor_restricted Draft investment memorandum (for solicitor review), investor content pack,
                      business case, financial model (workbook and executed notebook) and the
                      investor deck's source files.

WHAT PREDATES LATER DECISIONS
- The playbook (7 November) predates the investor-pack review. It still says the paper "proves"
  the guarantee, plans an Apache-2.0-only core, and sets a launch before Christmas. The staged
  launch and the licence split recommended on 8 November supersede it.
- The financial model, business case and memorandum assume the round completes by the end of
  March 2027. The staged launch would move completion to about the third quarter of 2027.
- The memorandum is a draft: valuation, price, company number, registered office, contact
  details and the prescribed financial-promotion statements are placeholders.

MANIFEST.sha256 lists a SHA-256 fingerprint for every file, so any copy can be checked.
"""


def main() -> None:
    entries: list[tuple[Path, str]] = list(FILES)
    for folder, dest in TREES:
        entries += [(p, f"{dest}/{p.relative_to(folder)}") for p in sorted(folder.rglob("*")) if p.is_file()]
    missing = [str(p) for p, _ in entries if not p.exists()]
    if missing:
        raise SystemExit("missing: " + ", ".join(missing))
    out = ROOT / "dist" / f"{TOP}.zip"
    manifest = []
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"{TOP}/README.txt", README)
        for src, arc in entries:
            zf.write(src, f"{TOP}/{arc}")
            manifest.append(f"{hashlib.sha256(src.read_bytes()).hexdigest()}  {arc}")
        zf.writestr(f"{TOP}/MANIFEST.sha256", "\n".join(manifest) + "\n")
    print(f"written {out} ({out.stat().st_size / 1e6:.1f} MB, {len(entries)} files)")


if __name__ == "__main__":
    main()
