"""Herdsman: an independent statistical referee for AI analysts.

Count every test. Seal the confirmation data. Certify only what survives.
"""
from ._version import __version__
from .audit import verify_bundle, write_bundle
from .budget import ELond, GammaPolicy, bh, by, e_bh, lond
from .certificates import Signer, verify_document
from .claims import Claim, ClaimError
from .config import demo_mode
from .evalues import BettingState, FoldEvidence, difference_evidence, e_to_p, level_evidence, logmeanexp, p_to_e
from .families import HeuristicProposer, LLMProposer, default_proposer
from .filters import Filter, FilterError
from .ledger import Ledger
from .referee import Referee, RefereeError
from .schema import Schema
from .vault import Vault

__all__ = [
    "__version__",
    "BettingState",
    "Claim",
    "ClaimError",
    "ELond",
    "Filter",
    "FilterError",
    "FoldEvidence",
    "GammaPolicy",
    "HeuristicProposer",
    "LLMProposer",
    "Ledger",
    "Referee",
    "RefereeError",
    "Schema",
    "Signer",
    "Vault",
    "bh",
    "by",
    "default_proposer",
    "demo_mode",
    "difference_evidence",
    "e_bh",
    "e_to_p",
    "level_evidence",
    "logmeanexp",
    "lond",
    "p_to_e",
    "verify_bundle",
    "verify_document",
    "write_bundle",
]
