"""Canonical JSON, hashing and clocks.

Every record the referee writes is hashed over a canonical serialisation, so the
same content always produces the same hash on any machine.
"""
from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

import numpy as np


def _default(obj: Any) -> Any:
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        value = float(obj)
        if not math.isfinite(value):
            raise ValueError("non-finite number in canonical JSON")
        return value
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serialisable")


def canonical_json(obj: Any) -> str:
    """Serialise ``obj`` deterministically: sorted keys, no whitespace, no NaN."""
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
        default=_default,
    )


def sha256_hex(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def hash_object(obj: Any) -> str:
    return sha256_hex(canonical_json(obj))


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


Clock = Callable[[], str]


class FixedClock:
    """Deterministic clock for reproducible studies: starts at ``start`` and
    advances by ``step_seconds`` on every call."""

    def __init__(self, start: str = "2026-11-07T09:00:00Z", step_seconds: float = 1.0):
        self._t = datetime.fromisoformat(start.replace("Z", "+00:00"))
        self._step = timedelta(seconds=step_seconds)

    def __call__(self) -> str:
        now = self._t
        self._t = self._t + self._step
        return now.isoformat(timespec="microseconds").replace("+00:00", "Z")
