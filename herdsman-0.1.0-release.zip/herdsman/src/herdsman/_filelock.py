"""Cross-platform exclusive file lock (fcntl on POSIX, msvcrt on Windows)."""
from __future__ import annotations

import os
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

if os.name == "nt":  # pragma: no cover - exercised on Windows only
    import msvcrt

    def _acquire(handle) -> None:
        while True:
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                return
            except OSError:
                time.sleep(0.01)

    def _release(handle) -> None:
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)

else:
    import fcntl

    def _acquire(handle) -> None:
        fcntl.flock(handle, fcntl.LOCK_EX)

    def _release(handle) -> None:
        fcntl.flock(handle, fcntl.LOCK_UN)


@contextmanager
def exclusive_lock(path: str | os.PathLike) -> Iterator[None]:
    """Hold an exclusive lock on ``path`` (created if missing) for the duration of the block."""
    with open(Path(path), "a+b") as handle:
        _acquire(handle)
        try:
            yield
        finally:
            _release(handle)
