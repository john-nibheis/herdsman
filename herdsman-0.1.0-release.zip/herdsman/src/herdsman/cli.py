"""Command-line interface: ``herdsman <command> ...``. Every command prints JSON."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from .certificates import verify_document
from .referee import Referee, RefereeError


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def _bounds(items: list[str] | None) -> dict:
    out = {}
    for item in items or []:
        name, lo, hi = item.rsplit(":", 2)
        out[name] = (float(lo), float(hi))
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="herdsman", description="Independent statistical referee for AI analysts.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init", help="create a study from a CSV file")
    p.add_argument("data")
    p.add_argument("--study", required=True)
    p.add_argument("--keys", required=True)
    p.add_argument("--outcome", action="append", required=True)
    p.add_argument("--bounds", action="append", help="column:lower:upper for numeric outcomes")
    p.add_argument("--alpha", type=float, default=0.10)
    p.add_argument("--horizon", type=int, default=50)
    p.add_argument("--gamma", default="uniform", choices=["uniform", "harmonic", "decaying"])
    p.add_argument("--folds", type=int, default=3)
    p.add_argument("--explore-fraction", type=float, default=0.4)
    p.add_argument("--seed", type=int)
    p.add_argument("--time-column")
    p.add_argument("--title", default="")
    p.add_argument("--question", default="")
    p.add_argument("--allow-agent-close", action="store_true")

    for name, help_text in [
        ("brief", "show the study brief"),
        ("budget", "show the error budget"),
        ("claims", "list claims"),
        ("disclosure", "summarise the logged exploratory search"),
        ("verify", "verify ledger, released folds and certificates"),
    ]:
        q = sub.add_parser(name, help=help_text)
        q.add_argument("--study", required=True)

    q = sub.add_parser("explore", help="run and log an exploratory test")
    q.add_argument("--study", required=True)
    q.add_argument("--spec", required=True, help="JSON test specification")
    q.add_argument("--actor", default="analyst")

    q = sub.add_parser("commit", help="commit a claim for certification")
    q.add_argument("--study", required=True)
    q.add_argument("--claim", required=True, help="JSON claim")
    q.add_argument("--actor", default="analyst")

    for name in ("close-episode", "close-study"):
        q = sub.add_parser(name, help="referee only: open the next sealed fold" if name == "close-episode" else "referee only: finish the study")
        q.add_argument("--study", required=True)
        q.add_argument("--keys", required=True)

    q = sub.add_parser("report", help="write the HTML study report")
    q.add_argument("--study", required=True)
    q.add_argument("--out", required=True)

    q = sub.add_parser("bundle", help="write an audit bundle (no keys, no data)")
    q.add_argument("--study", required=True)
    q.add_argument("--out", required=True)

    q = sub.add_parser("verify-bundle", help="verify an audit bundle")
    q.add_argument("bundle")
    q.add_argument("--public-key", help="trusted referee public key (hex)")

    q = sub.add_parser("verify-certificate", help="verify a certificate file")
    q.add_argument("certificate")
    q.add_argument("--public-key", help="trusted referee public key (hex)")

    args = parser.parse_args(argv)
    try:
        if args.command == "init":
            data = pd.read_csv(args.data)
            referee = Referee.create(
                args.study,
                args.keys,
                data,
                outcomes=args.outcome,
                bounds=_bounds(args.bounds),
                alpha=args.alpha,
                horizon=args.horizon,
                gamma=args.gamma,
                exploration_fraction=args.explore_fraction,
                n_folds=args.folds,
                seed=args.seed,
                title=args.title,
                question=args.question,
                time_column=args.time_column,
                allow_agent_close=args.allow_agent_close,
            )
            _print({"study_id": referee.params["study_id"], "study": args.study, "budget": referee.budget()})
        elif args.command == "verify-bundle":
            from .audit import verify_bundle

            result = verify_bundle(args.bundle, args.public_key)
            _print(result)
            return 0 if result["ok"] else 2
        elif args.command == "verify-certificate":
            document = json.loads(Path(args.certificate).read_text(encoding="utf-8"))
            _print(verify_document(document, args.public_key))
        else:
            keys = getattr(args, "keys", None)
            referee = Referee(args.study, keys)
            if args.command == "brief":
                _print(referee.brief())
            elif args.command == "budget":
                _print(referee.budget())
            elif args.command == "claims":
                _print(referee.claims())
            elif args.command == "disclosure":
                _print(referee.disclosure())
            elif args.command == "verify":
                _print(referee.verify())
            elif args.command == "explore":
                _print(referee.explore_test(json.loads(args.spec), actor=args.actor))
            elif args.command == "commit":
                _print(referee.commit_claim(json.loads(args.claim), actor=args.actor))
            elif args.command == "close-episode":
                _print(referee.close_episode())
            elif args.command == "close-study":
                _print(referee.close_study())
            elif args.command == "bundle":
                _print({"written": str(referee.audit_bundle(args.out))})
            elif args.command == "report":
                Path(args.out).write_text(referee.report_html(), encoding="utf-8")
                _print({"written": args.out})
    except (RefereeError, ValueError, KeyError) as exc:
        _print({"error": str(exc)})
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
