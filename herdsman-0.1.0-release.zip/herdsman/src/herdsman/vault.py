"""The vault: an open exploration split plus sealed confirmation folds.

At study creation the rows are shuffled with a seeded generator (or ordered by
time) and split into an exploration set and ``K`` folds. Each fold is serialised,
its SHA-256 hash is published in the manifest as a commitment, and the bytes are
encrypted with a key that only the referee holds. A fold is opened exactly once,
to confirm the claims open at that moment; afterwards it is *spent* and released
into the exploration pool, because nothing that is committed later is ever
evaluated on it.
"""
from __future__ import annotations

import gzip
import io
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from cryptography.fernet import Fernet

from .canonical import canonical_json, sha256_hex


class VaultError(RuntimeError):
    pass


def _frame_to_bytes(frame: pd.DataFrame) -> bytes:
    return frame.to_csv(index=False, lineterminator="\n").encode("utf-8")


def _frame_from_bytes(raw: bytes) -> pd.DataFrame:
    return pd.read_csv(io.BytesIO(raw), keep_default_na=True)


class Vault:
    def __init__(self, root: str | os.PathLike):
        self.root = Path(root)
        manifest = self.root / "manifest.json"
        if not manifest.exists():
            raise VaultError(f"no vault at {self.root}")
        self.manifest = json.loads(manifest.read_text(encoding="utf-8"))

    # ------------------------------------------------------------------ creation
    @classmethod
    def create(
        cls,
        root: str | os.PathLike,
        frame: pd.DataFrame,
        *,
        key: bytes,
        exploration_fraction: float,
        n_folds: int,
        seed: int,
        time_column: str | None = None,
    ) -> "Vault":
        if not 0.0 < exploration_fraction < 1.0:
            raise VaultError("exploration_fraction must lie in (0, 1)")
        if n_folds < 1:
            raise VaultError("at least one sealed fold is needed")
        root = Path(root)
        (root / "released").mkdir(parents=True, exist_ok=True)
        n = len(frame)
        if time_column:
            order = np.argsort(frame[time_column].to_numpy(), kind="stable")
            split = "time"
        else:
            order = np.random.default_rng(seed).permutation(n)
            split = "random"
        shuffled = frame.iloc[order].reset_index(drop=True)
        n_explore = int(round(exploration_fraction * n))
        boundaries = np.linspace(n_explore, n, n_folds + 1).round().astype(int)
        exploration = shuffled.iloc[:n_explore]
        exploration_bytes = _frame_to_bytes(exploration)
        (root / "exploration.csv.gz").write_bytes(gzip.compress(exploration_bytes, mtime=0))
        cipher = Fernet(key)
        folds = []
        for k in range(n_folds):
            part = shuffled.iloc[boundaries[k] : boundaries[k + 1]]
            raw = _frame_to_bytes(part)
            (root / f"fold_{k + 1}.sealed").write_bytes(cipher.encrypt(gzip.compress(raw, mtime=0)))
            folds.append({"fold": k + 1, "rows": int(len(part)), "sha256": sha256_hex(raw)})
        manifest = {
            "split": split,
            "time_column": time_column,
            "rows": int(n),
            "exploration_rows": int(n_explore),
            "exploration_sha256": sha256_hex(exploration_bytes),
            "folds": folds,
            "released": [],
        }
        (root / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return cls(root)

    # ------------------------------------------------------------------ access
    @property
    def n_folds(self) -> int:
        return len(self.manifest["folds"])

    @property
    def released(self) -> list[int]:
        return list(self.manifest.get("released", []))

    def commitments(self) -> dict:
        return {
            "exploration_sha256": self.manifest["exploration_sha256"],
            "folds": [{"fold": f["fold"], "rows": f["rows"], "sha256": f["sha256"]} for f in self.manifest["folds"]],
        }

    def commitment_hash(self) -> str:
        return sha256_hex(canonical_json(self.commitments()))

    def exploration(self) -> pd.DataFrame:
        """Exploration rows plus every released (spent) fold."""
        frames = [_frame_from_bytes(gzip.decompress((self.root / "exploration.csv.gz").read_bytes()))]
        for k in self.released:
            frames.append(_frame_from_bytes(gzip.decompress((self.root / "released" / f"fold_{k}.csv.gz").read_bytes())))
        return pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]

    def unseal(self, k: int, key: bytes) -> pd.DataFrame:
        if not 1 <= k <= self.n_folds:
            raise VaultError(f"fold {k} does not exist")
        raw = gzip.decompress(Fernet(key).decrypt((self.root / f"fold_{k}.sealed").read_bytes()))
        if sha256_hex(raw) != self.manifest["folds"][k - 1]["sha256"]:
            raise VaultError(f"fold {k} does not match its published commitment")
        return _frame_from_bytes(raw)

    def release(self, k: int, key: bytes) -> None:
        """Move a spent fold into the exploration pool."""
        if k in self.released:
            return
        raw = gzip.decompress(Fernet(key).decrypt((self.root / f"fold_{k}.sealed").read_bytes()))
        (self.root / "released" / f"fold_{k}.csv.gz").write_bytes(gzip.compress(raw, mtime=0))
        self.manifest["released"] = sorted(self.released + [k])
        (self.root / "manifest.json").write_text(json.dumps(self.manifest, indent=2), encoding="utf-8")

    def verify_released(self) -> dict:
        """Check that every released fold matches the hash committed at creation."""
        problems = []
        for k in self.released:
            raw = gzip.decompress((self.root / "released" / f"fold_{k}.csv.gz").read_bytes())
            if sha256_hex(raw) != self.manifest["folds"][k - 1]["sha256"]:
                problems.append(k)
        return {"ok": not problems, "mismatched_folds": problems}
