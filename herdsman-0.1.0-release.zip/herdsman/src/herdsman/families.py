"""Hypothesis families: grouping related attempts.

An analyst who tries one idea in fourteen subgroups has asked one question
fourteen ways. Families make that visible. A *proposer* assigns each test or claim
to a family; the referee then does all the accounting deterministically.

The language model is in the loop but not in the guarantee. Family labels are used
for disclosure (how many distinct questions were explored, how many attempts per
question) and, when an analyst commits a family claim, to decide which e-values are
averaged. Any grouping fixed before a sealed fold is opened leaves the referee's
error guarantee intact, so a poor grouping can cost power or clarity but never
validity. In demo mode only the deterministic heuristic is used.
"""
from __future__ import annotations

import json
import os
import re
from typing import Callable, Protocol, Sequence

from .config import demo_mode
from .filters import Filter, FilterError


class FamilyProposer(Protocol):
    name: str

    def propose(self, specs: Sequence[dict]) -> list[str]: ...


def _columns(text: str | None) -> set[str]:
    if text is None:
        return set()
    if text.strip().lower() in {"", "rest", "others", "all others"}:
        return set()
    try:
        return set(Filter(text).columns)
    except FilterError:
        return set()


class HeuristicProposer:
    """Family = same outcome and same grouping variables, whatever the subgroup,
    threshold or direction. Level claims form one family per outcome."""

    name = "heuristic/v1"

    def label(self, spec: dict) -> str:
        outcome = spec.get("outcome", "?")
        if spec.get("reference") is None:
            return f"{outcome} | level"
        columns = sorted(_columns(spec.get("focal")) | _columns(spec.get("reference")))
        return f"{outcome} ~ {' + '.join(columns) if columns else 'groups'}"

    def propose(self, specs: Sequence[dict]) -> list[str]:
        return [self.label(s) for s in specs]


PROMPT = """You are helping an independent statistical referee count how many distinct questions a data analyst has tested.

Group the numbered analyses below into hypothesis families. Two analyses belong to the same family when they test the same substantive question: the same outcome and the same explanatory contrast or driver, even if they differ in subgroup, threshold, covariates, direction or wording. Different outcomes, or different drivers, are different families.

Return only JSON, with no commentary, in this form:
{{"families": [{{"label": "<short label, at most 8 words>", "items": [<item numbers>]}}]}}
Every item number must appear exactly once.

Analyses:
{items}
"""


def _summarise(spec: dict) -> str:
    parts = [f"outcome={spec.get('outcome')}"]
    for key in ("focal", "reference", "population", "direction", "value"):
        if spec.get(key) not in (None, ""):
            parts.append(f"{key}={spec.get(key)}")
    if spec.get("statement"):
        parts.append(f'statement="{spec["statement"]}"')
    return "; ".join(parts)


def _extract_json(text: str) -> str:
    match = re.search(r"\{.*\}", text, flags=re.S)
    if not match:
        raise ValueError("no JSON object in response")
    return match.group(0)


class LLMProposer:
    """Asks a language model to partition analyses into families, then checks the
    answer is a valid partition. Any failure falls back to the heuristic."""

    name = "llm/v1"

    def __init__(self, complete: Callable[[str], str], fallback: FamilyProposer | None = None, batch_size: int = 120):
        self.complete = complete
        self.fallback = fallback or HeuristicProposer()
        self.batch_size = batch_size
        self.failures = 0

    def _propose_batch(self, batch: Sequence[dict]) -> list[str]:
        items = "\n".join(f"{i + 1}. {_summarise(s)}" for i, s in enumerate(batch))
        data = json.loads(_extract_json(self.complete(PROMPT.format(items=items))))
        assignment: dict[int, str] = {}
        for family in data["families"]:
            label = str(family["label"]).strip()[:80] or "unlabelled"
            for item in family["items"]:
                index = int(item) - 1
                if index in assignment or not 0 <= index < len(batch):
                    raise ValueError("not a partition")
                assignment[index] = label
        if len(assignment) != len(batch):
            raise ValueError("partition is incomplete")
        return [assignment[i] for i in range(len(batch))]

    def propose(self, specs: Sequence[dict]) -> list[str]:
        labels: list[str] = []
        for start in range(0, len(specs), self.batch_size):
            batch = list(specs[start : start + self.batch_size])
            try:
                labels.extend(self._propose_batch(batch))
            except Exception:  # noqa: BLE001 - any model failure falls back
                self.failures += 1
                labels.extend(self.fallback.propose(batch))
        return labels


def anthropic_completer(model: str = "claude-sonnet-5-5", api_key: str | None = None, max_tokens: int = 4000):
    """Completion function backed by the Anthropic API (requires ``pip install anthropic``)."""
    import anthropic  # noqa: PLC0415 - optional dependency

    client = anthropic.Anthropic(api_key=api_key)

    def complete(prompt: str) -> str:
        message = client.messages.create(model=model, max_tokens=max_tokens, messages=[{"role": "user", "content": prompt}])
        return "".join(getattr(block, "text", "") for block in message.content)

    return complete


def default_proposer() -> FamilyProposer:
    """Heuristic in demo mode or without an API key; otherwise an LLM proposer."""
    if demo_mode() or not os.environ.get("ANTHROPIC_API_KEY"):
        return HeuristicProposer()
    try:
        return LLMProposer(anthropic_completer())
    except Exception:  # noqa: BLE001
        return HeuristicProposer()
