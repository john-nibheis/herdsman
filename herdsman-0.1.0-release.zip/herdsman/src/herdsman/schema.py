"""Dataset schema: column kinds, outcome bounds and categorical levels.

Bounds matter for validity. The betting e-values Herdsman uses are exact for
outcomes known to lie in ``[lower, upper]``. Bounds are therefore fixed before any
sealed data are touched: either declared by the data owner, or taken from the
exploration split only. Sealed values outside the bounds are clipped, and the
claim's estimand is then the mean of the clipped outcome.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Iterable, Mapping

import numpy as np
import pandas as pd

KINDS = ("binary", "numeric", "categorical")


@dataclass
class ColumnSpec:
    name: str
    kind: str
    lower: float | None = None
    upper: float | None = None
    levels: list | None = None
    description: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Mapping) -> "ColumnSpec":
        return cls(**{k: d.get(k) for k in ("name", "kind", "lower", "upper", "levels", "description") if k in d})


@dataclass
class Schema:
    columns: dict[str, ColumnSpec]
    outcomes: list[str] = field(default_factory=list)

    @classmethod
    def infer(
        cls,
        frame: pd.DataFrame,
        outcomes: Iterable[str],
        bounds: Mapping[str, tuple[float, float]] | None = None,
        descriptions: Mapping[str, str] | None = None,
        max_levels: int = 60,
    ) -> "Schema":
        """Infer a schema from ``frame``, which should be the exploration split."""
        bounds = dict(bounds or {})
        descriptions = dict(descriptions or {})
        columns: dict[str, ColumnSpec] = {}
        for name in frame.columns:
            series = frame[name]
            values = series.dropna()
            description = descriptions.get(name, "")
            if pd.api.types.is_bool_dtype(series) or (
                pd.api.types.is_numeric_dtype(series) and len(values) > 0 and set(np.unique(values)).issubset({0, 1})
            ):
                columns[name] = ColumnSpec(name, "binary", 0.0, 1.0, None, description)
            elif pd.api.types.is_numeric_dtype(series):
                lo, hi = bounds.get(name, (float(values.min()), float(values.max())) if len(values) else (0.0, 1.0))
                columns[name] = ColumnSpec(name, "numeric", float(lo), float(hi), None, description)
            else:
                uniques = sorted(map(str, values.unique()))
                levels = uniques if len(uniques) <= max_levels else None
                columns[name] = ColumnSpec(name, "categorical", None, None, levels, description)
        schema = cls(columns, list(outcomes))
        for outcome in schema.outcomes:
            if outcome not in columns:
                raise ValueError(f"outcome '{outcome}' is not a column")
            if columns[outcome].kind == "categorical":
                raise ValueError(f"outcome '{outcome}' must be binary or numeric")
            if columns[outcome].upper is None or columns[outcome].lower is None:
                raise ValueError(f"outcome '{outcome}' needs bounds")
            if columns[outcome].upper <= columns[outcome].lower:
                raise ValueError(f"outcome '{outcome}' has empty bounds")
        return schema

    def bounds(self, name: str) -> tuple[float, float]:
        spec = self.columns[name]
        if spec.lower is None or spec.upper is None:
            raise ValueError(f"column '{name}' has no bounds")
        return float(spec.lower), float(spec.upper)

    def kind(self, name: str) -> str:
        return self.columns[name].kind

    def to_dict(self) -> dict:
        return {"columns": [c.to_dict() for c in self.columns.values()], "outcomes": list(self.outcomes)}

    @classmethod
    def from_dict(cls, d: Mapping) -> "Schema":
        columns = {c["name"]: ColumnSpec.from_dict(c) for c in d["columns"]}
        return cls(columns, list(d.get("outcomes", [])))

    def describe(self) -> list[dict]:
        rows = []
        for spec in self.columns.values():
            row = {"name": spec.name, "kind": spec.kind}
            if spec.kind != "categorical":
                row["bounds"] = [spec.lower, spec.upper]
            if spec.levels:
                row["levels"] = spec.levels
            if spec.description:
                row["description"] = spec.description
            row["outcome"] = spec.name in self.outcomes
            rows.append(row)
        return rows
