"""Exploratory tests: the quick, conventional statistics an analyst looks at.

These run on the exploration data only, are logged in the ledger, and carry no
guarantee: their p-values are reported exactly as an unrefereed analyst would see
them. Certification happens only on sealed folds.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .claims import Claim


def _phi_sf(z: float) -> float:
    return 0.5 * math.erfc(z / math.sqrt(2.0))


def _stats(y: np.ndarray) -> tuple[int, float, float]:
    y = y[np.isfinite(y)]
    n = int(y.size)
    if n == 0:
        return 0, float("nan"), float("nan")
    return n, float(y.mean()), float(y.var(ddof=1)) if n > 1 else float("nan")


def welch_difference(y_focal: np.ndarray, y_reference: np.ndarray, direction: str = "increase") -> dict:
    nf, mf, vf = _stats(np.asarray(y_focal, float))
    nr, mr, vr = _stats(np.asarray(y_reference, float))
    out = {"n_focal": nf, "n_reference": nr, "mean_focal": mf, "mean_reference": mr, "var_focal": vf, "var_reference": vr}
    if nf < 2 or nr < 2:
        return {**out, "estimate": None, "se": None, "z": None, "p_two_sided": None, "p_one_sided": None}
    estimate = mf - mr
    se = math.sqrt(vf / nf + vr / nr)
    if se == 0.0:
        z = 0.0 if estimate == 0 else math.copysign(float("inf"), estimate)
    else:
        z = estimate / se
    signed = z if direction == "increase" else -z
    return {
        **out,
        "estimate": estimate,
        "se": se,
        "z": z,
        "p_two_sided": min(1.0, 2.0 * _phi_sf(abs(z))),
        "p_one_sided": _phi_sf(signed),
    }


def one_sample(y: np.ndarray, value: float, direction: str = "increase") -> dict:
    n, m, v = _stats(np.asarray(y, float))
    out = {"n_focal": n, "n_reference": 0, "mean_focal": m, "mean_reference": None, "var_focal": v, "var_reference": None}
    if n < 2:
        return {**out, "estimate": None, "se": None, "z": None, "p_two_sided": None, "p_one_sided": None}
    estimate = m - value
    se = math.sqrt(v / n)
    z = (0.0 if estimate == 0 else math.copysign(float("inf"), estimate)) if se == 0 else estimate / se
    signed = z if direction == "increase" else -z
    return {
        **out,
        "estimate": estimate,
        "se": se,
        "z": z,
        "p_two_sided": min(1.0, 2.0 * _phi_sf(abs(z))),
        "p_one_sided": _phi_sf(signed),
    }


def run_test(frame: pd.DataFrame, claim: Claim) -> dict:
    """Conventional large-sample test of a (validated) claim on ``frame``."""
    frame = claim.with_derived(frame)
    focal, reference = claim.groups(frame)
    y = claim.outcome_values(frame)
    if reference is None:
        return one_sample(y[focal], float(claim.value), claim.direction)
    result = welch_difference(y[focal], y[reference], claim.direction)
    if result["estimate"] is not None and claim.margin:
        shifted = result["estimate"] - (claim.margin if claim.direction == "increase" else -claim.margin)
        signed = shifted / result["se"] if result["se"] else 0.0
        result["p_one_sided"] = _phi_sf(signed if claim.direction == "increase" else -signed)
    return result
