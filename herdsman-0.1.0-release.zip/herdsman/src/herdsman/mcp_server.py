"""Model Context Protocol server: lets any MCP-capable agent work through the referee.

Run ``herdsman-mcp --study path/to/study`` (analyst view). Add ``--keys`` and
``--allow-close`` only if the agent itself may close episodes; normally the
referee's operator does that, so the agent never holds the keys to sealed data.

Example client configuration::

    {"mcpServers": {"herdsman": {"command": "herdsman-mcp", "args": ["--study", "/data/studies/q4-pricing"]}}}
"""
from __future__ import annotations

import argparse

import pandas as pd

from .referee import Referee, RefereeError

INSTRUCTIONS = """Herdsman is an independent statistical referee. Use it whenever you analyse this study's data.
1. Call study_brief first. It lists columns, outcomes, the error budget and the claim format.
2. Explore with explore_test and describe_groups. Exploratory results are logged and carry no guarantee.
3. When you believe a finding, call commit_claim with a precise, testable claim. You cannot see the sealed data it will be tested on.
4. Only certified claims may be reported as established findings. Report open or expired claims as unconfirmed.
Commit a family claim (commit_family_claim) when you believe an effect exists in at least one of several subgroups but do not know which; it uses one claim slot."""


def _server_class():
    try:
        from mcp.server.mcpserver import MCPServer  # mcp >= 2

        return MCPServer
    except ImportError:  # pragma: no cover - mcp 1.x
        from mcp.server.fastmcp import FastMCP

        return FastMCP


def build_server(study_dir: str, keys_dir: str | None = None, *, allow_close: bool | None = None, actor: str = "agent"):
    referee = Referee(study_dir, keys_dir)
    if allow_close is None:
        allow_close = bool(referee.params.get("allow_agent_close", False))
    server = _server_class()("herdsman", instructions=INSTRUCTIONS)

    def _call(fn, *args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except RefereeError as exc:
            raise ValueError(str(exc)) from None

    @server.tool()
    def study_brief() -> dict:
        """Columns, outcomes, error budget, claim format and rules for this study."""
        return referee.brief()

    @server.tool()
    def describe_groups(outcome: str, by: str, population: str = "") -> dict:
        """Mean of an outcome by the levels of a categorical column, on the exploration data (logged, not a test)."""
        frame = referee.exploration_data()
        from .claims import Claim

        claim = Claim(outcome=outcome, population=population, value=0.0).validate(referee.schema)
        mask, _ = claim.groups(frame)
        table = frame.loc[mask].groupby(by)[outcome].agg(["count", "mean"]).reset_index()
        referee.ledger.append("describe", actor, {"outcome": outcome, "by": by, "population": claim.population})
        return {"outcome": outcome, "by": by, "population": population, "rows": table.to_dict(orient="records")}

    @server.tool()
    def explore_test(
        outcome: str,
        focal: str = "",
        reference: str | None = None,
        population: str = "",
        direction: str = "increase",
        value: float | None = None,
        margin: float = 0.0,
    ) -> dict:
        """Conventional test on the exploration data (Welch z or one-sample z). Logged; no guarantee."""
        spec = {"outcome": outcome, "focal": focal, "reference": reference, "population": population, "direction": direction, "value": value, "margin": margin}
        return _call(referee.explore_test, spec, actor=actor)

    @server.tool()
    def commit_claim(
        statement: str,
        outcome: str,
        focal: str = "",
        reference: str | None = None,
        population: str = "",
        direction: str = "increase",
        margin: float = 0.0,
        value: float | None = None,
    ) -> dict:
        """Commit a claim for certification on sealed data. The evidence it needs is fixed now."""
        spec = {
            "statement": statement,
            "outcome": outcome,
            "focal": focal,
            "reference": reference,
            "population": population,
            "direction": direction,
            "margin": margin,
            "value": value,
        }
        return _call(referee.commit_claim, spec, actor=actor)

    @server.tool()
    def commit_family_claim(statement: str, members: list[dict]) -> dict:
        """Commit 'at least one of these effects is real' as one claim (uses one slot)."""
        return _call(referee.commit_family, members, statement, actor=actor)

    @server.tool()
    def list_claims(status: str | None = None) -> list[dict]:
        """Claims with their status (open, certified, expired, withdrawn) and evidence so far."""
        return referee.claims(status)

    @server.tool()
    def budget_status() -> dict:
        """Error budget: claims committed, slots left, evidence the next claim will need."""
        return referee.budget()

    @server.tool()
    def get_certificate(claim_id: str) -> dict:
        """Signed certificate for a certified claim."""
        return _call(referee.certificate, claim_id)

    @server.tool()
    def search_disclosure() -> dict:
        """Summary of the exploratory search logged so far."""
        return referee.disclosure()

    if allow_close:

        @server.tool()
        def close_episode() -> dict:
            """Referee action: open the next sealed fold and update open claims."""
            return _call(referee.close_episode, actor="referee")

    return server


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="herdsman-mcp")
    parser.add_argument("--study", required=True)
    parser.add_argument("--keys")
    parser.add_argument("--allow-close", action="store_true")
    parser.add_argument("--actor", default="agent")
    parser.add_argument("--transport", default="stdio", choices=["stdio", "sse", "streamable-http"])
    args = parser.parse_args(argv)
    build_server(args.study, args.keys, allow_close=args.allow_close or None, actor=args.actor).run(args.transport)


if __name__ == "__main__":  # pragma: no cover
    main()
