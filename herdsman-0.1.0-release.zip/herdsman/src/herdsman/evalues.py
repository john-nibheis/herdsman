"""Betting e-values for claims about bounded means.

An e-value ``E`` for a null hypothesis ``H0`` is a non-negative statistic with
``E[E] <= 1`` whenever ``H0`` is true; by Markov's inequality ``P(E >= 1/a) <= a``.

Herdsman constructs e-values by betting (Shafer, 2021; Waudby-Smith and Ramdas,
2024). For a one-sided null ``H0: E[y] <= 0`` on observations bounded below by
``-b``, a gambler starts with wealth one and multiplies it by ``1 + lambda_i * y_i``,
where ``lambda_i`` lies in ``[0, c/b]`` (``c < 1``) and depends only on earlier
observations. Each factor is positive and, under ``H0``, has conditional mean at
most one, so the final wealth is an e-value. The bet follows a Kelly-style plug-in,
``lambda_i = S_{i-1} / (Q_{i-1} + v0)``, clipped to ``[0, c/b]``, where ``S`` and
``Q`` are running sums of ``y`` and ``y**2`` (including earlier folds, which keeps
the bet predictable) and ``v0`` is a prior second moment.

Two-sample claims are reduced to one sample by *blocking*. Within a fold the
smaller group's units are each matched with ``r = floor(n_large / n_small)`` units
of the larger group, giving independent block differences whose expectation is
exactly the difference in group means. The e-value depends on a random order and
pairing, so the referee averages wealth over several seeded orderings; an average
of e-values is an e-value.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import numpy as np

from .config import DEFAULT_MAX_BET, DEFAULT_ORDERINGS

_CHUNK_ELEMENTS = 6_000_000


@dataclass
class BettingState:
    """Running sums carried from earlier folds, so later bets can learn from them."""

    s: float = 0.0
    q: float = 0.0
    n: int = 0

    def to_dict(self) -> dict:
        return {"s": float(self.s), "q": float(self.q), "n": int(self.n)}

    @classmethod
    def from_dict(cls, d: dict | None) -> "BettingState":
        if not d:
            return cls()
        return cls(float(d.get("s", 0.0)), float(d.get("q", 0.0)), int(d.get("n", 0)))


@dataclass
class FoldEvidence:
    """Evidence contributed by one sealed fold to one claim."""

    log_e: float
    n_focal: int
    n_reference: int
    n_obs: int
    estimate: float | None
    state: BettingState

    @property
    def e(self) -> float:
        return math.exp(min(self.log_e, 700.0))

    def to_dict(self) -> dict:
        return {
            "log_e": float(self.log_e),
            "n_focal": int(self.n_focal),
            "n_reference": int(self.n_reference),
            "n_obs": int(self.n_obs),
            "estimate": None if self.estimate is None else float(self.estimate),
        }


def logmeanexp(values: Sequence[float] | np.ndarray, weights: Sequence[float] | None = None) -> float:
    a = np.asarray(values, dtype=float)
    if a.size == 0:
        return 0.0
    w = np.full(a.size, 1.0 / a.size) if weights is None else np.asarray(weights, dtype=float) / np.sum(weights)
    top = float(np.max(a))
    return top + float(np.log(np.sum(w * np.exp(a - top))))


def _clean(values, lower: float, upper: float) -> np.ndarray:
    x = np.asarray(values, dtype=float).ravel()
    x = x[np.isfinite(x)]
    return np.clip(x, lower, upper)


def _rng(seed) -> np.random.Generator:
    if isinstance(seed, np.random.Generator):
        return seed
    return np.random.default_rng(seed)


def _orderings(rng: np.random.Generator, count: int, n: int) -> np.ndarray:
    return rng.random((count, n)).argsort(axis=1, kind="stable")


def _log_wealth(y: np.ndarray, lam_max: float, v0: float, state: BettingState):
    """Log wealth of the plug-in betting strategy for each row of ``y``."""
    cs = np.cumsum(y, axis=1)
    cq = np.cumsum(y * y, axis=1)
    s_prev = np.empty_like(cs)
    q_prev = np.empty_like(cq)
    s_prev[:, 0] = 0.0
    q_prev[:, 0] = 0.0
    s_prev[:, 1:] = cs[:, :-1]
    q_prev[:, 1:] = cq[:, :-1]
    s_prev += state.s
    q_prev += state.q
    lam = s_prev / (q_prev + v0)
    np.clip(lam, 0.0, lam_max, out=lam)
    log_w = np.log1p(lam * y).sum(axis=1)
    return log_w, cs[:, -1], cq[:, -1]


def difference_evidence(
    y_focal,
    y_reference,
    *,
    lower: float,
    upper: float,
    direction: str = "increase",
    margin: float = 0.0,
    seed=None,
    n_orderings: int = DEFAULT_ORDERINGS,
    max_bet: float = DEFAULT_MAX_BET,
    state: BettingState | None = None,
) -> FoldEvidence:
    """E-value for ``H0: mean(focal) - mean(reference) <= margin`` (``direction='increase'``)
    or ``H0: mean(reference) - mean(focal) <= margin`` (``direction='decrease'``).

    Observations must be independent draws within each group; values are clipped
    to ``[lower, upper]``.
    """
    if not 0.0 < max_bet < 1.0:
        raise ValueError("max_bet must lie in (0, 1)")
    state = state or BettingState()
    yf = _clean(y_focal, lower, upper)
    yr = _clean(y_reference, lower, upper)
    nf, nr = yf.size, yr.size
    estimate = float(yf.mean() - yr.mean()) if nf and nr else None
    span = float(upper - lower)
    if nf == 0 or nr == 0 or span <= 0.0:
        return FoldEvidence(0.0, nf, nr, 0, estimate, state)
    if not -span < margin < span:
        raise ValueError("margin must lie strictly between -(upper-lower) and (upper-lower)")
    sign = 1.0 if direction == "increase" else -1.0
    small_is_focal = nf <= nr
    m = min(nf, nr)
    r = max(nf, nr) // m
    lam_max = max_bet / (span + margin)
    v0 = 0.25 * span * span
    rng = _rng(seed)
    chunk = max(1, min(n_orderings, _CHUNK_ELEMENTS // max(nf + nr, 1)))
    log_ws, s_tot, q_tot = [], [], []
    done = 0
    while done < n_orderings:
        b = min(chunk, n_orderings - done)
        focal = yf[_orderings(rng, b, nf)]
        reference = yr[_orderings(rng, b, nr)]
        if small_is_focal:
            d = focal[:, :m] - reference[:, : m * r].reshape(b, m, r).mean(axis=2)
        else:
            d = focal[:, : m * r].reshape(b, m, r).mean(axis=2) - reference[:, :m]
        y = sign * d - margin
        lw, s, q = _log_wealth(y, lam_max, v0, state)
        log_ws.append(lw)
        s_tot.append(s)
        q_tot.append(q)
        done += b
    log_w = np.concatenate(log_ws)
    new_state = BettingState(
        state.s + float(np.mean(np.concatenate(s_tot))),
        state.q + float(np.mean(np.concatenate(q_tot))),
        state.n + m,
    )
    return FoldEvidence(logmeanexp(log_w), nf, nr, m, estimate, new_state)


def level_evidence(
    y,
    *,
    lower: float,
    upper: float,
    value: float,
    direction: str = "increase",
    seed=None,
    n_orderings: int = DEFAULT_ORDERINGS,
    max_bet: float = DEFAULT_MAX_BET,
    state: BettingState | None = None,
) -> FoldEvidence:
    """E-value for ``H0: mean <= value`` (``direction='increase'``) or
    ``H0: mean >= value`` (``direction='decrease'``)."""
    if not 0.0 < max_bet < 1.0:
        raise ValueError("max_bet must lie in (0, 1)")
    state = state or BettingState()
    x = _clean(y, lower, upper)
    n = x.size
    estimate = float(x.mean() - value) if n else None
    span = float(upper - lower)
    if n == 0 or span <= 0.0:
        return FoldEvidence(0.0, n, 0, 0, estimate, state)
    if direction == "increase":
        centred = x - value
        bound = value - lower
    else:
        centred = value - x
        bound = upper - value
    lam_max = max_bet / (bound if bound > 0 else span)
    v0 = 0.25 * span * span
    rng = _rng(seed)
    chunk = max(1, min(n_orderings, _CHUNK_ELEMENTS // max(n, 1)))
    log_ws, s_tot, q_tot = [], [], []
    done = 0
    while done < n_orderings:
        b = min(chunk, n_orderings - done)
        y = centred[_orderings(rng, b, n)]
        lw, s, q = _log_wealth(y, lam_max, v0, state)
        log_ws.append(lw)
        s_tot.append(s)
        q_tot.append(q)
        done += b
    new_state = BettingState(
        state.s + float(np.mean(np.concatenate(s_tot))),
        state.q + float(np.mean(np.concatenate(q_tot))),
        state.n + n,
    )
    return FoldEvidence(logmeanexp(np.concatenate(log_ws)), n, 0, n, estimate, new_state)


def prior_state(
    estimate: float | None,
    var_focal: float | None,
    n_focal: int,
    var_reference: float | None = None,
    n_reference: int = 0,
    *,
    direction: str = "increase",
    margin: float = 0.0,
    value_kind: str = "difference",
    shrink: float = 0.5,
    weight: float = 100.0,
) -> BettingState:
    """Starting state for a claim's bets, built from the exploration data at commit time.

    The exploration estimate, shrunk towards zero to temper the winner's curse, enters
    the plug-in bet as ``weight`` pseudo-observations. Because it is fixed before any
    sealed fold is opened, the e-value stays valid whatever the estimate is; a good
    estimate removes most of the cost of learning the bet size from the sealed data."""
    if estimate is None or var_focal is None or not math.isfinite(estimate) or not math.isfinite(var_focal) or weight <= 0:
        return BettingState()
    sign = 1.0 if direction == "increase" else -1.0
    mu = shrink * (sign * float(estimate) - float(margin))
    if value_kind == "difference":
        if var_reference is None or not math.isfinite(var_reference) or n_focal < 1 or n_reference < 1:
            return BettingState()
        (n_small, v_small), (n_large, v_large) = sorted([(n_focal, var_focal), (n_reference, var_reference)])
        r = max(n_large // max(n_small, 1), 1)
        var_d = v_small + v_large / r
    else:
        var_d = float(var_focal)
    var_d = max(var_d, 1e-6)
    return BettingState(s=weight * mu, q=weight * (var_d + mu * mu), n=0)


def p_to_e(p: float, kappa: float = 0.5) -> float:
    """Vovk-Wang calibrator ``kappa * p**(kappa - 1)``: turns a p-value into an e-value."""
    if not 0.0 < kappa < 1.0:
        raise ValueError("kappa must lie in (0, 1)")
    p = min(max(float(p), 1e-300), 1.0)
    return kappa * p ** (kappa - 1.0)


def e_to_p(e: float) -> float:
    """Markov's inequality: ``min(1, 1/e)`` is a valid p-value."""
    return 1.0 if e <= 1.0 else 1.0 / e
