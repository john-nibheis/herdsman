"""Claims: the statements an analyst asks the referee to certify.

A claim is a one-sided statement about a population mean, precise enough to be
tested by code. Two kinds are supported.

*Difference claims* compare an outcome between a focal group and a reference
group inside a population::

    Claim(outcome="completed", population="channel == 'broker'",
          focal="variant == 'B'", reference="variant == 'A'", direction="increase")

means "among broker applications, the completion rate under journey B exceeds the
rate under journey A". Associations use the same form, for example
``focal="years_trading > 5"``, ``reference="years_trading <= 5"``. Setting
``reference="rest"`` compares the focal group with everyone else in the population.

*Level claims* compare a population mean with a fixed value::

    Claim(outcome="arrears_6m", population="sector == 'hospitality' and funded == 1",
          value=0.05, direction="increase")

The groups are made disjoint by construction (rows matching both the focal and the
reference filter are dropped from both), and rows with a missing outcome are
excluded, so every claim has a well-defined estimand.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Mapping

import numpy as np
import pandas as pd

from .canonical import hash_object
from .filters import Filter, FilterError
from .schema import Schema

DIRECTIONS = ("increase", "decrease")
_FIELDS = ("outcome", "focal", "reference", "population", "direction", "margin", "value", "statement", "derived")


class ClaimError(ValueError):
    """Raised when a claim is malformed or cannot be tested."""


@dataclass
class Claim:
    outcome: str
    focal: str = ""
    reference: str | None = None
    population: str = ""
    direction: str = "increase"
    margin: float = 0.0
    value: float | None = None
    statement: str = ""
    derived: dict | None = None

    @classmethod
    def from_dict(cls, d: Mapping) -> "Claim":
        unknown = set(d) - set(_FIELDS)
        if unknown:
            raise ClaimError(f"unknown claim field(s): {', '.join(sorted(unknown))}")
        if "outcome" not in d:
            raise ClaimError("a claim needs an 'outcome'")
        kwargs = {k: d[k] for k in _FIELDS if k in d}
        if kwargs.get("margin") is None:
            kwargs["margin"] = 0.0
        return cls(**kwargs)

    @property
    def kind(self) -> str:
        return "level" if self.reference is None else "difference"

    @property
    def complement(self) -> bool:
        return self.reference is not None and self.reference.strip().lower() in {"", "rest", "others", "all others"}

    # ------------------------------------------------------------------ validation
    def derived_names(self) -> list[str]:
        return sorted((self.derived or {}).keys())

    def validate(self, schema: Schema) -> "Claim":
        """Check the claim against ``schema`` and return a normalised copy."""
        if self.outcome not in schema.outcomes:
            raise ClaimError(f"'{self.outcome}' is not a declared outcome; outcomes are {schema.outcomes}")
        if self.direction not in DIRECTIONS:
            raise ClaimError(f"direction must be one of {DIRECTIONS}")
        derived = {}
        for name, spec in (self.derived or {}).items():
            if not isinstance(name, str) or not name.isidentifier():
                raise ClaimError(f"derived column name '{name}' is not a valid identifier")
            if name in schema.columns:
                raise ClaimError(f"derived column '{name}' clashes with an existing column")
            weights = dict((spec or {}).get("weights", {}))
            if not weights:
                raise ClaimError(f"derived column '{name}' needs non-empty 'weights'")
            for column, weight in weights.items():
                if column not in schema.columns or schema.kind(column) == "categorical":
                    raise ClaimError(f"derived column '{name}' uses '{column}', which is not a numeric column")
                float(weight)
            derived[name] = {
                "weights": {k: float(v) for k, v in sorted(weights.items())},
                "intercept": float((spec or {}).get("intercept", 0.0)),
            }
        known = set(schema.columns) | set(derived)
        try:
            population = Filter(self.population, known)
            focal = Filter(self.focal, known)
            reference = None if self.reference is None or self.complement else Filter(self.reference, known)
        except FilterError as exc:
            raise ClaimError(str(exc)) from None
        lower, upper = schema.bounds(self.outcome)
        span = upper - lower
        margin = float(self.margin or 0.0)
        value = None if self.value is None else float(self.value)
        if self.kind == "difference":
            if focal.is_trivial:
                raise ClaimError("a difference claim needs a non-empty 'focal' filter")
            if not abs(margin) < span:
                raise ClaimError(f"margin must lie strictly inside (-{span}, {span})")
            if value is not None:
                raise ClaimError("'value' is only used by level claims")
        else:
            if value is None:
                raise ClaimError("a claim needs either a 'reference' group or a 'value'")
            if not focal.is_trivial:
                raise ClaimError("level claims use 'population' only; leave 'focal' empty")
            if margin:
                raise ClaimError("level claims fold any margin into 'value'")
        return Claim(
            outcome=self.outcome,
            focal=focal.text,
            reference=None if self.reference is None else ("rest" if self.complement else reference.text),
            population=population.text,
            direction=self.direction,
            margin=margin,
            value=value,
            statement=(self.statement or "").strip(),
            derived=derived or None,
        )

    # ------------------------------------------------------------------ identity
    def canonical(self) -> dict:
        """Canonical content of the claim (excludes the free-text statement)."""
        return {
            "outcome": self.outcome,
            "kind": self.kind,
            "population": self.population,
            "focal": self.focal,
            "reference": self.reference,
            "direction": self.direction,
            "margin": float(self.margin or 0.0),
            "value": self.value,
            "derived": self.derived,
        }

    def key(self) -> str:
        return hash_object(self.canonical())[:16]

    def to_dict(self) -> dict:
        d = self.canonical()
        d.pop("kind")
        d["statement"] = self.statement
        return d

    def describe(self) -> str:
        if self.statement:
            return self.statement
        where = f" among [{self.population}]" if self.population else ""
        if self.kind == "level":
            word = "exceeds" if self.direction == "increase" else "is below"
            return f"Mean {self.outcome}{where} {word} {self.value:g}"
        word = "higher" if self.direction == "increase" else "lower"
        ref = "everyone else" if self.complement else f"[{self.reference}]"
        margin = f" by more than {self.margin:g}" if self.margin else ""
        return f"{self.outcome} is {word}{margin} for [{self.focal}] than for {ref}{where}"

    def referenced_columns(self) -> frozenset[str]:
        cols: set[str] = set()
        for text in (self.population, self.focal, self.reference if not self.complement else ""):
            if text:
                cols |= set(Filter(text).columns)
        return frozenset(cols)

    def grouping_columns(self) -> frozenset[str]:
        cols: set[str] = set()
        for text in (self.focal, "" if self.reference is None or self.complement else self.reference):
            if text:
                cols |= set(Filter(text).columns)
        return frozenset(cols)

    # ------------------------------------------------------------------ evaluation
    def with_derived(self, frame: pd.DataFrame) -> pd.DataFrame:
        if not self.derived:
            return frame
        frame = frame.copy()
        for name, spec in self.derived.items():
            score = np.full(len(frame), float(spec.get("intercept", 0.0)))
            for column, weight in spec["weights"].items():
                score = score + float(weight) * pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)
            frame[name] = score
        return frame

    def groups(self, frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray | None]:
        """Return boolean masks ``(focal, reference)``; ``reference`` is None for level claims."""
        frame = self.with_derived(frame)
        observed = frame[self.outcome].notna().to_numpy()
        base = Filter(self.population).mask(frame) & observed
        if self.kind == "level":
            return base, None
        focal = Filter(self.focal).mask(frame)
        if self.complement:
            reference = ~focal
            return base & focal, base & reference
        reference = Filter(self.reference).mask(frame)
        both = focal & reference
        return base & focal & ~both, base & reference & ~both

    def outcome_values(self, frame: pd.DataFrame) -> np.ndarray:
        return pd.to_numeric(frame[self.outcome], errors="coerce").to_numpy(dtype=float)


def claims_from_records(records: Iterable[Mapping]) -> list[Claim]:
    return [Claim.from_dict(r) for r in records]
