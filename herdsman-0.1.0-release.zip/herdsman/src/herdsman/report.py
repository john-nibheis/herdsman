"""Self-contained HTML study report (no external assets)."""
from __future__ import annotations

import html
import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from .referee import Referee

NAVY, TEAL, AMBER, SLATE, PAPER = "#0B2545", "#1F8A8A", "#E09F3E", "#5B6B7F", "#F7F5F0"


def _e(text) -> str:
    return html.escape(str(text), quote=True)


def _fmt_e(log10_e: float) -> str:
    if log10_e >= 4:
        return f"10^{log10_e:.1f}"
    value = 10 ** log10_e
    return f"{value:,.1f}" if value >= 10 else f"{value:.2f}"


def _spark(trajectory: list[dict], threshold: float, n_folds: int) -> str:
    width, height, pad = 150, 44, 5
    points = [(0, 0.0)] + [(s["fold"], s["log_e_cumulative"] / math.log(10)) for s in trajectory]
    top = max([math.log10(threshold), *[p[1] for p in points], 0.5])
    bottom = min([*[p[1] for p in points], -0.5])
    sx = lambda f: pad + (width - 2 * pad) * f / max(n_folds, 1)
    sy = lambda v: height - pad - (height - 2 * pad) * (v - bottom) / (top - bottom)
    path = " ".join(f"{'M' if i == 0 else 'L'}{sx(f):.1f},{sy(v):.1f}" for i, (f, v) in enumerate(points))
    ty = sy(math.log10(threshold))
    return (
        f'<svg viewBox="0 0 {width} {height}" width="{width}" height="{height}" role="img" aria-label="evidence path">'
        f'<line x1="{pad}" x2="{width - pad}" y1="{ty:.1f}" y2="{ty:.1f}" stroke="{AMBER}" stroke-dasharray="3 3"/>'
        f'<line x1="{pad}" x2="{width - pad}" y1="{sy(0):.1f}" y2="{sy(0):.1f}" stroke="var(--rule)"/>'
        f'<path d="{path}" fill="none" stroke="{TEAL}" stroke-width="2"/>'
        f'</svg>'
    )


def build_report(referee: "Referee") -> str:
    params = referee.params
    state = referee.state()
    budget = referee.budget()
    claims = referee.claims()
    verification = referee.verify()
    disclosure = referee.disclosure()
    n_folds = referee.vault.n_folds
    counts = {s: sum(1 for c in claims if c["status"] == s) for s in ("certified", "open", "expired", "withdrawn")}

    def tile(label: str, value: str) -> str:
        return f'<div class="tile"><div class="v">{_e(value)}</div><div class="l">{_e(label)}</div></div>'

    tiles = "".join(
        [
            tile("error budget (alpha)", f"{budget['alpha']:.0%}"),
            tile("claims committed", str(len(claims))),
            tile("certified", str(counts["certified"])),
            tile("still open", str(counts["open"])),
            tile("exploratory tests logged", f"{disclosure['tests']:,}"),
            tile("hypothesis families", str(disclosure["families"])),
        ]
    )
    rows = []
    for c in claims:
        status = c["status"]
        rows.append(
            "<tr>"
            f"<td class='mono'>{_e(c['id'])}</td>"
            f"<td>{_e(c['statement'])}<div class='sub'>{_e(c['family'])}{' · family claim' if c['family_claim'] else ''}</div></td>"
            f"<td class='num'>{c['episode']}</td>"
            f"<td class='num'>{_fmt_e(math.log10(c['threshold_e']))}</td>"
            f"<td class='num'>{_fmt_e(c['log10_e'])}</td>"
            f"<td>{_spark(c['trajectory'], c['threshold_e'], n_folds)}</td>"
            f"<td><span class='pill {status}'>{_e(status)}</span></td>"
            "</tr>"
        )
    fam_rows = "".join(
        f"<tr><td>{_e(r['family'])}</td><td class='num'>{r['tests']}</td><td class='num'>{r['significant_at_alpha']}</td>"
        f"<td class='num'>{r['min_p']:.2g}</td><td class='num'>{r['bonferroni_min_p']:.2g}</td></tr>"
        for r in disclosure["family_table"][:15]
    )
    ratio = disclosure["inflation_ratio"]
    integrity = verification["ledger"]
    return f"""<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Herdsman study report</title>
<style>
:root {{ --ink:{NAVY}; --paper:{PAPER}; --card:#FFFFFF; --rule:#D9D4C7; --muted:{SLATE}; --teal:{TEAL}; --amber:{AMBER}; }}
@media (prefers-color-scheme: dark) {{ :root {{ --ink:#E8EEF5; --paper:#0B1622; --card:#12212F; --rule:#24384B; --muted:#9AAABB; }} }}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--paper); color:var(--ink); font:15px/1.5 Georgia, 'Iowan Old Style', serif; }}
main {{ max-width:1100px; margin:0 auto; padding:32px 16px 64px; }}
header .kicker {{ font:600 12px/1 system-ui, sans-serif; letter-spacing:.14em; text-transform:uppercase; color:var(--teal); }}
h1 {{ font-size:30px; margin:8px 0 4px; }} h2 {{ font-size:20px; margin:36px 0 12px; border-bottom:1px solid var(--rule); padding-bottom:6px; }}
.q {{ color:var(--muted); max-width:70ch; }}
.tiles {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:22px 0; }}
.tile {{ background:var(--card); border:1px solid var(--rule); border-radius:6px; padding:12px 14px; }}
.tile .v {{ font:600 24px/1.1 system-ui, sans-serif; }} .tile .l {{ font:12px/1.3 system-ui, sans-serif; color:var(--muted); margin-top:4px; }}
table {{ width:100%; border-collapse:collapse; background:var(--card); border:1px solid var(--rule); font:13.5px/1.4 system-ui, sans-serif; }}
th, td {{ text-align:left; padding:8px 10px; border-bottom:1px solid var(--rule); vertical-align:middle; }}
th {{ font-weight:600; color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.05em; }}
.num {{ text-align:right; font-variant-numeric:tabular-nums; }} .mono {{ font-family:ui-monospace, Menlo, monospace; }}
.sub {{ color:var(--muted); font-size:12px; margin-top:2px; }}
.pill {{ display:inline-block; padding:2px 8px; border-radius:999px; font-size:12px; font-weight:600; border:1px solid var(--rule); }}
.pill.certified {{ background:var(--teal); color:#fff; border-color:var(--teal); }} .pill.open {{ color:var(--amber); border-color:var(--amber); }}
.pill.expired, .pill.withdrawn {{ color:var(--muted); }}
.scroll {{ overflow-x:auto; }} .note {{ color:var(--muted); font-size:13px; max-width:80ch; }}
dl {{ display:grid; grid-template-columns:max-content 1fr; gap:6px 16px; font:13px/1.4 system-ui, sans-serif; }} dt {{ color:var(--muted); }} dd {{ margin:0; word-break:break-all; }}
</style></head><body><main>
<header><div class="kicker">Herdsman · statistical referee</div><h1>{_e(params['title'] or 'Study report')}</h1>
<p class="q">{_e(params['question'])}</p></header>
<section class="tiles">{tiles}</section>
<h2>Claims</h2>
<p class="note">Each claim must accumulate evidence on sealed folds the analyst has never seen. The amber line is the evidence it needs (1/α<sub>t</sub>, fixed when the claim was committed); the teal line is the evidence it has.</p>
<div class="scroll"><table><thead><tr><th>ID</th><th>Claim</th><th class="num">Episode</th><th class="num">Needed</th><th class="num">Evidence</th><th>Path</th><th>Status</th></tr></thead>
<tbody>{''.join(rows) or '<tr><td colspan="7">No claims yet.</td></tr>'}</tbody></table></div>
<h2>How hard the analyst looked</h2>
<p class="note">{disclosure['tests']:,} exploratory tests in {disclosure['families']} families. {disclosure['significant_at_alpha']} were significant at 5%,
against {disclosure['expected_significant_if_all_null']:.1f} expected if every hypothesis were null{f' (ratio {ratio:.1f})' if ratio else ''}.
{disclosure['bh_survivors']} survive Benjamini–Hochberg at 10% across the logged tests. These figures describe the search; they are not the guarantee.</p>
<div class="scroll"><table><thead><tr><th>Family</th><th class="num">Tests</th><th class="num">p&lt;0.05</th><th class="num">Smallest p</th><th class="num">Smallest p × tests</th></tr></thead><tbody>{fam_rows}</tbody></table></div>
<h2>Integrity</h2>
<dl>
<dt>Ledger</dt><dd>{integrity['records']} records · chain {'intact' if integrity['ok'] else 'BROKEN: ' + _e(integrity['error'])}</dd>
<dt>Ledger head</dt><dd class="mono">{_e(integrity['head'])}</dd>
<dt>Vault commitment</dt><dd class="mono">{_e(params['vault']['commitment_hash'])}</dd>
<dt>Seed commitment</dt><dd class="mono">{_e(params['seed_commitment'])}</dd>
<dt>Referee key</dt><dd class="mono">{_e(params['referee_key_fingerprint'])}</dd>
<dt>Certificates</dt><dd>{sum(1 for c in verification['certificates'] if c['signature_ok'])} of {len(verification['certificates'])} signatures valid</dd>
<dt>Budget</dt><dd>{_e(budget['policy'])}; folds used {budget['folds_used']} of {n_folds}</dd>
</dl>
<p class="note">Guarantee: across every claim committed in this study, the expected proportion of certified claims that are false is at most {budget['alpha']:.0%}, whatever the analyst did beforehand, provided the sealed folds are independent random samples from the study population.</p>
</main></body></html>"""
