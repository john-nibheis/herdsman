"""The referee: the study object that analysts and agents talk to.

Protocol (the "rolling seal")

1. ``Referee.create`` splits the data into an open exploration set and ``K`` sealed
   folds, publishes hash commitments for every fold and for the random seed, and
   generates the referee's signing key.
2. During an *episode* the analyst explores freely (``explore_test`` calls are
   logged) and *commits* claims. Claim ``t`` is given its level ``alpha_t`` by
   e-LOND at the moment of commit; the level never changes afterwards.
3. ``close_episode`` opens the next unopened fold once. Every open claim receives
   that fold's e-value, which multiplies into the claim's running e-process. A
   claim is certified when its running product reaches ``1/alpha_t``. The fold is
   then released into the exploration pool: it is spent, because nothing
   committed later will ever be evaluated on it.
4. ``close_study`` stops new claims, uses any remaining folds for open claims,
   reveals the seed, and signs a final checkpoint.

Guarantee: if the sealed folds are independent random samples from the study
population, the false discovery rate over all certified claims is at most
``alpha``, however the analyst chose, ordered, revised or abandoned its claims.
"""
from __future__ import annotations

import json
import math
import os
import secrets
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Sequence

import numpy as np
import pandas as pd
from cryptography.fernet import Fernet

from ._version import __version__
from .budget import ELond, GammaPolicy, bh, by, e_bh
from .canonical import Clock, hash_object, sha256_hex, utc_now_iso
from .certificates import Signer, verify_document
from .claims import Claim, ClaimError
from .config import (
    DEFAULT_ALPHA,
    DEFAULT_EXPLORATION_FRACTION,
    DEFAULT_FOLDS,
    DEFAULT_HORIZON,
    DEFAULT_MAX_BET,
    DEFAULT_ORDERINGS,
)
from .diagnostics import disclosure
from .evalues import BettingState, FoldEvidence, difference_evidence, level_evidence, logmeanexp, prior_state
from .explore import run_test
from .families import FamilyProposer, HeuristicProposer, default_proposer
from .ledger import Ledger
from .schema import Schema
from ._filelock import exclusive_lock
from .vault import Vault

LN10 = math.log(10.0)


class RefereeError(RuntimeError):
    """Raised when an operation breaks the study's protocol."""


GUARANTEE_TEXT = (
    "Certified by online e-LOND at overall level alpha={alpha}: across every claim committed in this study, "
    "the expected proportion of certified claims that are false is at most alpha, whatever the analyst did "
    "before committing them, provided the sealed folds are independent random samples from the study population. "
    "The certificate speaks to the statistical claim as specified, not to its causal interpretation."
)


class Referee:
    """Handle on a study directory.

    Open without ``keys_dir`` for an *analyst view*: explore, commit and read only.
    Open with ``keys_dir`` for the *referee view*, which can also open sealed folds
    and sign certificates.
    """

    def __init__(
        self,
        study_dir: str | os.PathLike,
        keys_dir: str | os.PathLike | None = None,
        *,
        clock: Clock | None = None,
        proposer: FamilyProposer | None = None,
    ):
        self.dir = Path(study_dir)
        if not (self.dir / "study.json").exists():
            raise RefereeError(f"no study at {self.dir}")
        self.params = json.loads((self.dir / "study.json").read_text(encoding="utf-8"))
        self.schema = Schema.from_dict(self.params["schema"])
        self.clock = clock or utc_now_iso
        self.ledger = Ledger(self.dir / "ledger.jsonl", clock=self.clock)
        self.vault = Vault(self.dir / "vault")
        self.policy = GammaPolicy.from_dict(self.params["budget"]["gamma"])
        self.elond = ELond(float(self.params["budget"]["alpha"]), self.policy)
        self.keys_dir = Path(keys_dir) if keys_dir else None
        self.proposer = proposer or default_proposer()
        self._cache: tuple[tuple, pd.DataFrame] | None = None

    # ================================================================== creation
    @classmethod
    def create(
        cls,
        study_dir: str | os.PathLike,
        keys_dir: str | os.PathLike,
        data: pd.DataFrame,
        *,
        outcomes: Sequence[str],
        bounds: dict | None = None,
        descriptions: dict | None = None,
        alpha: float = DEFAULT_ALPHA,
        horizon: int | None = DEFAULT_HORIZON,
        gamma: str = "uniform",
        exploration_fraction: float = DEFAULT_EXPLORATION_FRACTION,
        n_folds: int = DEFAULT_FOLDS,
        seed: int | None = None,
        n_orderings: int = DEFAULT_ORDERINGS,
        max_bet: float = DEFAULT_MAX_BET,
        prior_weight: float = 100.0,
        prior_shrink: float = 0.5,
        title: str = "",
        question: str = "",
        time_column: str | None = None,
        allow_agent_close: bool = False,
        mode: str = "rolling",
        batch_procedure: str = "by",
        clock: Clock | None = None,
        proposer: FamilyProposer | None = None,
    ) -> "Referee":
        study_dir, keys_dir = Path(study_dir), Path(keys_dir)
        if mode not in ("rolling", "batch"):
            raise RefereeError("mode must be 'rolling' or 'batch'")
        if batch_procedure not in ("by", "bh", "ebh"):
            raise RefereeError("batch_procedure must be 'by', 'bh' or 'ebh'")
        if mode == "batch":
            n_folds = 1
        if (study_dir / "study.json").exists():
            raise RefereeError(f"a study already exists at {study_dir}")
        if keys_dir.resolve() == study_dir.resolve() or study_dir.resolve() in keys_dir.resolve().parents:
            raise RefereeError("keep the keys directory outside the study directory")
        study_dir.mkdir(parents=True, exist_ok=True)
        (study_dir / "certificates").mkdir(exist_ok=True)
        keys_dir.mkdir(parents=True, exist_ok=True)
        clock = clock or utc_now_iso

        seed = int(seed if seed is not None else secrets.randbits(62))
        salt = secrets.token_hex(16)
        vault_key = Fernet.generate_key()
        signer = Signer.generate()
        (keys_dir / "vault.key").write_bytes(vault_key)
        os.chmod(keys_dir / "vault.key", 0o600)
        signer.save(keys_dir / "signing_key.pem")
        (keys_dir / "seed.json").write_text(json.dumps({"seed": seed, "salt": salt}), encoding="utf-8")
        os.chmod(keys_dir / "seed.json", 0o600)

        vault = Vault.create(
            study_dir / "vault",
            data,
            key=vault_key,
            exploration_fraction=exploration_fraction,
            n_folds=n_folds,
            seed=seed,
            time_column=time_column,
        )
        schema = Schema.infer(vault.exploration(), outcomes, bounds=bounds, descriptions=descriptions)
        if gamma == "uniform":
            policy = GammaPolicy.uniform(int(horizon or DEFAULT_HORIZON))
        elif gamma == "harmonic":
            policy = GammaPolicy.harmonic(int(horizon or DEFAULT_HORIZON))
        elif gamma == "decaying":
            policy = GammaPolicy.decaying()
        else:
            raise RefereeError(f"unknown gamma policy '{gamma}'")
        created = clock()
        params = {
            "format": "herdsman-study/v1",
            "software": f"herdsman {__version__}",
            "study_id": sha256_hex(f"{salt}:{created}:{title}")[:12],
            "title": title,
            "question": question,
            "created": created,
            "schema": schema.to_dict(),
            "budget": {"alpha": float(alpha), "gamma": policy.to_dict(), "cap": float(alpha)},
            "evidence": {
                "method": "predictable plug-in betting started from a shrunken exploration estimate; two-sample claims blocked; wealth averaged over seeded orderings",
                "n_orderings": int(n_orderings),
                "max_bet": float(max_bet),
                "prior_weight": float(prior_weight),
                "prior_shrink": float(prior_shrink),
            },
            "vault": {
                "split": vault.manifest["split"],
                "exploration_fraction": float(exploration_fraction),
                "n_folds": int(n_folds),
                "rows": vault.manifest["rows"],
                "exploration_rows": vault.manifest["exploration_rows"],
                "commitments": vault.commitments(),
                "commitment_hash": vault.commitment_hash(),
            },
            "seed_commitment": sha256_hex(f"{salt}:{seed}"),
            "referee_public_key": signer.public_hex,
            "referee_key_fingerprint": signer.fingerprint,
            "allow_agent_close": bool(allow_agent_close),
            "mode": mode,
            "batch_procedure": batch_procedure if mode == "batch" else None,
        }
        (study_dir / "study.json").write_text(json.dumps(params, indent=2), encoding="utf-8")
        referee = cls(study_dir, keys_dir, clock=clock, proposer=proposer)
        referee._save_state(
            {"episode": 1, "folds_used": 0, "n_certified": 0, "explore_tests": 0, "accepting": True, "closed": False, "claims": []}
        )
        referee.ledger.append(
            "study_created",
            "referee",
            {
                "study_id": params["study_id"],
                "params_hash": hash_object(params),
                "vault_commitment": params["vault"]["commitment_hash"],
                "seed_commitment": params["seed_commitment"],
                "referee_key_fingerprint": signer.fingerprint,
            },
        )
        return referee

    # ================================================================== state
    @contextmanager
    def _locked(self) -> Iterator[None]:
        with exclusive_lock(self.dir / "study.lock"):
            yield

    def state(self) -> dict:
        return json.loads((self.dir / "state.json").read_text(encoding="utf-8"))

    def _save_state(self, state: dict) -> None:
        tmp = self.dir / "state.json.tmp"
        tmp.write_text(json.dumps(state, indent=1), encoding="utf-8")
        os.replace(tmp, self.dir / "state.json")

    @property
    def can_open_folds(self) -> bool:
        return self.keys_dir is not None and (self.keys_dir / "vault.key").exists()

    def _require_keys(self) -> None:
        if not self.can_open_folds:
            raise RefereeError("this handle has no referee keys; only the referee can open sealed folds")

    def _seed(self) -> int:
        return int(json.loads((self.keys_dir / "seed.json").read_text(encoding="utf-8"))["seed"])

    # ================================================================== analyst view
    def exploration_data(self) -> pd.DataFrame:
        """Exploration rows plus every spent fold."""
        self.vault = Vault(self.dir / "vault")  # another handle may have released a fold
        version = tuple(self.vault.released)
        if self._cache is None or self._cache[0] != version:
            self._cache = (version, self.vault.exploration())
        return self._cache[1]

    def budget(self) -> dict:
        state = self.state()
        t_next = len(state["claims"]) + 1
        level = self.elond.level(t_next, state["n_certified"]) if state["accepting"] else 0.0
        horizon = self.policy.horizon
        return {
            "alpha": self.elond.alpha,
            "policy": self.policy.describe(),
            "claim_slots": horizon,
            "claims_committed": len(state["claims"]),
            "slots_left": None if horizon is None else max(horizon - len(state["claims"]), 0),
            "certified": state["n_certified"],
            "next_claim_level": level,
            "next_claim_threshold_e": (1.0 / level) if level > 0 else None,
            "episode": state["episode"],
            "folds_used": state["folds_used"],
            "folds_remaining": self.vault.n_folds - state["folds_used"],
            "accepting_claims": state["accepting"] and not state["closed"],
            "mode": self.params.get("mode", "rolling"),
            "batch_procedure": self.params.get("batch_procedure"),
        }

    def brief(self) -> dict:
        p = self.params
        return {
            "study_id": p["study_id"],
            "title": p["title"],
            "question": p["question"],
            "outcomes": self.schema.outcomes,
            "columns": self.schema.describe(),
            "exploration_rows": int(len(self.exploration_data())),
            "budget": self.budget(),
            "claim_format": {
                "difference": {
                    "outcome": "an outcome column",
                    "population": "filter, e.g. \"channel == 'broker' and funded == 1\" (empty = everyone)",
                    "focal": "filter for the focal group, e.g. \"variant == 'B'\"",
                    "reference": "filter for the comparison group, e.g. \"variant == 'A'\", or 'rest'",
                    "direction": "'increase' (focal mean higher) or 'decrease'",
                    "margin": "optional minimum difference, in outcome units",
                    "statement": "plain-English statement of the finding",
                },
                "level": {"outcome": "...", "population": "...", "value": "number", "direction": "'increase' or 'decrease'"},
            },
            "rules": [
                "Explore the exploration data as much as you like; tests run through the referee are logged.",
                "Commit a claim when you want it certified. Its required evidence is fixed at commit.",
                "At the end of the episode the referee opens one sealed fold you have never seen and updates every open claim.",
                "A claim is certified when its accumulated e-value reaches 1/alpha_t. Open claims keep accumulating on later folds.",
                "Spent folds are released to you afterwards; new claims are only ever tested on folds you have not seen.",
            ],
        }

    def explore_test(self, spec: dict, actor: str = "analyst") -> dict:
        """Run and log a conventional test on the exploration data."""
        try:
            claim = Claim.from_dict(spec).validate(self.schema)
        except ClaimError as exc:
            raise RefereeError(f"invalid test specification: {exc}") from None
        result = run_test(self.exploration_data(), claim)
        label = HeuristicProposer().label(claim.to_dict())
        with self._locked():
            state = self.state()
            record = self.ledger.append(
                "explore",
                actor,
                {
                    "spec": claim.to_dict(),
                    "key": claim.key(),
                    "family": label,
                    "result": result,
                    "data_version": len(self.vault.released),
                    "episode": state["episode"],
                },
            )
            state["explore_tests"] = state.get("explore_tests", 0) + 1
            self._save_state(state)
        return {**result, "ledger_seq": record["seq"], "family": label}

    def commit_claim(self, spec: dict, actor: str = "analyst") -> dict:
        """Commit a claim for certification; its level is fixed now."""
        try:
            claim = Claim.from_dict(spec).validate(self.schema)
        except ClaimError as exc:
            raise RefereeError(f"invalid claim: {exc}") from None
        return self._commit([claim], actor, statement=claim.describe(), family_claim=False)

    def commit_family(self, specs: Sequence[dict], statement: str, actor: str = "analyst") -> dict:
        """Commit a *family claim*: "at least one of these effects is real".

        The family occupies one claim slot; its evidence on each fold is the average of
        the members' e-values, which is an e-value for the intersection of their nulls.
        """
        if len(specs) < 2:
            raise RefereeError("a family claim needs at least two members")
        try:
            members = [Claim.from_dict(s).validate(self.schema) for s in specs]
        except ClaimError as exc:
            raise RefereeError(f"invalid family member: {exc}") from None
        return self._commit(members, actor, statement=statement.strip() or "At least one member effect is real", family_claim=True)

    def _commit(self, members: list[Claim], actor: str, *, statement: str, family_claim: bool) -> dict:
        frame = self.exploration_data()
        warnings = []
        priors = []
        for claim in members:
            focal, reference = claim.groups(frame)
            if focal.sum() == 0 or (reference is not None and reference.sum() == 0):
                warnings.append(f"'{claim.describe()}' selects an empty group in the exploration data")
            explored = run_test(frame, claim)
            prior = BettingState()
            if self.params["evidence"].get("prior_weight", 100.0) > 0:
                prior = prior_state(
                    explored.get("estimate"),
                    explored.get("var_focal"),
                    explored.get("n_focal", 0),
                    explored.get("var_reference"),
                    explored.get("n_reference", 0),
                    direction=claim.direction,
                    margin=float(claim.margin or 0.0),
                    value_kind=claim.kind,
                    shrink=float(self.params["evidence"].get("prior_shrink", 0.5)),
                    weight=float(self.params["evidence"].get("prior_weight", 100.0)),
                )
            priors.append({"exploration_estimate": explored.get("estimate"), "exploration_p": explored.get("p_one_sided"), "state": prior.to_dict()})
        key = hash_object(sorted(c.key() for c in members))[:16] if family_claim else members[0].key()
        label = HeuristicProposer().label(members[0].to_dict())
        with self._locked():
            state = self.state()
            if state["closed"] or not state["accepting"]:
                raise RefereeError("the study is no longer accepting claims")
            if state["folds_used"] >= self.vault.n_folds:
                raise RefereeError("every sealed fold has been spent")
            for existing in state["claims"]:
                if existing["key"] == key and existing["status"] in ("open", "certified"):
                    raise RefereeError(f"this claim duplicates {existing['id']}")
            t = len(state["claims"]) + 1
            gamma_t = self.policy.gamma(t)
            alpha_t = self.elond.level(t, state["n_certified"])
            if alpha_t <= 0.0:
                raise RefereeError("no claim slots are left in the error budget")
            claim_id = f"C{t:03d}"
            payload = {
                "claim_id": claim_id,
                "t": t,
                "family_claim": family_claim,
                "members": [c.to_dict() for c in members],
                "statement": statement,
                "key": key,
                "family": label,
                "alpha_t": alpha_t,
                "gamma_t": gamma_t,
                "certified_before": state["n_certified"],
                "threshold_e": 1.0 / alpha_t,
                "episode": state["episode"],
                "priors": priors,
            }
            record = self.ledger.append("commit", actor, payload)
            entry = {
                "id": claim_id,
                "t": t,
                "key": key,
                "family_claim": family_claim,
                "members": [c.to_dict() for c in members],
                "statement": statement,
                "family": label,
                "alpha_t": alpha_t,
                "gamma_t": gamma_t,
                "certified_before": state["n_certified"],
                "episode": state["episode"],
                "actor": actor,
                "committed_seq": record["seq"],
                "committed_hash": record["hash"],
                "committed_at": record["ts"],
                "explore_tests_before": state.get("explore_tests", 0),
                "status": "open",
                "log_e": 0.0,
                "member_states": [p["state"] for p in priors],
                "priors": priors,
                "trajectory": [],
                "certified_fold": None,
                "certificate": None,
            }
            state["claims"].append(entry)
            self._save_state(state)
        return {**self._public(entry), "warnings": warnings}

    def withdraw_claim(self, claim_id: str, actor: str = "analyst") -> dict:
        """Withdraw an open claim. Withdrawing can only reduce certifications, so it is always allowed."""
        with self._locked():
            state = self.state()
            entry = self._entry(state, claim_id)
            if entry["status"] != "open":
                raise RefereeError(f"{claim_id} is {entry['status']}, not open")
            entry["status"] = "withdrawn"
            self.ledger.append("withdrawn", actor, {"claim_id": claim_id})
            self._save_state(state)
        return self._public(entry)

    def claims(self, status: str | None = None) -> list[dict]:
        return [self._public(c) for c in self.state()["claims"] if status is None or c["status"] == status]

    def certificate(self, claim_id: str) -> dict:
        path = self.dir / "certificates" / f"{claim_id}.json"
        if not path.exists():
            raise RefereeError(f"no certificate for {claim_id}")
        return json.loads(path.read_text(encoding="utf-8"))

    @staticmethod
    def _entry(state: dict, claim_id: str) -> dict:
        for entry in state["claims"]:
            if entry["id"] == claim_id:
                return entry
        raise RefereeError(f"no claim {claim_id}")

    @staticmethod
    def _public(entry: dict) -> dict:
        return {
            "id": entry["id"],
            "t": entry["t"],
            "statement": entry["statement"],
            "status": entry["status"],
            "family_claim": entry["family_claim"],
            "members": entry["members"],
            "family": entry["family"],
            "episode": entry["episode"],
            "alpha_t": entry["alpha_t"],
            "threshold_e": 1.0 / entry["alpha_t"],
            "log10_e": entry["log_e"] / LN10,
            "trajectory": entry["trajectory"],
            "certified_fold": entry["certified_fold"],
            "committed_at": entry["committed_at"],
            "actor": entry["actor"],
        }

    # ================================================================== referee view
    def _member_evidence(self, claim: Claim, fold: pd.DataFrame, t: int, k: int, member: int, state: BettingState) -> FoldEvidence:
        frame = claim.with_derived(fold)
        focal, reference = claim.groups(frame)
        y = claim.outcome_values(frame)
        lower, upper = self.schema.bounds(claim.outcome)
        seed = np.random.SeedSequence([self._seed(), t, k, member])
        options = {
            "seed": seed,
            "n_orderings": int(self.params["evidence"]["n_orderings"]),
            "max_bet": float(self.params["evidence"]["max_bet"]),
            "state": state,
        }
        if reference is None:
            return level_evidence(y[focal], lower=lower, upper=upper, value=float(claim.value), direction=claim.direction, **options)
        return difference_evidence(
            y[focal], y[reference], lower=lower, upper=upper, direction=claim.direction, margin=float(claim.margin), **options
        )

    def _member_pvalue(self, claim: Claim, fold: pd.DataFrame) -> float:
        result = run_test(fold, claim)
        p = result.get("p_one_sided")
        return 1.0 if p is None or not math.isfinite(p) else float(p)

    def close_episode(self, actor: str = "referee") -> dict:
        """Open the next sealed fold once, update every open claim, certify, release the fold."""
        self._require_keys()
        with self._locked():
            state = self.state()
            k = state["folds_used"] + 1
            if k > self.vault.n_folds:
                raise RefereeError("every sealed fold has been spent")
            key = (self.keys_dir / "vault.key").read_bytes()
            fold = self.vault.unseal(k, key)
            open_entries = [e for e in state["claims"] if e["status"] == "open"]
            self.ledger.append(
                "fold_opened",
                actor,
                {
                    "fold": k,
                    "rows": int(len(fold)),
                    "sha256": self.vault.manifest["folds"][k - 1]["sha256"],
                    "episode": state["episode"],
                    "open_claims": [e["id"] for e in open_entries],
                },
            )
            newly_certified = []
            batch = self.params.get("mode", "rolling") == "batch"
            batch_rows = []
            for entry in open_entries:
                members = [Claim.from_dict(m) for m in entry["members"]]
                evidences = [
                    self._member_evidence(c, fold, entry["t"], k, i, BettingState.from_dict(entry["member_states"][i]))
                    for i, c in enumerate(members)
                ]
                fold_log_e = logmeanexp([ev.log_e for ev in evidences]) if len(evidences) > 1 else evidences[0].log_e
                entry["member_states"] = [ev.state.to_dict() for ev in evidences]
                entry["log_e"] = float(entry["log_e"] + fold_log_e)
                step = {
                    "fold": k,
                    "log_e_fold": float(fold_log_e),
                    "log_e_cumulative": entry["log_e"],
                    "members": [ev.to_dict() for ev in evidences],
                }
                if batch:
                    p_members = [self._member_pvalue(c, fold) for c in members]
                    step["p_value"] = min(1.0, min(p_members) * len(p_members))  # Bonferroni across family members
                    entry["trajectory"].append(step)
                    batch_rows.append(entry)
                    continue
                log_threshold = -math.log(entry["alpha_t"])
                certified = entry["log_e"] >= log_threshold
                entry["trajectory"].append(step)
                self.ledger.append(
                    "evidence",
                    actor,
                    {"claim_id": entry["id"], **step, "log_threshold": log_threshold, "certified": certified},
                )
                if certified:
                    entry["status"] = "certified"
                    entry["certified_fold"] = k
                    state["n_certified"] += 1
                    newly_certified.append(entry)
            if batch and batch_rows:
                procedure = self.params.get("batch_procedure", "by")
                alpha = self.elond.alpha
                if procedure == "ebh":
                    decisions = e_bh([math.exp(min(e["log_e"], 700.0)) for e in batch_rows], alpha)
                elif procedure == "bh":
                    decisions = bh([e["trajectory"][-1]["p_value"] for e in batch_rows], alpha)
                else:
                    decisions = by([e["trajectory"][-1]["p_value"] for e in batch_rows], alpha)
                for entry, keep in zip(batch_rows, decisions):
                    self.ledger.append(
                        "evidence",
                        actor,
                        {"claim_id": entry["id"], **entry["trajectory"][-1], "procedure": procedure, "batch_size": len(batch_rows), "certified": bool(keep)},
                    )
                    if keep:
                        entry["status"] = "certified"
                        entry["certified_fold"] = k
                        state["n_certified"] += 1
                        newly_certified.append(entry)
            expired = []
            if k == self.vault.n_folds:
                for entry in state["claims"]:
                    if entry["status"] == "open":
                        entry["status"] = "expired"
                        expired.append(entry["id"])
                if expired:
                    self.ledger.append("expired", actor, {"claims": expired, "reason": "no sealed folds remain"})
            self.vault.release(k, key)
            self._cache = None
            self.ledger.append("fold_released", actor, {"fold": k})
            for entry in newly_certified:
                entry["certificate"] = self._issue_certificate(entry, state)
            state["folds_used"] = k
            closed_episode = state["episode"]
            state["episode"] += 1
            if k == self.vault.n_folds:
                state["accepting"] = False
                state["closed"] = True
            self.ledger.append(
                "episode_closed",
                actor,
                {
                    "episode": closed_episode,
                    "fold": k,
                    "certified": [e["id"] for e in newly_certified],
                    "open": [e["id"] for e in state["claims"] if e["status"] == "open"],
                    "expired": expired,
                },
            )
            self._save_state(state)
        return {
            "episode": closed_episode,
            "fold": k,
            "certified": [self._public(e) for e in newly_certified],
            "still_open": [self._public(e) for e in state["claims"] if e["status"] == "open"],
            "expired": expired,
            "folds_remaining": self.vault.n_folds - k,
        }

    def close_study(self, actor: str = "referee") -> dict:
        """Stop accepting claims, use remaining folds for open claims, reveal the seed, sign a checkpoint."""
        self._require_keys()
        with self._locked():
            state = self.state()
            state["accepting"] = False
            self._save_state(state)
            self.ledger.append("claims_closed", actor, {"claims": len(state["claims"])})
        while True:
            state = self.state()
            if state["folds_used"] >= self.vault.n_folds or not any(e["status"] == "open" for e in state["claims"]):
                break
            self.close_episode(actor)
        with self._locked():
            state = self.state()
            expired = [e["id"] for e in state["claims"] if e["status"] == "open"]
            for entry in state["claims"]:
                if entry["status"] == "open":
                    entry["status"] = "expired"
            if expired:
                self.ledger.append("expired", actor, {"claims": expired, "reason": "study closed"})
            secret = json.loads((self.keys_dir / "seed.json").read_text(encoding="utf-8"))
            self.ledger.append("seed_revealed", actor, {"seed": secret["seed"], "salt": secret["salt"]})
            state["closed"] = True
            self._save_state(state)
            checkpoint = self._checkpoint(actor)
        return {
            "certified": [self._public(e) for e in state["claims"] if e["status"] == "certified"],
            "expired": [e["id"] for e in state["claims"] if e["status"] == "expired"],
            "checkpoint": checkpoint,
        }

    def _checkpoint(self, actor: str) -> dict:
        signer = Signer.load(self.keys_dir / "signing_key.pem")
        seq, head = self.ledger.head()
        state = self.state()
        document = signer.sign_document(
            {
                "format": "herdsman-checkpoint/v1",
                "study_id": self.params["study_id"],
                "ledger_records": seq,
                "ledger_head": head,
                "certified": [e["id"] for e in state["claims"] if e["status"] == "certified"],
                "claims": len(state["claims"]),
                "issued_at": self.clock(),
            }
        )
        (self.dir / "checkpoint.json").write_text(json.dumps(document, indent=2), encoding="utf-8")
        self.ledger.append("checkpoint", actor, {"ledger_records": seq, "ledger_head": head, "signature": document["signature"]["value"]})
        return document

    def _guarantee_text(self) -> str:
        if self.params.get("mode", "rolling") == "batch":
            procedure = {"by": "Benjamini-Yekutieli", "bh": "Benjamini-Hochberg", "ebh": "e-BH"}[self.params.get("batch_procedure", "by")]
            dependence = "under arbitrary dependence between claims" if self.params.get("batch_procedure") in ("by", "ebh") else "if the claims' test statistics are positively dependent (PRDS)"
            return (
                f"Certified by {procedure} at false discovery rate {self.elond.alpha} over the batch of claims tested together on the single "
                f"sealed fold, {dependence}, provided the fold is an independent random sample from the study population. "
                + ("P-values are large-sample Welch z-tests. " if self.params.get("batch_procedure") != "ebh" else "")
                + "The certificate speaks to the statistical claim as specified, not to its causal interpretation."
            )
        return GUARANTEE_TEXT.format(alpha=self.elond.alpha)

    def _issue_certificate(self, entry: dict, state: dict) -> str:
        signer = Signer.load(self.keys_dir / "signing_key.pem")
        seq, head = self.ledger.head()
        explores = self.ledger.records("explore")
        before = [r for r in explores if r["seq"] < entry["committed_seq"]]
        same_family = sum(1 for r in before if r["payload"].get("family") == entry["family"])
        document = {
            "format": "herdsman-certificate/v1",
            "study": {
                "study_id": self.params["study_id"],
                "title": self.params["title"],
                "params_hash": hash_object(self.params),
                "alpha": self.elond.alpha,
                "gamma": self.policy.to_dict(),
                "vault_commitment": self.params["vault"]["commitment_hash"],
                "seed_commitment": self.params["seed_commitment"],
            },
            "claim_id": entry["id"],
            "statement": entry["statement"],
            "family_claim": entry["family_claim"],
            "members": entry["members"],
            "claim_key": entry["key"],
            "commit": {
                "t": entry["t"],
                "episode": entry["episode"],
                "actor": entry["actor"],
                "committed_at": entry["committed_at"],
                "ledger_seq": entry["committed_seq"],
                "ledger_hash": entry["committed_hash"],
                "alpha_t": entry["alpha_t"],
                "gamma_t": entry["gamma_t"],
                "certified_before": entry["certified_before"],
                "threshold_e": 1.0 / entry["alpha_t"],
            },
            "evidence": {
                "trajectory": entry["trajectory"],
                "log_e": entry["log_e"],
                "log10_e": entry["log_e"] / LN10,
                "certified_fold": entry["certified_fold"],
            },
            "disclosure": {
                "exploratory_tests_logged_before_commit": len(before),
                "same_family_tests_before_commit": same_family,
                "claims_committed_before": entry["t"] - 1,
                "family": entry["family"],
            },
            "ledger_head_at_issue": {"seq": seq, "hash": head},
            "issued_at": self.clock(),
            "guarantee": self._guarantee_text(),
        }
        signed = signer.sign_document(document)
        path = self.dir / "certificates" / f"{entry['id']}.json"
        path.write_text(json.dumps(signed, indent=2), encoding="utf-8")
        self.ledger.append("certificate_issued", "referee", {"claim_id": entry["id"], "certificate_sha256": hash_object(signed)})
        return path.name

    # ================================================================== audit
    def disclosure(self, proposer: FamilyProposer | None = None) -> dict:
        tests = [r["payload"] for r in self.ledger.records("explore")]
        proposer = proposer or self.proposer
        labels = proposer.propose([t["spec"] for t in tests]) if tests else []
        result = disclosure(tests, labels)
        result["proposer"] = getattr(proposer, "name", type(proposer).__name__)
        return result

    def verify(self) -> dict:
        """Check the ledger chain, the released folds and every certificate."""
        ledger = self.ledger.verify()
        vault = Vault(self.dir / "vault").verify_released()
        by_seq = {r["seq"]: r for r in self.ledger.records()}
        trusted = self.params["referee_public_key"]
        certificates = []
        for path in sorted((self.dir / "certificates").glob("*.json")):
            document = json.loads(path.read_text(encoding="utf-8"))
            signature = verify_document(document, trusted)
            commit = by_seq.get(document["commit"]["ledger_seq"])
            committed = bool(commit and commit["hash"] == document["commit"]["ledger_hash"])
            certificates.append({"file": path.name, "signature_ok": signature["ok"], "commit_in_ledger": committed})
        checkpoint = None
        if (self.dir / "checkpoint.json").exists():
            checkpoint = verify_document(json.loads((self.dir / "checkpoint.json").read_text(encoding="utf-8")), trusted)["ok"]
        ok = ledger["ok"] and vault["ok"] and all(c["signature_ok"] and c["commit_in_ledger"] for c in certificates)
        if checkpoint is not None:
            ok = ok and checkpoint
        return {"ok": ok, "ledger": ledger, "vault": vault, "certificates": certificates, "checkpoint_ok": checkpoint}

    def audit_bundle(self, path: str | os.PathLike) -> Path:
        """Write a zip an auditor can verify: parameters, ledger, checkpoint, certificates, fold hashes."""
        from .audit import write_bundle  # noqa: PLC0415

        return write_bundle(self, path)

    def report_html(self) -> str:
        from .report import build_report  # noqa: PLC0415

        return build_report(self)
