"""Tamper-evident, append-only ledger.

Each record carries the SHA-256 hash of the previous record, so changing, deleting
or reordering any past record breaks every hash after it. The ledger is the
study's source of truth: exploratory tests, commits, fold openings, evidence,
certifications and checkpoints are all recorded here.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from ._filelock import exclusive_lock
from .canonical import Clock, canonical_json, sha256_hex, utc_now_iso

GENESIS = "0" * 64


class LedgerError(RuntimeError):
    pass


class Ledger:
    def __init__(self, path: str | os.PathLike, clock: Clock | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        self._lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self._clock = clock or utc_now_iso
        self._tail: tuple[int, int, str] | None = None  # (file size, seq, hash)

    @contextmanager
    def _locked(self) -> Iterator[None]:
        with exclusive_lock(self._lock_path):
            yield

    def _last(self) -> tuple[int, str]:
        size = self.path.stat().st_size
        if self._tail and self._tail[0] == size:
            return self._tail[1], self._tail[2]
        if size == 0:
            return 0, GENESIS
        with open(self.path, "rb") as handle:
            back = min(size, 65536)
            while True:
                handle.seek(size - back)
                chunk = handle.read(back)
                lines = chunk.rstrip(b"\n").split(b"\n")
                if len(lines) > 1 or back == size:
                    last = json.loads(lines[-1])
                    break
                back = min(size, back * 4)
        self._tail = (size, int(last["seq"]), last["hash"])
        return int(last["seq"]), last["hash"]

    def append(self, kind: str, actor: str, payload: dict) -> dict:
        with self._locked():
            seq, prev = self._last()
            body = {
                "seq": seq + 1,
                "ts": self._clock(),
                "type": kind,
                "actor": actor,
                "payload": payload,
                "prev": prev,
            }
            digest = sha256_hex(canonical_json(body))
            record = {**body, "hash": digest}
            line = canonical_json(record) + "\n"
            with open(self.path, "a", encoding="utf-8", newline="\n") as handle:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())
            self._tail = (self.path.stat().st_size, seq + 1, digest)
            return record

    def records(self, kind: str | None = None) -> list[dict]:
        out = []
        with open(self.path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                if kind is None or record["type"] == kind:
                    out.append(record)
        return out

    def head(self) -> tuple[int, str]:
        return self._last()

    def find(self, seq: int) -> dict | None:
        for record in self.records():
            if record["seq"] == seq:
                return record
        return None

    def verify(self) -> dict:
        """Recompute every hash. Returns ``{'ok', 'records', 'head', 'error'}``."""
        prev = GENESIS
        count = 0
        with open(self.path, "r", encoding="utf-8") as handle:
            for number, line in enumerate(handle, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    return {"ok": False, "records": count, "head": prev, "error": f"line {number} is not valid JSON"}
                claimed = record.pop("hash", None)
                if record.get("prev") != prev:
                    return {"ok": False, "records": count, "head": prev, "error": f"record {record.get('seq')} does not chain to its predecessor"}
                if record.get("seq") != count + 1:
                    return {"ok": False, "records": count, "head": prev, "error": f"record {record.get('seq')} is out of sequence"}
                if sha256_hex(canonical_json(record)) != claimed:
                    return {"ok": False, "records": count, "head": prev, "error": f"record {record.get('seq')} has been altered"}
                prev = claimed
                count += 1
        return {"ok": True, "records": count, "head": prev, "error": None}
