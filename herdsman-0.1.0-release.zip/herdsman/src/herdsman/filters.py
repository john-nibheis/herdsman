"""Safe filter expressions that define populations and comparison groups.

Filters use a small Python-like language, for example::

    device == 'mobile' and years_trading >= 3 and region in ['Scotland', 'Wales']

They are parsed with :mod:`ast` and only a whitelist of node types is accepted, so
a filter can never call a function, read an attribute or execute code. A row
belongs to a filter's subgroup only if every column the filter mentions is
observed for that row; missing values never satisfy a filter.
"""
from __future__ import annotations

import ast
from typing import Iterable

import numpy as np
import pandas as pd

MAX_FILTER_LENGTH = 600
MAX_NODES = 120

_COMPARATORS = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.LtE: "<=",
    ast.Gt: ">",
    ast.GtE: ">=",
    ast.In: "in",
    ast.NotIn: "not in",
}


class FilterError(ValueError):
    """Raised when a filter is malformed, unsafe or refers to unknown columns."""


def _is_constant(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and isinstance(node.value, (str, int, float, bool))


def _is_constant_list(node: ast.AST) -> bool:
    return isinstance(node, (ast.List, ast.Tuple)) and all(_is_constant(e) for e in node.elts)


def _check(node: ast.AST, columns: set[str]) -> None:
    """Recursively reject anything outside the whitelist."""
    if isinstance(node, ast.Expression):
        _check(node.body, columns)
    elif isinstance(node, ast.BoolOp):
        if not isinstance(node.op, (ast.And, ast.Or)):
            raise FilterError("only 'and' / 'or' are allowed")
        for value in node.values:
            _check(value, columns)
    elif isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, ast.Not):
            raise FilterError("only 'not' is allowed as a unary operator")
        _check(node.operand, columns)
    elif isinstance(node, ast.Compare):
        operands = [node.left, *node.comparators]
        for op in node.ops:
            if type(op) not in _COMPARATORS:
                raise FilterError(f"comparison {type(op).__name__} is not allowed")
        for i, op in enumerate(node.ops):
            left, right = operands[i], operands[i + 1]
            if isinstance(op, (ast.In, ast.NotIn)):
                if not isinstance(left, ast.Name) or not _is_constant_list(right):
                    raise FilterError("'in' needs a column on the left and a list of constants on the right")
            else:
                for side in (left, right):
                    if not (isinstance(side, ast.Name) or _is_constant(side)):
                        raise FilterError("comparisons may only involve column names and constants")
                if not (isinstance(left, ast.Name) or isinstance(right, ast.Name)):
                    raise FilterError("a comparison must mention at least one column")
        for operand in operands:
            if isinstance(operand, ast.Name):
                _check(operand, columns)
    elif isinstance(node, ast.Name):
        if columns and node.id not in columns:
            raise FilterError(f"unknown column '{node.id}'")
    elif isinstance(node, ast.Constant):
        if not isinstance(node.value, bool):
            raise FilterError("a bare constant is not a valid filter")
    else:
        raise FilterError(f"'{type(node).__name__}' is not allowed in a filter")


class Filter:
    """A parsed, validated filter expression.

    ``Filter("")`` (or ``"all"``) selects every row.
    """

    def __init__(self, expression: str | None, columns: Iterable[str] | None = None):
        text = (expression or "").strip()
        if text.lower() in {"", "all", "true"}:
            self.text = ""
            self.columns: frozenset[str] = frozenset()
            self._tree: ast.Expression | None = None
            return
        if len(text) > MAX_FILTER_LENGTH:
            raise FilterError(f"filter longer than {MAX_FILTER_LENGTH} characters")
        try:
            tree = ast.parse(text, mode="eval")
        except SyntaxError as exc:
            raise FilterError(f"could not parse filter: {exc.msg}") from None
        if sum(1 for _ in ast.walk(tree)) > MAX_NODES:
            raise FilterError("filter is too complex")
        _check(tree, set(columns) if columns is not None else set())
        self._tree = tree
        self.text = ast.unparse(tree)
        self.columns = frozenset(n.id for n in ast.walk(tree) if isinstance(n, ast.Name))

    def __repr__(self) -> str:
        return f"Filter({self.text!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Filter) and other.text == self.text

    def __hash__(self) -> int:
        return hash(self.text)

    @property
    def is_trivial(self) -> bool:
        return self._tree is None

    def mask(self, frame: pd.DataFrame) -> np.ndarray:
        """Boolean mask of rows satisfying the filter."""
        n = len(frame)
        if self._tree is None:
            return np.ones(n, dtype=bool)
        missing = [c for c in self.columns if c not in frame.columns]
        if missing:
            raise FilterError(f"unknown column(s): {', '.join(sorted(missing))}")
        result = np.asarray(_evaluate(self._tree.body, frame), dtype=bool)
        observed = np.ones(n, dtype=bool)
        for column in self.columns:
            observed &= frame[column].notna().to_numpy()
        return result & observed


def _operand(node: ast.AST, frame: pd.DataFrame):
    if isinstance(node, ast.Name):
        return frame[node.id]
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, (ast.List, ast.Tuple)):
        return [e.value for e in node.elts]
    raise FilterError("unsupported operand")


def _compare(left, op: ast.cmpop, right) -> np.ndarray:
    try:
        if isinstance(op, ast.In):
            out = left.isin(right)
        elif isinstance(op, ast.NotIn):
            out = ~left.isin(right)
        elif isinstance(op, ast.Eq):
            out = left == right
        elif isinstance(op, ast.NotEq):
            out = left != right
        elif isinstance(op, ast.Lt):
            out = left < right
        elif isinstance(op, ast.LtE):
            out = left <= right
        elif isinstance(op, ast.Gt):
            out = left > right
        else:
            out = left >= right
    except TypeError as exc:
        raise FilterError(f"incompatible comparison: {exc}") from None
    if isinstance(out, pd.Series):
        return out.fillna(False).to_numpy(dtype=bool)
    return np.asarray(out, dtype=bool)


def _evaluate(node: ast.AST, frame: pd.DataFrame) -> np.ndarray:
    n = len(frame)
    if isinstance(node, ast.BoolOp):
        parts = [_evaluate(v, frame) for v in node.values]
        reducer = np.logical_and if isinstance(node.op, ast.And) else np.logical_or
        return reducer.reduce(parts)
    if isinstance(node, ast.UnaryOp):
        return ~_evaluate(node.operand, frame)
    if isinstance(node, ast.Compare):
        result = np.ones(n, dtype=bool)
        operands = [node.left, *node.comparators]
        for i, op in enumerate(node.ops):
            left = _operand(operands[i], frame)
            right = _operand(operands[i + 1], frame)
            outcome = _compare(left, op, right)
            if np.ndim(outcome) == 0:
                outcome = np.full(n, bool(outcome))
            result &= outcome
        return result
    if isinstance(node, ast.Constant) and isinstance(node.value, bool):
        return np.full(n, node.value)
    raise FilterError(f"cannot evaluate '{type(node).__name__}'")
