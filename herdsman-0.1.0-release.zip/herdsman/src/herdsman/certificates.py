"""Signing and verifying certificates and ledger checkpoints with Ed25519."""
from __future__ import annotations

import base64
import os
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .canonical import canonical_json, sha256_hex


class Signer:
    def __init__(self, private_key: Ed25519PrivateKey):
        self._key = private_key

    @classmethod
    def generate(cls) -> "Signer":
        return cls(Ed25519PrivateKey.generate())

    @classmethod
    def load(cls, path: str | os.PathLike) -> "Signer":
        key = serialization.load_pem_private_key(Path(path).read_bytes(), password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError("signing key is not Ed25519")
        return cls(key)

    def save(self, path: str | os.PathLike) -> None:
        pem = self._key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
        )
        path = Path(path)
        path.write_bytes(pem)
        os.chmod(path, 0o600)

    @property
    def public_hex(self) -> str:
        raw = self._key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        return raw.hex()

    @property
    def fingerprint(self) -> str:
        return fingerprint(self.public_hex)

    def sign_document(self, document: dict) -> dict:
        body = {k: v for k, v in document.items() if k != "signature"}
        value = self._key.sign(canonical_json(body).encode("utf-8"))
        return {
            **body,
            "signature": {
                "alg": "Ed25519",
                "public_key": self.public_hex,
                "key_fingerprint": self.fingerprint,
                "value": base64.b64encode(value).decode("ascii"),
            },
        }


def fingerprint(public_hex: str) -> str:
    return sha256_hex(bytes.fromhex(public_hex))[:16]


def verify_document(document: dict, trusted_public_hex: str | None = None) -> dict:
    """Verify a signed document. If ``trusted_public_hex`` is given, the document must
    have been signed by that key; otherwise the embedded key is used and reported."""
    signature = document.get("signature") or {}
    public_hex = signature.get("public_key")
    if not public_hex or signature.get("alg") != "Ed25519":
        return {"ok": False, "reason": "missing or unsupported signature"}
    if trusted_public_hex and public_hex != trusted_public_hex:
        return {"ok": False, "reason": "signed by an untrusted key", "key_fingerprint": fingerprint(public_hex)}
    body = {k: v for k, v in document.items() if k != "signature"}
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_hex)).verify(
            base64.b64decode(signature["value"]), canonical_json(body).encode("utf-8")
        )
    except (InvalidSignature, ValueError):
        return {"ok": False, "reason": "signature does not match the document", "key_fingerprint": fingerprint(public_hex)}
    return {"ok": True, "reason": None, "key_fingerprint": fingerprint(public_hex), "trusted": bool(trusted_public_hex)}
