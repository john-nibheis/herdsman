"""Search disclosure: what the exploration ledger says about how hard the analyst looked.

These figures carry no guarantee; certification rests on sealed folds alone. They
exist so a reader can see the size of the search behind a finding, in the spirit
of multiverse and specification-curve reporting.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Sequence

import numpy as np
import pandas as pd

from .budget import bh
from .claims import Claim
from .explore import welch_difference, one_sample


def disclosure(tests: Sequence[dict], labels: Sequence[str], *, alpha: float = 0.05, q: float = 0.10) -> dict:
    """Summarise logged exploratory tests.

    ``tests`` are ledger payloads with ``spec`` and ``result``; ``labels`` assigns each
    test to a hypothesis family.
    """
    pvalues = [t["result"].get("p_two_sided") for t in tests]
    valid = [i for i, p in enumerate(pvalues) if p is not None and not math.isnan(p)]
    n_tests = len(valid)
    significant = sum(1 for i in valid if pvalues[i] < alpha)
    expected = alpha * n_tests
    survivors = bh([pvalues[i] for i in valid], q) if valid else np.zeros(0, bool)
    families: dict[str, list[int]] = defaultdict(list)
    for i in valid:
        families[labels[i]].append(i)
    rows = []
    for label, members in families.items():
        p_min = min(pvalues[i] for i in members)
        best = min(members, key=lambda i: pvalues[i])
        rows.append(
            {
                "family": label,
                "tests": len(members),
                "min_p": p_min,
                "bonferroni_min_p": min(1.0, len(members) * p_min),
                "significant_at_alpha": sum(1 for i in members if pvalues[i] < alpha),
                "best_spec": tests[best]["spec"],
            }
        )
    rows.sort(key=lambda r: r["min_p"])
    return {
        "tests": n_tests,
        "families": len(families),
        "tests_per_family": (n_tests / len(families)) if families else 0.0,
        "significant_at_alpha": significant,
        "expected_significant_if_all_null": expected,
        "inflation_ratio": (significant / expected) if expected else None,
        "bh_survivors": int(np.sum(survivors)),
        "alpha": alpha,
        "q": q,
        "family_table": rows,
    }


def _abs_z(frame: pd.DataFrame, claim: Claim) -> float:
    frame = claim.with_derived(frame)
    focal, reference = claim.groups(frame)
    y = claim.outcome_values(frame)
    result = one_sample(y[focal], float(claim.value)) if reference is None else welch_difference(y[focal], y[reference])
    z = result.get("z")
    return 0.0 if z is None or not math.isfinite(z) else abs(z)


def replay_max_test(
    frame: pd.DataFrame,
    claims: Sequence[Claim],
    outcome_columns: Sequence[str],
    *,
    n_permutations: int = 200,
    seed: int = 0,
) -> dict:
    """Permutation p-value for the largest |z| across a logged family of specifications.

    The outcome columns are permuted jointly, which breaks every association between
    outcomes and the other columns, and every logged specification is re-run on each
    permuted copy. This accounts for the number and correlation of the attempts the
    analyst actually made, but not for the attempts an adaptive analyst *would* have
    made on other data, so it understates the true search cost.
    """
    observed = max((_abs_z(frame, c) for c in claims), default=0.0)
    rng = np.random.default_rng(seed)
    exceed = 0
    outcome_columns = [c for c in outcome_columns if c in frame.columns]
    permuted = frame.copy()
    for _ in range(n_permutations):
        order = rng.permutation(len(frame))
        permuted[outcome_columns] = frame[outcome_columns].to_numpy()[order]
        if max((_abs_z(permuted, c) for c in claims), default=0.0) >= observed:
            exceed += 1
    return {
        "specifications": len(claims),
        "max_abs_z": observed,
        "permutations": n_permutations,
        "p_value": (1 + exceed) / (1 + n_permutations),
    }
