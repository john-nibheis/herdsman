"""Error budgets: online e-LOND levels and batch procedures.

Herdsman controls the false discovery rate across every claim an analyst commits,
in the order they are committed, with e-LOND (Xu and Ramdas, 2024). Claim ``t``
receives the level ``alpha_t = alpha * gamma_t * (D_t + 1)`` at the moment it is
committed, where ``D_t`` is the number of claims already certified and ``gamma`` is a
non-negative sequence summing to at most one. The claim is certified if its
evidence ever reaches ``1 / alpha_t``. Because ``alpha_t`` is fixed at commit and the
``(D_t + 1)`` factor cancels in the proof, the guarantee holds under arbitrary
dependence between claims and arbitrary adaptivity of the analyst.

The ``gamma`` sequence is the budget's shape. ``uniform(N)`` spreads the budget evenly
over a declared horizon of ``N`` claim slots; ``decaying`` is the infinite-horizon
sequence of Javanmard and Montanari (2018), normalised numerically here.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from functools import lru_cache
from typing import Sequence

import numpy as np


def _jm_term(j: int) -> float:
    return math.log(max(j, 2)) / (j * math.exp(math.sqrt(math.log(j)))) if j >= 1 else 0.0


@lru_cache(maxsize=1)
def _jm_normaliser(partial_terms: int = 2_000_000) -> float:
    j = np.arange(1, partial_terms + 1, dtype=float)
    terms = np.log(np.maximum(j, 2.0)) / (j * np.exp(np.sqrt(np.log(j))))
    partial = float(terms.sum())
    a = math.sqrt(math.log(partial_terms))
    tail = 2.0 * math.exp(-a) * (a**3 + 3 * a**2 + 6 * a + 6)  # integral bound on the remaining terms
    return partial + tail


@dataclass(frozen=True)
class GammaPolicy:
    """Shape of the error budget across claim slots."""

    name: str = "uniform"
    horizon: int | None = 50

    @classmethod
    def uniform(cls, horizon: int) -> "GammaPolicy":
        if horizon < 1:
            raise ValueError("horizon must be at least one")
        return cls("uniform", int(horizon))

    @classmethod
    def harmonic(cls, horizon: int) -> "GammaPolicy":
        if horizon < 1:
            raise ValueError("horizon must be at least one")
        return cls("harmonic", int(horizon))

    @classmethod
    def decaying(cls) -> "GammaPolicy":
        return cls("decaying", None)

    def gamma(self, j: int) -> float:
        """Budget share of the ``j``-th claim (1-based)."""
        if j < 1:
            raise ValueError("claim index is 1-based")
        if self.name == "uniform":
            return 1.0 / self.horizon if j <= self.horizon else 0.0
        if self.name == "harmonic":
            if j > self.horizon:
                return 0.0
            h = sum(1.0 / k for k in range(1, self.horizon + 1))
            return (1.0 / j) / h
        if self.name == "decaying":
            return _jm_term(j) / _jm_normaliser()
        raise ValueError(f"unknown gamma policy '{self.name}'")

    def to_dict(self) -> dict:
        return {"name": self.name, "horizon": self.horizon}

    @classmethod
    def from_dict(cls, d: dict) -> "GammaPolicy":
        return cls(d.get("name", "uniform"), d.get("horizon"))

    def describe(self) -> str:
        if self.name == "uniform":
            return f"uniform over {self.horizon} claim slots"
        if self.name == "harmonic":
            return f"front-loaded (harmonic) over {self.horizon} claim slots"
        return "decaying, unbounded number of claims"


@dataclass(frozen=True)
class ELond:
    """Online e-LOND levels. ``cap`` (default ``alpha``) stops a level from rising above it,
    so no claim is ever certified on evidence weaker than ``1/alpha``; capping only
    lowers levels and therefore keeps the guarantee."""

    alpha: float = 0.10
    policy: GammaPolicy = GammaPolicy()
    cap: float | None = None

    def __post_init__(self) -> None:
        if not 0.0 < self.alpha < 1.0:
            raise ValueError("alpha must lie in (0, 1)")

    def level(self, t: int, certified_before: int) -> float:
        raw = self.alpha * self.policy.gamma(t) * (certified_before + 1)
        return min(raw, self.alpha if self.cap is None else self.cap)


# --------------------------------------------------------------------------- batch procedures
def e_bh(evalues: Sequence[float], alpha: float) -> np.ndarray:
    """e-BH (Wang and Ramdas, 2022): FDR control under arbitrary dependence."""
    e = np.asarray(evalues, dtype=float)
    m = e.size
    if m == 0:
        return np.zeros(0, dtype=bool)
    order = np.argsort(-e, kind="stable")
    ranked = e[order]
    k_star = 0
    for k in range(m, 0, -1):
        if ranked[k - 1] >= m / (alpha * k):
            k_star = k
            break
    out = np.zeros(m, dtype=bool)
    out[order[:k_star]] = True
    return out


def bh(pvalues: Sequence[float], q: float) -> np.ndarray:
    """Benjamini-Hochberg step-up."""
    p = np.asarray(pvalues, dtype=float)
    m = p.size
    if m == 0:
        return np.zeros(0, dtype=bool)
    order = np.argsort(p, kind="stable")
    thresholds = q * np.arange(1, m + 1) / m
    passed = np.nonzero(p[order] <= thresholds)[0]
    out = np.zeros(m, dtype=bool)
    if passed.size:
        out[order[: passed[-1] + 1]] = True
    return out


def by(pvalues: Sequence[float], q: float) -> np.ndarray:
    """Benjamini-Yekutieli: BH at ``q / H_m``, valid under arbitrary dependence."""
    m = len(pvalues)
    if m == 0:
        return np.zeros(0, dtype=bool)
    return bh(pvalues, q / sum(1.0 / k for k in range(1, m + 1)))


def bonferroni(pvalues: Sequence[float], alpha: float) -> np.ndarray:
    p = np.asarray(pvalues, dtype=float)
    return p <= alpha / max(p.size, 1)


def lond(pvalues: Sequence[float], alpha: float, policy: GammaPolicy) -> np.ndarray:
    """LOND (Javanmard and Montanari, 2018) on p-values in the order given."""
    out = np.zeros(len(pvalues), dtype=bool)
    certified = 0
    for t, p in enumerate(pvalues, start=1):
        if p <= alpha * policy.gamma(t) * (certified + 1):
            out[t - 1] = True
            certified += 1
    return out
