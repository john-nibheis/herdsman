"""Audit bundles: everything an auditor needs to check a study, and nothing they should not see.

A bundle is a zip file holding the study parameters, the ledger, the signed checkpoint,
every certificate and the vault manifest (fold hashes only). It contains no keys and no
data. ``verify_bundle`` checks the ledger chain, every certificate's signature and its
commit record, the checkpoint signature, and that each certificate refers to these exact
study parameters.
"""
from __future__ import annotations

import io
import json
import tempfile
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from .canonical import hash_object
from .certificates import verify_document
from .ledger import Ledger

if TYPE_CHECKING:  # pragma: no cover
    from .referee import Referee

VERIFY_TEXT = """Herdsman audit bundle

This archive contains the parameters, ledger, signed checkpoint, certificates and vault
manifest of one study. It contains no keys and no data.

To verify:  pip install herdsman && herdsman verify-bundle THIS_FILE.zip
To pin the referee's key, add:  --public-key <hex from a source you trust>
"""


def write_bundle(referee: "Referee", path: str | Path) -> Path:
    path = Path(path)
    base = referee.dir
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(base / "study.json", "study.json")
        zf.write(base / "ledger.jsonl", "ledger.jsonl")
        zf.write(base / "vault" / "manifest.json", "vault_manifest.json")
        if (base / "checkpoint.json").exists():
            zf.write(base / "checkpoint.json", "checkpoint.json")
        for cert in sorted((base / "certificates").glob("*.json")):
            zf.write(cert, f"certificates/{cert.name}")
        zf.writestr("VERIFY.txt", VERIFY_TEXT)
    return path


def verify_bundle(path: str | Path, trusted_public_hex: str | None = None) -> dict:
    with zipfile.ZipFile(path) as zf:
        names = set(zf.namelist())
        params = json.loads(zf.read("study.json"))
        public_hex = trusted_public_hex or params["referee_public_key"]
        with tempfile.TemporaryDirectory() as tmp:
            ledger_path = Path(tmp) / "ledger.jsonl"
            ledger_path.write_bytes(zf.read("ledger.jsonl"))
            ledger = Ledger(ledger_path)
            chain = ledger.verify()
            by_seq = {r["seq"]: r for r in ledger.records()}
        params_hash = hash_object(params)
        created = next((r for r in by_seq.values() if r["type"] == "study_created"), None)
        params_in_ledger = bool(created and created["payload"].get("params_hash") == params_hash)
        certificates = []
        for name in sorted(n for n in names if n.startswith("certificates/") and n.endswith(".json")):
            doc = json.loads(zf.read(name))
            signature = verify_document(doc, public_hex)
            commit = by_seq.get(doc["commit"]["ledger_seq"])
            certificates.append(
                {
                    "file": name,
                    "claim_id": doc.get("claim_id"),
                    "signature_ok": signature["ok"],
                    "commit_in_ledger": bool(commit and commit["hash"] == doc["commit"]["ledger_hash"]),
                    "same_study": doc["study"]["params_hash"] == params_hash,
                }
            )
        checkpoint_ok = None
        if "checkpoint.json" in names:
            checkpoint = json.loads(zf.read("checkpoint.json"))
            checkpoint_ok = verify_document(checkpoint, public_hex)["ok"] and checkpoint["ledger_records"] <= chain["records"]
    ok = chain["ok"] and params_in_ledger and all(c["signature_ok"] and c["commit_in_ledger"] and c["same_study"] for c in certificates)
    if checkpoint_ok is not None:
        ok = ok and checkpoint_ok
    return {
        "ok": ok,
        "study_id": params.get("study_id"),
        "ledger": chain,
        "params_in_ledger": params_in_ledger,
        "certificates": certificates,
        "checkpoint_ok": checkpoint_ok,
        "key_pinned": bool(trusted_public_hex),
    }
