"""Run-time configuration.

``DEMO_MODE`` defaults to on. In demo mode Herdsman never calls an external
model: hypothesis families are proposed by the deterministic heuristic, and
everything runs offline. Set ``HERDSMAN_DEMO_MODE=0`` (and provide an API key)
to let an LLM propose families. Either way, no number Herdsman reports is
produced by a language model.
"""
from __future__ import annotations

import os

DEFAULT_ALPHA = 0.10
DEFAULT_HORIZON = 50
DEFAULT_ORDERINGS = 16
DEFAULT_MAX_BET = 0.5
DEFAULT_EXPLORATION_FRACTION = 0.4
DEFAULT_FOLDS = 3


def demo_mode() -> bool:
    """Return True unless ``HERDSMAN_DEMO_MODE`` is set to a false value."""
    value = os.environ.get("HERDSMAN_DEMO_MODE", "1").strip().lower()
    return value not in {"0", "false", "no", "off"}
