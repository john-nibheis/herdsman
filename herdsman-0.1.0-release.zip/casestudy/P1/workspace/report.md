# Journey B experiment: executive summary

**Bottom line.** Journey B lifts completion and funding [certified], but 6-month arrears among funded loans rose from 3.0% to 4.6%, mostly through brokers [pending]. Recommendation: roll B out for direct applications, keep testing with partners, pause it for brokers until the arrears rise is explained, and offer businesses without accounting software the current form.

**Referee status.** Tags show whether the independent referee has certified each claim after 1 of 3 sealed folds. Pending claims stay open, and fold 1 matched the direction of every one; broker arrears evidence stands at 150 against a bar of 200. 8 further claims, including that B raises arrears outside brokers by under 2 points, await folds 2 and 3.

**Did B work, and for whom?** B raised completion from 62.3% to 67.7% and funding from 51.2% to 55.3%, and cut journey time from 27.0 to 24.4 minutes [certified]. Approval of completed applications was unchanged (82.1% vs 81.7%), so the extra funding comes from more completions. Gains were largest on mobile (completion +9.0 points) and for cloud-accounting users (+7.6 points, 6.4 minutes faster) [certified]; businesses without accounting software took 3.5 minutes longer [certified]. Direct-channel funding rose 5.2 points [pending].

**Unintended consequences.** Broker-loan arrears rose from 2.8% to 7.4% (channel interaction p < 0.0001), with no significant change in direct or partner; brokers account for 89% of the extra arrears. Per 100 broker applicants, B added 3.3 funded loans but 2.9 more in arrears, a net gain of under half a performing loan against 4.4 elsewhere. Extra loans alone cannot explain that (86% would need to be in arrears), so B probably worsens broker loans that would have been funded anyway; a riskier applicant mix does not explain it either.

**Early-warning signals** (funded loans): a CCJ in the last six years (10.2% vs 3.6% arrears) [certified], hospitality (6.8% vs 3.5%) [pending] and, with moderate confidence, under 15 days' cash (5.0% vs 3.5%). Broker origination signals risk only under B [pending].

**On "five wins".** The gains are real but are facets of one effect, more businesses finishing. Showing them without the arrears rise would mislead the board; B's net value needs loss and margin data not in this extract.

**Method.** Figures come from the 19,200-application exploration extract, where randomisation was sound (50.2% in B). All findings except the cash-buffer signal survive Holm correction across 94 pre-specified tests.
