"""Episode 2 claim commits (tested on sealed folds 2 and 3 only, bar e = 22).
Selection used exploration + fold 1. Planning model, fitted to the referee's fold-1 evidence: per fold
ln e ~= z^2/2 - 1.6 for z > 0, folds multiply. Commit rule fixed in advance: commit if the estimated
probability of certification (per-fold mean z averaged over pooled and fold-1-only estimates) >= 0.6.
Idempotent: skips statements already committed; stops at the first failure."""
import json
import numpy as np
import northfell_tools as nt

B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"
CLAIMS = [
    dict(statement="Outside the broker channel, journey B raises the 6-month arrears rate among funded loans by less than 2 percentage points",
         outcome="arrears_6m", focal=B, reference=A, population=f"{F} and channel != 'broker'", direction="decrease", margin=-0.02),
    dict(statement="Among broker-originated funded loans, journey B raises the 6-month arrears rate by more than 1 percentage point",
         outcome="arrears_6m", focal=B, reference=A, population=f"{F} and channel == 'broker'", direction="increase", margin=0.01),
    dict(statement="Among funded loans, businesses with annual turnover under £250k have a higher 6-month arrears rate than larger businesses",
         outcome="arrears_6m", focal="turnover_band <= 2", reference="turnover_band >= 3", population=F, direction="increase", margin=0.0),
    dict(statement="Among funded loans from journey B, broker-originated loans have a higher 6-month arrears rate than loans from other channels",
         outcome="arrears_6m", focal="channel == 'broker'", reference="channel != 'broker'", population=f"{F} and {B}", direction="increase", margin=0.0),
    dict(statement="Among mobile applicants, journey B raises the share of applicants who are funded",
         outcome="funded", focal=B, reference=A, population="device == 'mobile'", direction="increase", margin=0.0),
    dict(statement="Among businesses using cloud accounting software, journey B raises the share of applicants who are funded",
         outcome="funded", focal=B, reference=A, population="accounting_software == 'cloud'", direction="increase", margin=0.0),
    dict(statement="Journey B raises the share of applicants who are funded by more than 2 percentage points",
         outcome="funded", focal=B, reference=A, population="", direction="increase", margin=0.02),
    dict(statement="Among completed applications, the share funded under journey B is no more than 3 percentage points below journey A",
         outcome="funded", focal=B, reference=A, population="completed == 1", direction="increase", margin=-0.03),
]


def p_cert(mu, ln_bar, c=1.6, folds=2, sims=200000, seed=2):
    z = np.random.default_rng(seed).normal(mu, 1, size=(sims, folds))
    return float(((np.clip(z, 0, None) ** 2 / 2 - c).sum(1) >= ln_bar).mean())


def planning_mu(df, c):
    """Per-fold expected z for the claim, averaging pooled and fold-1-only estimates (descriptive)."""
    f1 = df.iloc[19200:]
    sgn = 1 if c["direction"] == "increase" else -1
    shift = c["margin"] if c["direction"] == "increase" else -c["margin"]
    out = []
    for d in (df, f1):
        d = d.query(c["population"]) if c["population"] else d
        a, b = d.query(c["focal"])[c["outcome"]].dropna(), d.query(c["reference"])[c["outcome"]].dropna()
        est, se = a.mean() - b.mean(), np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
        out.append((est, se))
    (e_pool, se_pool), (e_f1, _) = out
    se_fold = se_pool * np.sqrt(len(df) / 9600)
    return est_pair(e_pool, e_f1), (sgn * (e_pool - shift) / se_fold + sgn * (e_f1 - shift) / se_fold) / 2


def est_pair(a, b):
    return round(float(a), 4), round(float(b), 4)


if __name__ == "__main__":
    df = nt.load_data()
    bud = nt.budget()
    ln_bar = np.log(bud["next_claim_threshold_e"])
    done = {c.get("statement") for c in nt.claims() if isinstance(c, dict)}
    results = []
    for c in CLAIMS:
        ests, mu = planning_mu(df, c)
        p = p_cert(mu, ln_bar)
        print(f"{c['statement'][:70]:70s} est(pooled,fold1)={ests} mu={mu:.2f} P={p:.2f}")
        if c["statement"] in done:
            print("  already committed")
            continue
        if p < 0.6:
            print("  NOT committed (below pre-set rule)")
            continue
        try:
            r = nt.commit_claim(**c, value=None)
            results.append({"spec": c, "planning_mu": mu, "planning_P": p, "result": r})
            print("  COMMITTED", r["id"], "bar", round(r["threshold_e"], 2), "warnings", r.get("warnings"))
        except Exception as exc:
            print("  FAILED ->", repr(exc))
            break
    with open("claims_episode2.json", "w") as fh:
        json.dump(results, fh, indent=1, default=str)
    print(json.dumps(nt.budget(), default=str))
