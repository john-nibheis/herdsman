"""Episode 1 claim commits. Idempotent: skips any statement already committed.
Selection rule: decision-critical claims (all three ExCo questions, harms included) whose exploration
evidence is strong (two-sided p < 1e-4, or the pre-specified primary arrears outcome). Statements are
directional only (margin 0): the referee certifies direction, not the exploration point estimates."""
import json
import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"
F = "funded == 1"
CLAIMS = [
    dict(statement="Journey B raises the share of applicants who are funded",
         outcome="funded", focal=B, reference=A, population="", direction="increase"),
    dict(statement="Journey B raises the 6-month arrears rate among funded loans",
         outcome="arrears_6m", focal=B, reference=A, population=F, direction="increase"),
    dict(statement="Among broker-originated funded loans, journey B raises the 6-month arrears rate",
         outcome="arrears_6m", focal=B, reference=A, population=f"{F} and channel == 'broker'", direction="increase"),
    dict(statement="Journey B raises the application completion rate",
         outcome="completed", focal=B, reference=A, population="", direction="increase"),
    dict(statement="Journey B reduces the minutes applicants spend in the application journey",
         outcome="minutes_in_journey", focal=B, reference=A, population="", direction="decrease"),
    dict(statement="For businesses using cloud accounting software, journey B reduces the minutes spent in the journey",
         outcome="minutes_in_journey", focal=B, reference=A, population="accounting_software == 'cloud'", direction="decrease"),
    dict(statement="For businesses with no accounting software, journey B increases the minutes spent in the journey",
         outcome="minutes_in_journey", focal=B, reference=A, population="accounting_software == 'none'", direction="increase"),
    dict(statement="Among mobile applicants, journey B raises the completion rate",
         outcome="completed", focal=B, reference=A, population="device == 'mobile'", direction="increase"),
    dict(statement="Among businesses using cloud accounting software, journey B raises the completion rate",
         outcome="completed", focal=B, reference=A, population="accounting_software == 'cloud'", direction="increase"),
    dict(statement="In the direct channel, journey B raises the share of applicants who are funded",
         outcome="funded", focal=B, reference=A, population="channel == 'direct'", direction="increase"),
    dict(statement="Among funded loans, applicants with a County Court Judgment in the last six years have a higher 6-month arrears rate than those without",
         outcome="arrears_6m", focal="prior_ccj == 1", reference="prior_ccj == 0", population=F, direction="increase"),
    dict(statement="Among funded loans, hospitality businesses have a higher 6-month arrears rate than businesses in other sectors",
         outcome="arrears_6m", focal="sector == 'hospitality'", reference="sector != 'hospitality'", population=F, direction="increase"),
]

if __name__ == "__main__":
    existing = nt.claims()
    done = {c.get("statement") for c in existing if isinstance(c, dict)}
    results = []
    for c in CLAIMS:
        if c["statement"] in done:
            print("already committed:", c["statement"])
            continue
        try:
            r = nt.commit_claim(**c, margin=0.0, value=None)
            results.append({"spec": c, "result": r})
            print("COMMITTED:", json.dumps(r, default=str))
        except Exception as exc:          # stop at the first failure so nothing unexpected is committed
            print("FAILED:", c["statement"], "->", repr(exc))
            break
    with open("claims_episode1.json", "w") as fh:
        json.dump(results, fh, indent=1, default=str)
    print(json.dumps(nt.budget(), indent=1, default=str))
