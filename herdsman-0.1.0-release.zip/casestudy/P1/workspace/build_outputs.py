"""Builds findings.json and report.md from test_log.csv (helper results) and descriptive arithmetic.
No new hypothesis tests are run here; every p-value comes from the logged northfell_tools tests."""
import json
import re
import numpy as np
import pandas as pd
from scipy import stats
import northfell_tools as nt
from analysis import holm, bh

log = pd.read_csv("test_log.csv", keep_default_na=False)
log = log[log.section != "rerun"].reset_index(drop=True)   # distinct comparisons only
log["family"] = log.section.str.split(":").str[0]
log["p_holm_all"] = holm(log.p_two_sided)
log["q_bh_family"] = np.nan
for fam, idx in log.groupby("family").groups.items():
    log.loc[idx, "q_bh_family"] = bh(log.loc[idx, "p_two_sided"])

B, A = "variant == 'B'", "variant == 'A'"


def get(outcome, population, focal=B, reference=A):
    m = log[(log.outcome == outcome) & (log.population == population) & (log.focal == focal) & (log.reference == reference)]
    assert len(m) == 1, (outcome, population, focal, reference, len(m))
    return m.iloc[0]


pct = lambda x: f"{100 * x:.1f}%"
pts = lambda x: f"{100 * abs(x):.1f} points"
mins = lambda x: f"{abs(x):.1f} minutes"

F1 = "funded == 1"
spec = [  # (row, statement template) in order of importance
    (get("funded", ""), lambda r: f"Journey B raises the share of applicants funded from {pct(r.mean_reference)} to {pct(r.mean_focal)} (+{pts(r.estimate)})"),
    (get("arrears_6m", F1), lambda r: f"Journey B raises 6-month arrears among funded loans from {pct(r.mean_reference)} to {pct(r.mean_focal)}, a relative rise of {r.mean_focal / r.mean_reference - 1:.0%}"),
    (get("arrears_6m", f"{F1} and channel == 'broker'"), lambda r: f"The arrears rise is concentrated in the broker channel: broker-originated loans under B have 6-month arrears of {pct(r.mean_focal)} against {pct(r.mean_reference)} under A"),
    (get("completed", ""), lambda r: f"Journey B raises application completion from {pct(r.mean_reference)} to {pct(r.mean_focal)} (+{pts(r.estimate)})"),
    (get("minutes_in_journey", ""), lambda r: f"Journey B cuts average time in the journey by {mins(r.estimate)} ({r.mean_reference:.1f} to {r.mean_focal:.1f})"),
    (get("completed", "device == 'mobile'"), lambda r: f"Journey B's completion gain is largest on mobile: {pct(r.mean_reference)} to {pct(r.mean_focal)} (+{pts(r.estimate)})"),
    (get("minutes_in_journey", "accounting_software == 'cloud'"), lambda r: f"For businesses on cloud accounting software, journey B cuts time in the journey by {mins(r.estimate)} ({r.mean_reference:.1f} to {r.mean_focal:.1f})"),
    (get("minutes_in_journey", "accounting_software == 'none'"), lambda r: f"For businesses with no accounting software, journey B adds {mins(r.estimate)} to the journey ({r.mean_reference:.1f} to {r.mean_focal:.1f})"),
    (get("arrears_6m", F1, "prior_ccj == 1", "prior_ccj == 0"), lambda r: f"Funded applicants with a CCJ in the last six years have 6-month arrears of {pct(r.mean_focal)} against {pct(r.mean_reference)} without one"),
    (get("arrears_6m", F1, "sector == 'hospitality'", "sector != 'hospitality'"), lambda r: f"Funded hospitality businesses have 6-month arrears of {pct(r.mean_focal)} against {pct(r.mean_reference)} in other sectors"),
    (get("funded", "channel == 'direct'"), lambda r: f"In the direct channel, journey B raises the share of applicants funded from {pct(r.mean_reference)} to {pct(r.mean_focal)}"),
    (get("completed", "accounting_software == 'cloud'"), lambda r: f"For businesses on cloud accounting software, journey B raises completion from {pct(r.mean_reference)} to {pct(r.mean_focal)}"),
    (get("arrears_6m", f"{F1} and prior_ccj == 0 and cash_buffer_days >= 15"), lambda r: f"Journey B raises arrears even among funded applicants with no CCJ and at least 15 days' cash buffer ({pct(r.mean_reference)} to {pct(r.mean_focal)}), so the rise is not explained by a riskier applicant mix"),
    (get("arrears_6m", F1, "cash_buffer_days < 15", "cash_buffer_days >= 15"), lambda r: f"Funded applicants with under 15 days' cash buffer have 6-month arrears of {pct(r.mean_focal)} against {pct(r.mean_reference)} (moderate evidence)"),
    (get("arrears_6m", F1, "requested_amount_k >= 101", "requested_amount_k < 101"), lambda r: f"Funded loans requesting £101k or more have lower 6-month arrears ({pct(r.mean_focal)} against {pct(r.mean_reference)}), largely because they come from larger businesses"),
]

spec = [spec[i] for i in [0, 1, 2, 3, 4, 8, 5, 6, 7, 10, 9, 12, 11, 13, 14]]   # most important first
findings = []
for r, st in spec:
    findings.append({
        "statement": st(r), "outcome": r.outcome, "population": r.population, "focal": r.focal,
        "reference": r.reference, "direction": "increase" if r.estimate > 0 else "decrease",
        "estimate": round(float(r.estimate), 4), "p_value": float(f"{r.p_two_sided:.3g}"),
    })
with open("findings.json", "w") as fh:
    json.dump(findings, fh, indent=2, ensure_ascii=False)

# ---- descriptive arithmetic for the report (no hypothesis tests) ----
df = nt.load_data().iloc[:19200]   # exploration extract; the referee appends sealed folds after row 19,200
assert (df.variant == "B").sum() == 9647


def per100(g):
    n = len(g)
    arr = g.arrears_6m.fillna(0).sum()
    return 100 * g.funded.sum() / n, 100 * arr / n


def delta_per100(g):
    fa, aa = per100(g[g.variant == "A"])
    fb, ab = per100(g[g.variant == "B"])
    return fb - fa, ab - aa


all_f, all_a = delta_per100(df)
br_f, br_a = delta_per100(df[df.channel == "broker"])

het = log[log.section == "het:arrears_6m:channel"]
w = 1 / het.se ** 2
Q = float((w * (het.estimate - (w * het.estimate).sum() / w.sum()) ** 2).sum())
q_channel_p = stats.chi2.sf(Q, len(het) - 1)

comp, fund, mn = get("completed", ""), get("funded", ""), get("minutes_in_journey", "")
appr, arr = get("funded", "completed == 1"), get("arrears_6m", F1)
mob, cldc = get("completed", "device == 'mobile'"), get("completed", "accounting_software == 'cloud'")
cldm, nonm = get("minutes_in_journey", "accounting_software == 'cloud'"), get("minutes_in_journey", "accounting_software == 'none'")
dirf, brk = get("funded", "channel == 'direct'"), get("arrears_6m", f"{F1} and channel == 'broker'")
dira, para = get("arrears_6m", f"{F1} and channel == 'direct'"), get("arrears_6m", f"{F1} and channel == 'partner'")
ccj = get("arrears_6m", F1, "prior_ccj == 1", "prior_ccj == 0")
hos = get("arrears_6m", F1, "sector == 'hospitality'", "sector != 'hospitality'")
cb = get("arrears_6m", F1, "cash_buffer_days < 15", "cash_buffer_days >= 15")
nB = (df.variant == "B").mean()
yng, tab = get("completed", "years_trading < 2"), get("completed", "device == 'tablet'")
assert yng.p_two_sided > 0.05 and tab.p_two_sided > 0.05     # backs the "no detectable gain" sentence
assert dira.p_two_sided > 0.05 and para.p_two_sided > 0.05   # backs "no significant change" in direct/partner
holm_fail = [f["statement"] for f in findings if get(f["outcome"], f["population"], f["focal"], f["reference"]).p_holm_all >= 0.05]
assert len(holm_fail) == 1 and "cash buffer" in holm_fail[0]
p_int = "p < 0.0001" if q_channel_p < 1e-4 else f"p = {q_channel_p:.2g}"
# Share of B's extra arrears (per applicant) that comes through the broker channel
contrib = {ch: (df.channel == ch).mean() * delta_per100(df[df.channel == ch])[1] for ch in df.channel.unique()}
broker_share = contrib["broker"] / sum(contrib.values())
gains = [comp, fund, mn, mob, cldc, cldm, dirf]
assert all(g.p_two_sided < 0.001 for g in gains)
n_gains = len(gains)
rel_arr = arr.mean_focal / arr.mean_reference - 1
nb_f, nb_a = delta_per100(df[df.channel != "broker"])
nb_perf = nb_f - nb_a                     # extra performing loans per 100 non-broker applicants
br_perf = br_f - br_a

# ---- referee status (live) ----
cl = {c["id"]: c for c in nt.claims()}
def tag(*ids):
    return "[certified]" if all(cl[i]["status"] == "certified" for i in ids) else "[pending]"
for c in cl.values():                      # backs "fold 1 matched the direction of every one"
    if c["episode"] == 1:
        est = c["trajectory"][0]["members"][0]["estimate"]
        assert (est > 0) == (c["members"][0]["direction"] == "increase"), c["id"]
e_c003 = 10 ** cl["C003"]["log10_e"]
folds_used = nt.budget()["folds_used"]
n_ep2 = sum(c["episode"] == 2 for c in cl.values())
report = f"""# Journey B experiment: executive summary

**Bottom line.** Journey B lifts completion and funding {tag('C001', 'C004')}, but 6-month arrears among funded loans rose from {pct(arr.mean_reference)} to {pct(arr.mean_focal)}, mostly through brokers {tag('C002', 'C003')}. Recommendation: roll B out for direct applications, keep testing with partners, pause it for brokers until the arrears rise is explained, and offer businesses without accounting software the current form.

**Referee status.** Tags show whether the independent referee has certified each claim after {folds_used} of 3 sealed folds. Pending claims stay open, and fold 1 matched the direction of every one; broker arrears evidence stands at {e_c003:.0f} against a bar of 200. {n_ep2} further claims, including that B raises arrears outside brokers by under 2 points, await folds 2 and 3.

**Did B work, and for whom?** B raised completion from {pct(comp.mean_reference)} to {pct(comp.mean_focal)} and funding from {pct(fund.mean_reference)} to {pct(fund.mean_focal)}, and cut journey time from {mn.mean_reference:.1f} to {mn.mean_focal:.1f} minutes {tag('C001', 'C004', 'C005')}. Approval of completed applications was unchanged ({pct(appr.mean_reference)} vs {pct(appr.mean_focal)}), so the extra funding comes from more completions. Gains were largest on mobile (completion +{pts(mob.estimate)}) and for cloud-accounting users (+{pts(cldc.estimate)}, {mins(cldm.estimate)} faster) {tag('C006', 'C008', 'C009')}; businesses without accounting software took {mins(nonm.estimate)} longer {tag('C007')}. Direct-channel funding rose {pts(dirf.estimate)} {tag('C010')}.

**Unintended consequences.** Broker-loan arrears rose from {pct(brk.mean_reference)} to {pct(brk.mean_focal)} (channel interaction {p_int}), with no significant change in direct or partner; brokers account for {broker_share:.0%} of the extra arrears. Per 100 broker applicants, B added {br_f:.1f} funded loans but {br_a:.1f} more in arrears, a net gain of under half a performing loan against {nb_perf:.1f} elsewhere. Extra loans alone cannot explain that ({br_a / br_f:.0%} would need to be in arrears), so B probably worsens broker loans that would have been funded anyway; a riskier applicant mix does not explain it either.

**Early-warning signals** (funded loans): a CCJ in the last six years ({pct(ccj.mean_focal)} vs {pct(ccj.mean_reference)} arrears) {tag('C011')}, hospitality ({pct(hos.mean_focal)} vs {pct(hos.mean_reference)}) {tag('C012')} and, with moderate confidence, under 15 days' cash ({pct(cb.mean_focal)} vs {pct(cb.mean_reference)}). Broker origination signals risk only under B {tag('C016')}.

**On "five wins".** The gains are real but are facets of one effect, more businesses finishing. Showing them without the arrears rise would mislead the board; B's net value needs loss and margin data not in this extract.

**Method.** Figures come from the 19,200-application exploration extract, where randomisation was sound ({pct(nB)} in B). All findings except the cash-buffer signal survive Holm correction across {len(log)} pre-specified tests.
"""
assert br_perf < 0.5   # backs "under half a performing loan"
assert len(re.findall(r"\S+", report)) < 400, len(re.findall(r"\S+", report))
with open("report.md", "w") as fh:
    fh.write(report)

words = len(re.findall(r"\S+", report))
print("report words:", words)
chk = pd.DataFrame([(f["statement"][:60], f["estimate"], f["p_value"]) for f in findings], columns=["statement", "est", "p"])
chk["p_holm_all"] = [get(f["outcome"], f["population"], f["focal"], f["reference"]).p_holm_all for f in findings]
chk["q_bh_fam"] = [get(f["outcome"], f["population"], f["focal"], f["reference"]).q_bh_family for f in findings]
pd.set_option("display.width", 200)
print(chk.round(5).to_string())
print("direct arrears", round(dira.estimate, 4), round(dira.p_two_sided, 3), "partner arrears", round(para.estimate, 4), round(para.p_two_sided, 3))
