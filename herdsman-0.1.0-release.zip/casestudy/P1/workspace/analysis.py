"""Pre-specified test plan for the Northfell journey experiment.

Every hypothesis test goes through northfell_tools (logged by the referee ledger). The plan was
fixed before looking at any subgroup or risk-signal outcome rates; cut points for continuous
variables are outcome-blind (quartiles of the full sample or standard lending thresholds).
Results are cached in test_log.csv so re-running this script does not re-run (re-log) tests.
"""
import os
import json
import numpy as np
import pandas as pd
from scipy import stats
import northfell_tools as nt

LOG = "test_log.csv"
B, A = "variant == 'B'", "variant == 'A'"

plan = []


def add(section, outcome, population, focal, reference, direction):
    plan.append(dict(section=section, outcome=outcome, population=population, focal=focal,
                     reference=reference, direction=direction))


# 1. Primary intention-to-treat effects of journey B (all applicants)
add("primary", "completed", "", B, A, "increase")
add("primary", "funded", "", B, A, "increase")
add("primary", "minutes_in_journey", "", B, A, "decrease")
add("primary", "funded", "completed == 1", B, A, "increase")          # approval given completion
add("primary", "arrears_6m", "funded == 1", B, A, "increase")         # unintended consequence

# 2. Heterogeneity of the B effect across pre-specified moderators with a product mechanism
moderators = {
    "device": ["device == 'desktop'", "device == 'mobile'", "device == 'tablet'"],
    "channel": ["channel == 'direct'", "channel == 'broker'", "channel == 'partner'"],
    "accounting_software": ["accounting_software == 'cloud'", "accounting_software == 'desktop'",
                            "accounting_software == 'none'"],
    "turnover": ["turnover_band <= 2", "turnover_band >= 3"],
    "years_trading": ["years_trading < 2", "years_trading >= 2"],
    "form_language": ["form_language == 'en'", "form_language == 'cy'"],
    "browser": ["browser == 'chrome'", "browser == 'safari'", "browser == 'edge'", "browser == 'firefox'"],
}
grid = {
    "completed": list(moderators),
    "minutes_in_journey": list(moderators),
    "funded": [m for m in moderators if m != "browser"],
    "arrears_6m": [m for m in moderators if m not in ("browser", "form_language")],
}
for outcome, mods in grid.items():
    for m in mods:
        for level in moderators[m]:
            pop = f"funded == 1 and {level}" if outcome == "arrears_6m" else level
            d = "decrease" if outcome == "minutes_in_journey" else "increase"
            add(f"het:{outcome}:{m}", outcome, pop, B, A, d)

# 3. Composition of the funded book (did B fund a riskier mix?) is described in composition() below:
#    the helper only accepts the four declared outcomes, so these are descriptive, not helper tests.

# 4. Arrears effect of B within pre-specified risk strata (composition vs within-stratum effect)
add("strata", "arrears_6m", "funded == 1 and prior_ccj == 0 and cash_buffer_days >= 15", B, A, "increase")
add("strata", "arrears_6m", "funded == 1 and prior_ccj == 1", B, A, "increase")
add("strata", "arrears_6m", "funded == 1 and cash_buffer_days < 15", B, A, "increase")

# 5. Early-warning signal screen: one pre-specified binary contrast per application characteristic
F = "funded == 1"
signals = [
    ("prior_ccj == 1", "prior_ccj == 0"),
    ("cash_buffer_days < 15", "cash_buffer_days >= 15"),
    ("years_trading < 2", "years_trading >= 2"),
    ("turnover_band == 1", "turnover_band >= 2"),
    ("accounting_software == 'none'", "accounting_software in ['cloud', 'desktop']"),
    ("vat_registered == 0", "vat_registered == 1"),
    ("email_domain in ['gmail', 'outlook', 'other']", "email_domain == 'company'"),
    ("director_count == 1", "director_count >= 2"),
    ("requested_amount_k >= 101", "requested_amount_k < 101"),
    ("employees <= 2", "employees >= 3"),
    ("channel == 'broker'", "channel in ['direct', 'partner']"),
    ("device == 'mobile'", "device in ['desktop', 'tablet']"),
    ("sector == 'hospitality'", "sector != 'hospitality'"),
    ("sector == 'construction'", "sector != 'construction'"),
    ("logo_uploaded == 1", "logo_uploaded == 0"),
    ("referral_code_used == 1", "referral_code_used == 0"),
    ("marketing_consent == 1", "marketing_consent == 0"),
    ("started_hour < 8 or started_hour >= 19", "started_hour >= 8 and started_hour < 19"),
    ("application_weekday in ['Sat', 'Sun']", "application_weekday in ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']"),
    ("company_name_length >= 31", "company_name_length < 31"),
]
for focal, ref in signals:
    add("signal", "arrears_6m", F, focal, ref, "increase")

# 6. Direction-matched re-runs of two comparisons above whose sign turned out opposite to the logged
#    direction, so each reported finding has an exact ledger entry. Same data and the same two-sided
#    p-value; excluded from the multiplicity count (they are not new comparisons).
add("rerun", "minutes_in_journey", "accounting_software == 'none'", B, A, "increase")
add("rerun", "arrears_6m", F, "requested_amount_k >= 101", "requested_amount_k < 101", "decrease")


def key(s):
    return json.dumps([s["outcome"], s["population"], s["focal"], s["reference"], s["direction"]])


def run(plan):
    done = pd.read_csv(LOG, keep_default_na=False) if os.path.exists(LOG) else pd.DataFrame()
    have = set(done.apply(lambda r: key(r), axis=1)) if len(done) else set()
    out = done
    for s in plan:
        if key(s) in have:
            continue
        r = nt.test_difference(s["outcome"], s["focal"], s["reference"], s["population"], s["direction"])
        out = pd.concat([out, pd.DataFrame([{**s, **r}])], ignore_index=True)
        out.to_csv(LOG, index=False)   # save after every test so a crash never forces a re-run
    return out


def composition():
    """Descriptive: risk mix of funded loans by variant (not a helper test; see section 3)."""
    df = nt.load_data()
    f = df[df.funded == 1]
    rows = {}
    for c in ["prior_ccj", "cash_buffer_days", "years_trading", "turnover_band"]:
        a, b = f.loc[f.variant == "A", c], f.loc[f.variant == "B", c]
        rows[c] = dict(mean_A=a.mean(), mean_B=b.mean(), diff=b.mean() - a.mean())
    rows["cash_buffer_lt15"] = dict(mean_A=(f.loc[f.variant == "A", "cash_buffer_days"] < 15).mean(),
                                    mean_B=(f.loc[f.variant == "B", "cash_buffer_days"] < 15).mean())
    return pd.DataFrame(rows).T


def holm(p):
    p = np.asarray(p, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


def bh(p):
    p = np.asarray(p, float)
    m = len(p)
    order = np.argsort(p)[::-1]
    adj = np.empty(m)
    running = 1.0
    for k, i in enumerate(order):
        rank = m - k
        running = min(running, p[i] * m / rank)
        adj[i] = running
    return adj


if __name__ == "__main__":
    res = run(plan)
    distinct = res.section != "rerun"
    res["p_holm"], res["p_bh"] = np.nan, np.nan
    res.loc[distinct, "p_holm"] = holm(res.loc[distinct, "p_two_sided"])
    res.loc[distinct, "p_bh"] = bh(res.loc[distinct, "p_two_sided"])
    res.to_csv(LOG, index=False)
    print(f"tests in log: {len(res)}")
