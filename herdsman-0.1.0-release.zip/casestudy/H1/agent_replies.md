# Run H1: replies from the analyst agent (verbatim)

## Phase 1 (unrefereed report)

I wrote findings.json with 11 findings. I could not write report.md: the harness blocks subagents from writing .md report files, and I did not bypass it. Its 388-word text is below, ready to save as /home/claude/casestudy/runs/H1/workspace/report.md.

Journey B did not work. Completion (62.4% vs 62.3%), funding (51.1% vs 51.2%) and minutes (26.9 vs 27.0) were all unchanged, with p > 0.4 each time. Its main effect was harm: arrears among funded loans rose from 3.0% to 4.4% (p = 0.0003), almost all of it in broker loans (2.8% to 7.3%, p = 4e-9). The requested segment scan of 267 comparisons gave 6 nominal B wins, against 6.7 expected by chance. None survives correction, so none is reported, and I advise against ordering a rollout by them. The early-warning signals are prior CCJ, hospitality, short trading history, thin cash buffer and small business size. All 499 tests ran through the logged helper.

(The report text that followed is saved verbatim as runs/H1/workspace/report.md.)

## Phase 2 (after the referee was introduced)

I committed 11 claims, C001 to C011, all at the e=200 bar, and kept 9 slots.

- **C001–C002:** journey B raises 6-month arrears among funded loans, for broker loans and overall.
- **C003–C008:** six early-warning signals. These are trading 10+ years, a cash buffer of 60+ days, a prior CCJ, hospitality, turnover band 4 and requests of £100k+.
- **C009–C011:** journey B brought no material benefit. That means a completion uplift under 2.5 points, a funding uplift under 2.5 points and a time saving under 1 minute. Each is set up so the referee tests the bound I intended, and it recorded them that way.

My strategy was to commit now only claims that were pre-specified or survived multiple-testing correction, and that should reach the bar within the three sealed folds. The nine spare slots wait for episode 2, when certifications will have lowered the bar and fold 1 can vet weaker candidates. I committed none of the segment "wins", because they are at chance level.

## Phase 3 (after episode 1 was closed)

I committed three new claims in episode 2, at the e=67 bar:

- **C012:** B raises completion by less than 3 points.
- **C013:** B raises funding by less than 3 points.
- **C014:** B raises broker arrears by more than 1 point.

C012 and C013 are weaker fallbacks for C009 and C010, since fold 1 showed B about 1 point ahead. If both of a pair certify, count them as one finding. Six slots are kept.

Final position: do not roll out B. It shows no benefit: the referee certified it saves under a minute, and completion and funding are within half a point of A, uncertified. It is strongly, though not yet certifiably, linked to higher broker arrears (evidence 57 of 200), so switch B off for brokers now.
