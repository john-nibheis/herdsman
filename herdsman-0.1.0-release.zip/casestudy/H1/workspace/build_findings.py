"""Builds findings.json from logged helper tests. Overall tests are re-run through the helper (identical
specs to the first ones run); segment and early-warning results come from the saved scan outputs."""
import json
import pandas as pd
import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"
seg = pd.read_csv("segment_scan_results.csv")
het = pd.read_csv("heterogeneity_results.csv")
ew = pd.read_csv("early_warning_results.csv")


def sig(x, n=4):
    return float(f"{x:.{n}g}")


def pct(x):
    return f"{100 * x:.1f}%"


def finding(statement, outcome, population, focal, reference, r):
    return {"statement": statement, "outcome": outcome, "population": population, "focal": focal,
            "reference": reference, "direction": "increase" if r["estimate"] > 0 else "decrease",
            "estimate": sig(r["estimate"], 6), "p_value": sig(r["p_two_sided"], 4)}


import os
if os.path.exists("overall_results.csv"):  # cached so rebuilding does not re-log the same tests
    overall = {row["outcome"]: row for row in pd.read_csv("overall_results.csv").to_dict("records")}
else:
    overall = {o: nt.test_difference(o, B, A, pop, d) for o, pop, d in [
        ("arrears_6m", "funded == 1", "increase"), ("completed", "", "increase"),
        ("funded", "", "increase"), ("minutes_in_journey", "", "decrease")]}
    pd.DataFrame([{"outcome": k, **v} for k, v in overall.items()]).to_csv("overall_results.csv", index=False)
df = nt.load_data()
df["fa"] = ((df.funded == 1) & (df.arrears_6m == 1)).astype(int)
itt = df.groupby("variant").fa.agg(["sum", "mean"])
fl = df[df.funded == 1]
def bin_rate(mask):
    return pct(fl[mask].arrears_6m.mean())


def ci(r, scale=100, unit="pp", dp=1):
    lo, hi = (r["estimate"] - 1.96 * r["se"]) * scale, (r["estimate"] + 1.96 * r["se"]) * scale
    return f"95% CI {lo:+.{dp}f} to {hi:+.{dp}f}{unit}"


F = []
r = overall["arrears_6m"]
F.append(finding(
    f"Unintended consequence: journey B raised 6-month arrears among funded loans from {pct(r['mean_reference'])} "
    f"to {pct(r['mean_focal'])} (+{100 * r['estimate']:.1f}pp, {ci(r)}). Funding rates are identical across arms, and per "
    f"application (a purely randomised comparison) {pct(itt.loc['B', 'mean'])} of B applications vs "
    f"{pct(itt.loc['A', 'mean'])} of A applications became funded loans in arrears ({itt.loc['B', 'sum']} vs {itt.loc['A', 'sum']}).",
    "arrears_6m", "funded == 1", B, A, r))

r = seg[(seg.outcome == "arrears_6m") & (seg.characteristic == "channel") & (seg.segment == "broker")].iloc[0]
h = het[(het.outcome == "arrears_6m") & (het.characteristic == "channel")].iloc[0]
dr, pr = [seg[(seg.outcome == "arrears_6m") & (seg.characteristic == "channel") & (seg.segment == s)].iloc[0]
          for s in ("direct", "partner")]
F.append(finding(
    f"The arrears increase is concentrated in broker-introduced loans: {pct(r['mean_reference'])} under A vs "
    f"{pct(r['mean_focal'])} under B (+{100 * r['estimate']:.1f}pp), with no change for direct "
    f"({pct(dr['mean_reference'])} vs {pct(dr['mean_focal'])}, p={dr['p_two_sided']:.2f}) or partner loans "
    f"({pct(pr['mean_reference'])} vs {pct(pr['mean_focal'])}, p={pr['p_two_sided']:.2f}). The channel difference in B's "
    f"effect survives correction (heterogeneity p={h['p_het']:.1g}; Holm-adjusted across 88 heterogeneity tests p={h['p_het_holm_all']:.1g}).",
    "arrears_6m", r["population"], B, A, r))

r = overall["completed"]
F.append(finding(
    f"Journey B did not change completion: {pct(r['mean_focal'])} vs {pct(r['mean_reference'])} ({ci(r)}). "
    f"No segment shows a B win that survives multiple-testing correction.",
    "completed", "", B, A, r))
r = overall["funded"]
F.append(finding(
    f"Journey B did not change funding: {pct(r['mean_focal'])} vs {pct(r['mean_reference'])} of applications ({ci(r)}).",
    "funded", "", B, A, r))
r = overall["minutes_in_journey"]
F.append(finding(
    f"Journey B did not shorten the journey: {r['mean_focal']:.1f} vs {r['mean_reference']:.1f} minutes "
    f"({ci(r, 1, ' min', 2)}).",
    "minutes_in_journey", "", B, A, r))

EW = [  # (characteristic, contrast, wording computed from data)
    ("prior_ccj", "1 vs 0", "A County Court Judgment in the last six years is the strongest early-warning signal"),
    ("years_trading", ">=10 vs rest",
     f"A short trading history is an early-warning signal (arrears {bin_rate(fl.years_trading < 2)} under 2 years, "
     f"falling steadily with age); businesses trading 10+ years"),
    ("cash_buffer_days", ">=60 vs rest",
     f"A thin cash buffer is an early-warning signal (arrears {bin_rate(fl.cash_buffer_days < 15)} under 15 days, "
     f"falling as the buffer grows; independent of business size); businesses with 60+ days of cash"),
    ("sector", "hospitality vs rest", "Hospitality is the riskiest sector"),
    ("turnover_band", "4 vs rest",
     f"Smaller businesses are riskier (arrears {bin_rate(fl.turnover_band == 1)} under 100k turnover); businesses turning over 1m-5m"),
    ("requested_amount_k", ">=100 vs rest",
     "Larger loan requests carry less risk, largely because they come from larger businesses (rank correlation "
     f"{fl[['requested_amount_k', 'turnover_band']].corr(method='spearman').iloc[0, 1]:.1f} with turnover band); requests of 100k+"),
]
for col, contrast, words in EW:
    r = ew[(ew.characteristic == col) & (ew.contrast == contrast)].iloc[0]
    F.append(finding(
        f"{words}: 6-month arrears {pct(r['mean_focal'])} vs {pct(r['mean_reference'])} for other funded loans "
        f"(Holm-adjusted p={r['p_holm']:.1g} across 83 screening tests; the pattern holds under journey A alone).",
        "arrears_6m", r["population"], r["focal"], r["reference"], r))

json.dump(F, open("findings.json", "w"), indent=2)
print(len(F), "findings written")

# Numbers for report.md
fav = {"completed": 1, "funded": 1, "minutes_in_journey": -1}
for o, s in fav.items():
    t = seg[seg.outcome == o]
    print(o, "nominal B wins:", ((t.p_two_sided < 0.05) & ((t.estimate * s) > 0)).sum(),
          "nominal B losses:", ((t.p_two_sided < 0.05) & ((t.estimate * s) < 0)).sum(),
          "Holm<0.05:", (t.p_holm < 0.05).sum(), "BH<0.05:", (t.p_bh < 0.05).sum(), "min BH q:", round(t.p_bh.min(), 3))
print("expected nominal wins under null across 267:", 267 * 0.025)
print("non-arrears heterogeneity min Holm p:", het[het.outcome != "arrears_6m"].p_het_holm_all.min())
print(df.groupby("variant").fa.agg(["sum", "count", "mean"]))
print(df.groupby(["channel", "variant"]).fa.sum().unstack())
print("overall ledger_seq:", [int(v["ledger_seq"]) for v in overall.values()])
