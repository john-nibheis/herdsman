"""Early-warning screen for 6-month arrears among funded loans: one pre-defined family of tests,
all run through northfell_tools (logged). Results saved to early_warning_results.csv."""
import pandas as pd
import northfell_tools as nt

POP = "funded == 1"
tests = []  # (characteristic, label, spec kwargs)

# Binary characteristics: arrears rate, flag = 1 vs flag = 0.
for col in ["vat_registered", "prior_ccj", "logo_uploaded", "referral_code_used", "marketing_consent"]:
    tests.append((col, "1 vs 0", dict(outcome="arrears_6m", focal=f"{col} == 1", reference=f"{col} == 0")))
tests.append(("form_language", "cy vs en",
              dict(outcome="arrears_6m", focal="form_language == 'cy'", reference="form_language == 'en'")))

# Categorical characteristics: arrears rate, each level vs the rest of funded loans.
for col, levels in [
    ("channel", ["direct", "broker", "partner"]),
    ("device", ["desktop", "mobile", "tablet"]),
    ("region", ["London", "South East", "North West", "West Midlands", "East of England", "Scotland",
                "Yorkshire", "South West", "East Midlands", "Wales", "North East", "Northern Ireland"]),
    ("sector", ["professional services", "retail", "construction", "other", "hospitality",
                "manufacturing", "transport", "health"]),
    ("accounting_software", ["cloud", "desktop", "none"]),
    ("application_weekday", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]),
    ("email_domain", ["company", "gmail", "outlook", "other"]),
    ("browser", ["chrome", "safari", "edge", "firefox"]),
]:
    for lv in levels:
        tests.append((col, f"{lv} vs rest", dict(outcome="arrears_6m", focal=f"{col} == '{lv}'", reference="rest")))

# Ordinal characteristics: each level vs the rest.
for col, levels in [("turnover_band", [1, 2, 3, 4, 5]), ("director_count", [1, 2, 3, 4])]:
    for lv in levels:
        tests.append((col, f"{lv} vs rest", dict(outcome="arrears_6m", focal=f"{col} == {lv}", reference="rest")))
# Numeric characteristics: the helper only accepts declared outcomes, so each numeric characteristic is
# split at the same cut points fixed in segment_scan.py before any arrears result was seen; each bin vs rest.
# (A first run of this script failed at this point after logging the 50 tests above; they were re-run unchanged.)
for col, cuts in [("years_trading", [2, 5, 10]), ("employees", [3, 10, 50]),
                  ("cash_buffer_days", [15, 30, 60]), ("requested_amount_k", [25, 50, 100]),
                  ("started_hour", [9, 13, 18]), ("company_name_length", [14, 23, 32])]:
    edges = [None] + cuts + [None]
    for lo, hi in zip(edges[:-1], edges[1:]):
        if lo is None:
            lab, filt = f"<{hi}", f"{col} < {hi}"
        elif hi is None:
            lab, filt = f">={lo}", f"{col} >= {lo}"
        else:
            lab, filt = f"{lo}-<{hi}", f"{col} >= {lo} and {col} < {hi}"
        tests.append((col, f"{lab} vs rest", dict(outcome="arrears_6m", focal=filt, reference="rest")))

rows = []
for col, label, spec in tests:
    r = nt.test_difference(spec["outcome"], spec["focal"], spec["reference"], POP, "increase")
    rows.append({"characteristic": col, "contrast": label, "population": POP, **spec, **r})
out = pd.DataFrame(rows)
out.to_csv("early_warning_results.csv", index=False)
print(len(out), "tests written")
