"""Segment-by-segment B vs A comparison requested by the Product Director.
Every test runs through northfell_tools (logged). Results saved to segment_scan_results.csv."""
import pandas as pd
import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"

SEGMENTS = []  # (characteristic, segment label, filter)
for col, levels in [
    ("channel", ["direct", "broker", "partner"]),
    ("device", ["desktop", "mobile", "tablet"]),
    ("region", ["London", "South East", "North West", "West Midlands", "East of England", "Scotland",
                "Yorkshire", "South West", "East Midlands", "Wales", "North East", "Northern Ireland"]),
    ("sector", ["professional services", "retail", "construction", "other", "hospitality",
                "manufacturing", "transport", "health"]),
    ("accounting_software", ["cloud", "desktop", "none"]),
    ("application_weekday", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]),
    ("email_domain", ["company", "gmail", "outlook", "other"]),
    ("browser", ["chrome", "safari", "edge", "firefox"]),
    ("form_language", ["en", "cy"]),
]:
    for lv in levels:
        SEGMENTS.append((col, lv, f"{col} == '{lv}'"))
for col, levels in [("turnover_band", [1, 2, 3, 4, 5]), ("director_count", [1, 2, 3, 4]),
                    ("vat_registered", [0, 1]), ("prior_ccj", [0, 1]), ("logo_uploaded", [0, 1]),
                    ("referral_code_used", [0, 1]), ("marketing_consent", [0, 1])]:
    for lv in levels:
        SEGMENTS.append((col, str(lv), f"{col} == {lv}"))
# Numeric characteristics: cut points fixed in advance (round business thresholds), not tuned.
for col, cuts in [("years_trading", [2, 5, 10]), ("employees", [3, 10, 50]),
                  ("cash_buffer_days", [15, 30, 60]), ("requested_amount_k", [25, 50, 100]),
                  ("started_hour", [9, 13, 18]), ("company_name_length", [14, 23, 32])]:
    edges = [None] + cuts + [None]
    for lo, hi in zip(edges[:-1], edges[1:]):
        if lo is None:
            SEGMENTS.append((col, f"<{hi}", f"{col} < {hi}"))
        elif hi is None:
            SEGMENTS.append((col, f">={lo}", f"{col} >= {lo}"))
        else:
            SEGMENTS.append((col, f"{lo}-<{hi}", f"{col} >= {lo} and {col} < {hi}"))

# B "wins" = completion up, funding up, minutes down. Arrears scanned as a harm check (B up = harm).
OUTCOMES = [("completed", "increase"), ("funded", "increase"),
            ("minutes_in_journey", "decrease"), ("arrears_6m", "increase")]

rows = []
for outcome, direction in OUTCOMES:
    for col, lv, filt in SEGMENTS:
        pop = f"funded == 1 and {filt}" if outcome == "arrears_6m" else filt
        r = nt.test_difference(outcome, B, A, pop, direction)
        rows.append({"outcome": outcome, "characteristic": col, "segment": lv, "population": pop,
                     "direction_tested": direction, **r})

out = pd.DataFrame(rows)
out.to_csv("segment_scan_results.csv", index=False)
print(len(SEGMENTS), "segments;", len(out), "tests written")
