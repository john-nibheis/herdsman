# Northfell application journey experiment: data dictionary

| Column | Type | Description |
|---|---|---|
| `application_id` | text | Application reference |
| `variant` | text | Randomised journey: A = current, B = open-banking pre-fill |
| `channel` | text | How the application arrived: direct, broker or partner |
| `device` | text | Device used to start the application |
| `region` | text | Business location (UK region) |
| `sector` | text | Business sector |
| `accounting_software` | text | Accounting software the business uses: cloud, desktop or none |
| `years_trading` | number | Years since incorporation |
| `turnover_band` | number | Annual turnover band (1 = under 100k ... 5 = over 5m) |
| `turnover_label` | text | Annual turnover band label |
| `employees` | number | Number of employees |
| `vat_registered` | number | 1 if VAT registered |
| `prior_ccj` | number | 1 if a County Court Judgment was recorded in the last six years |
| `cash_buffer_days` | number | Days of operating costs covered by cash at application |
| `director_count` | number | Number of directors |
| `requested_amount_k` | number | Loan amount requested, in thousands of pounds |
| `application_weekday` | text | Day of week the application started |
| `started_hour` | number | Hour of day the application started (0-23) |
| `email_domain` | text | Applicant e-mail domain type |
| `browser` | text | Browser used |
| `logo_uploaded` | number | 1 if the business uploaded a logo to its profile |
| `referral_code_used` | number | 1 if a referral code was entered |
| `marketing_consent` | number | 1 if the applicant consented to marketing |
| `form_language` | text | Language of the application form: en or cy (Welsh) |
| `company_name_length` | number | Characters in the registered company name |
| `completed` | number | 1 if the application was completed and submitted |
| `funded` | number | 1 if the loan was approved and paid out |
| `arrears_6m` | number | For funded loans: 1 if 30+ days in arrears within six months (blank if not funded) |
| `minutes_in_journey` | number | Minutes spent in the application journey |
