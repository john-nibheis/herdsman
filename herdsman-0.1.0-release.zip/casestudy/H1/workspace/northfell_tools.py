"""Helper functions for the Northfell analysis. Tests run through these functions are logged
for reproducibility. Filters use the syntax described in brief.md."""
import pandas as pd
from buachaille import Referee

_STUDY = "/home/claude/casestudy/runs/H1/study"
_ACTOR = "H1"
_ref = Referee(_STUDY)


def load_data() -> pd.DataFrame:
    """All application data currently available to you."""
    return _ref.exploration_data().copy()


def test_difference(outcome, focal, reference, population="", direction="increase"):
    """Welch z-test of mean(outcome | focal) - mean(outcome | reference) within population."""
    spec = {"outcome": outcome, "focal": focal, "reference": reference, "population": population, "direction": direction}
    return _ref.explore_test(spec, actor=_ACTOR)


def test_level(outcome, value, population="", direction="increase"):
    """One-sample z-test of mean(outcome | population) against value."""
    spec = {"outcome": outcome, "population": population, "value": value, "direction": direction}
    return _ref.explore_test(spec, actor=_ACTOR)


# --- added when Northfell adopted the referee -------------------------------------------
def commit_claim(statement, outcome, focal="", reference=None, population="", direction="increase", margin=0.0, value=None):
    """Commit a claim for certification on sealed data you have not seen."""
    spec = {"statement": statement, "outcome": outcome, "focal": focal, "reference": reference,
            "population": population, "direction": direction, "margin": margin, "value": value}
    return _ref.commit_claim(spec, actor=_ACTOR)


def budget():
    """Error budget: claim slots used and left, evidence the next claim needs."""
    return _ref.budget()


def claims():
    """Your committed claims and their status."""
    return _ref.claims()
