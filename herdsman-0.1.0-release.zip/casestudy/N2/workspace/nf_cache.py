"""Thin caching wrapper around northfell_tools so that every hypothesis is sent to the
logged helper exactly once. Each call is appended to test_log.jsonl with its stage label,
which is the full record of the inferential search used for multiplicity correction."""
import json
import os

import northfell_tools as nt

LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_log.jsonl")


def _key(spec):
    return json.dumps(spec, sort_keys=True)


def load_log():
    recs = []
    if os.path.exists(LOG):
        with open(LOG) as fh:
            for line in fh:
                line = line.strip()
                if line:
                    recs.append(json.loads(line))
    return recs


def _cached(spec):
    for rec in load_log():
        if _key(rec["spec"]) == _key(spec):
            return rec
    return None


def diff(outcome, focal, reference, population="", direction="increase", stage=""):
    spec = {"outcome": outcome, "focal": focal, "reference": reference,
            "population": population, "direction": direction}
    hit = _cached(spec)
    if hit is not None:
        return hit["result"]
    res = nt.test_difference(outcome, focal, reference, population=population, direction=direction)
    with open(LOG, "a") as fh:
        fh.write(json.dumps({"stage": stage, "spec": spec, "result": res}) + "\n")
    return res
