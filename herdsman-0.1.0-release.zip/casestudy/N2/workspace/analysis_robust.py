"""Stage 4: targeted robustness and consolidation tests decided after the screens (logged, and
counted in the multiplicity correction like every other test)."""
import nf_cache as C

B, A = "variant == 'B'", "variant == 'A'"

TESTS = [
    # consolidation of the monotone turnover pattern into one pre-declared contrast
    ("arrears_6m", "turnover_band >= 4", "rest", "funded == 1"),
    # do the early-warning signals hold under the current journey A alone?
    ("arrears_6m", "prior_ccj == 1", "rest", "funded == 1 and variant == 'A'"),
    ("arrears_6m", "years_trading > 9.75", "rest", "funded == 1 and variant == 'A'"),
    ("arrears_6m", "cash_buffer_days > 50", "rest", "funded == 1 and variant == 'A'"),
    ("arrears_6m", "sector == 'hospitality'", "rest", "funded == 1 and variant == 'A'"),
    ("arrears_6m", "turnover_band >= 4", "rest", "funded == 1 and variant == 'A'"),
    # tenure and size are correlated (rho ~ 0.55): does each carry information given the other?
    ("arrears_6m", "years_trading > 9.75", "rest", "funded == 1 and turnover_band <= 2"),
    ("arrears_6m", "turnover_band >= 4", "rest", "funded == 1 and years_trading > 5"),
    # is the journey-B arrears effect confined to brokers, and is it explained by CCJ mix?
    ("arrears_6m", B, A, "funded == 1 and channel in ['direct', 'partner']"),
    ("arrears_6m", B, A, "funded == 1 and channel == 'broker' and prior_ccj == 0"),
    # time to complete among completers (completion itself is unaffected, so little selection)
    ("minutes_in_journey", B, A, "completed == 1"),
]


def run():
    rows = []
    for out, foc, ref, pop in TESTS:
        r = C.diff(out, foc, ref, population=pop, stage="robustness")
        rows.append(dict(outcome=out, focal=foc, pop=pop, n_f=r["n_focal"], n_r=r["n_reference"],
                         m_f=r["mean_focal"], m_r=r["mean_reference"], est=r["estimate"], se=r["se"],
                         p=r["p_two_sided"], fam=r["family"]))
    return rows


if __name__ == "__main__":
    import pandas as pd
    pd.set_option("display.width", 250)
    print(pd.DataFrame(run()).to_string(index=False, float_format=lambda v: f"{v:.4g}"))
