"""Stage 2: pre-specified heterogeneity screen. B vs A within every level of every candidate
moderator, for completion, funding, minutes and (among funded loans) 6-month arrears.
All tests go through the logged helper (via nf_cache) and are corrected for multiplicity later."""
import nf_cache as C

B, A = "variant == 'B'", "variant == 'A'"

MODERATORS = {
    # tier 1: plausible mechanism for an open-banking pre-fill
    "channel": ["channel == 'direct'", "channel == 'broker'", "channel == 'partner'"],
    "device": ["device == 'desktop'", "device == 'mobile'", "device == 'tablet'"],
    "accounting_software": ["accounting_software == 'cloud'", "accounting_software == 'desktop'",
                            "accounting_software == 'none'"],
    "turnover_band": [f"turnover_band == {k}" for k in range(1, 6)],
    "years_trading": ["years_trading < 2", "years_trading >= 2 and years_trading < 5", "years_trading >= 5"],
    "prior_ccj": ["prior_ccj == 1", "prior_ccj == 0"],
    "form_language": ["form_language == 'cy'", "form_language == 'en'"],
    # tier 2: other descriptors
    "region": [f"region == '{r}'" for r in ['London', 'South East', 'North West', 'West Midlands', 'East of England',
                                             'Scotland', 'Yorkshire', 'South West', 'East Midlands', 'Wales',
                                             'North East', 'Northern Ireland']],
    "sector": [f"sector == '{s}'" for s in ['professional services', 'retail', 'construction', 'other',
                                             'hospitality', 'manufacturing', 'transport', 'health']],
    "email_domain": [f"email_domain == '{e}'" for e in ['company', 'gmail', 'outlook', 'other']],
    "browser": [f"browser == '{b}'" for b in ['chrome', 'safari', 'edge', 'firefox']],
    "vat_registered": ["vat_registered == 1", "vat_registered == 0"],
}

OUTCOMES = [("completed", ""), ("funded", ""), ("minutes_in_journey", ""), ("arrears_6m", "funded == 1")]


def run():
    rows = []
    for out, base in OUTCOMES:
        for mod, levels in MODERATORS.items():
            for lev in levels:
                pop = f"{base} and {lev}" if base else lev
                r = C.diff(out, B, A, population=pop, stage="hte_screen")
                rows.append(dict(outcome=out, moderator=mod, population=pop, nB=r["n_focal"], nA=r["n_reference"],
                                 mB=r["mean_focal"], mA=r["mean_reference"], est=r["estimate"], se=r["se"],
                                 p=r["p_two_sided"]))
    return rows


if __name__ == "__main__":
    import pandas as pd
    pd.set_option("display.width", 250); pd.set_option("display.max_rows", 500)
    df = pd.DataFrame(run())
    for out in df.outcome.unique():
        d = df[df.outcome == out]
        print(f"\n=== {out} ===")
        print(d[["population", "nB", "nA", "mB", "mA", "est", "se", "p"]].to_string(
            index=False, float_format=lambda v: f"{v:.4g}"))
