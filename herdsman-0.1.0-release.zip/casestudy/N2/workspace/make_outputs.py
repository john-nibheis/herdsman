"""Builds findings.json and report.md. Every number is read from the logged helper results in
test_log.jsonl (no hand-typed statistics)."""
import json
import re

import numpy as np

import nf_cache as C

B, A = "variant == 'B'", "variant == 'A'"
LOG = C.load_log()


def get(outcome, focal, reference, population):
    spec = {"outcome": outcome, "focal": focal, "reference": reference, "population": population,
            "direction": "increase"}
    for rec in LOG:
        s = rec["spec"]
        if all(s[k] == spec[k] for k in ("outcome", "focal", "reference", "population")):
            return rec["result"]
    raise KeyError(spec)


def pct(x, d=1):
    return f"{100 * x:.{d}f}%"


def pp(x, d=1, sign=True):
    return f"{100 * x:+.{d}f}" if sign else f"{100 * x:.{d}f}"


def ci(r, scale=100, d=1):
    lo, hi = r["estimate"] - 1.96 * r["se"], r["estimate"] + 1.96 * r["se"]
    return f"{scale * lo:+.{d}f} to {scale * hi:+.{d}f}"


def pfmt(p):
    if p < 1e-3:
        m, e = f"{p:.0e}".split("e")
        return f"{m}e{int(e)}"
    return f"{p:.2g}" if p < 0.1 else f"{p:.2f}"


def bh(p):
    p = np.asarray(p, float); n = len(p); o = np.argsort(p); q = np.empty(n)
    q[o] = np.minimum.accumulate((p[o] * n / np.arange(1, n + 1))[::-1])[::-1]
    return np.minimum(q, 1)


def holm(p):
    p = np.asarray(p, float); n = len(p); o = np.argsort(p); a = np.empty(n)
    a[o] = np.minimum(1, np.maximum.accumulate(p[o] * (n - np.arange(n))))
    return a


# ---- results used ---------------------------------------------------------------------------
r_comp = get("completed", B, A, "")
r_fund = get("funded", B, A, "")
r_min = get("minutes_in_journey", B, A, "")
r_min_c = get("minutes_in_journey", B, A, "completed == 1")
r_arr = get("arrears_6m", B, A, "funded == 1")
r_arr_br = get("arrears_6m", B, A, "funded == 1 and channel == 'broker'")
r_arr_br_noccj = get("arrears_6m", B, A, "funded == 1 and channel == 'broker' and prior_ccj == 0")
r_arr_dp = get("arrears_6m", B, A, "funded == 1 and channel in ['direct', 'partner']")
r_br_comp = get("completed", B, A, "channel == 'broker'")
r_br_fund = get("funded", B, A, "channel == 'broker'")
r_young = get("completed", B, A, "years_trading < 2")
r_yrs = get("arrears_6m", "years_trading > 9.75", "rest", "funded == 1")
r_yrs_lo = get("arrears_6m", "years_trading <= 3", "rest", "funded == 1")
r_cash = get("arrears_6m", "cash_buffer_days > 50", "rest", "funded == 1")
r_cash_lo = get("arrears_6m", "cash_buffer_days <= 15", "rest", "funded == 1")
r_ccj = get("arrears_6m", "prior_ccj == 1", "rest", "funded == 1")
r_hosp = get("arrears_6m", "sector == 'hospitality'", "rest", "funded == 1")
r_turn = get("arrears_6m", "turnover_band >= 4", "rest", "funded == 1")
r_name = get("arrears_6m", "company_name_length > 32", "rest", "funded == 1")

# per-application (fully randomised) broker arrears: arrears cases / applications
bad_B = r_arr_br["n_focal"] * r_arr_br["mean_focal"]; bad_A = r_arr_br["n_reference"] * r_arr_br["mean_reference"]
per_app_B = bad_B / r_br_comp["n_focal"]; per_app_A = bad_A / r_br_comp["n_reference"]

# ---- multiplicity -----------------------------------------------------------------------------
P = np.array([x["result"]["p_two_sided"] for x in LOG])
HOLM_ALL = holm(P)
q1_idx = [i for i, x in enumerate(LOG) if x["stage"] == "hte_screen" and x["spec"]["outcome"] != "arrears_6m"]
q1_min_q = bh(P[q1_idx]).min()
prim_idx = [i for i, x in enumerate(LOG) if x["stage"] == "primary"]
HOLM_PRIM = dict(zip(prim_idx, holm(P[prim_idx])))
N_TESTS = len(LOG)
N_EVENTS = int(round(r_arr["n_focal"] * r_arr["mean_focal"] + r_arr["n_reference"] * r_arr["mean_reference"]))


def finding(statement, outcome, population, focal, reference, r):
    return {"statement": statement, "outcome": outcome, "population": population, "focal": focal,
            "reference": reference, "direction": "increase" if r["estimate"] > 0 else "decrease",
            "estimate": round(float(r["estimate"]), 5), "p_value": float(f"{r['p_two_sided']:.3g}")}


findings = [
    finding(f"Journey B raised 6-month arrears on funded broker-originated loans from {pct(r_arr_br['mean_reference'])} "
            f"to {pct(r_arr_br['mean_focal'])}, with unchanged broker funding rates and risk mix",
            "arrears_6m", "funded == 1 and channel == 'broker'", B, A, r_arr_br),
    finding(f"Journey B raised 6-month arrears among all funded loans ({pct(r_arr['mean_focal'])} vs "
            f"{pct(r_arr['mean_reference'])}), driven by the broker channel",
            "arrears_6m", "funded == 1", B, A, r_arr),
    finding(f"No detectable effect of journey B on completion ({pct(r_comp['mean_focal'])} vs "
            f"{pct(r_comp['mean_reference'])}; 95% CI {ci(r_comp)} pp)", "completed", "", B, A, r_comp),
    finding(f"No detectable effect of journey B on funding ({pct(r_fund['mean_focal'])} vs "
            f"{pct(r_fund['mean_reference'])}; 95% CI {ci(r_fund)} pp)", "funded", "", B, A, r_fund),
    finding(f"No detectable effect of journey B on minutes in the journey ({r_min['mean_focal']:.1f} vs "
            f"{r_min['mean_reference']:.1f}; 95% CI {ci(r_min, 1)} min)", "minutes_in_journey", "", B, A, r_min),
    finding(f"No arrears effect of journey B outside the broker channel (direct and partner: "
            f"{pct(r_arr_dp['mean_focal'])} vs {pct(r_arr_dp['mean_reference'])})",
            "arrears_6m", "funded == 1 and channel in ['direct', 'partner']", B, A, r_arr_dp),
    finding(f"Businesses trading over 9.75 years have lower 6-month arrears ({pct(r_yrs['mean_focal'])} vs "
            f"{pct(r_yrs['mean_reference'])}); arrears reach {pct(r_yrs_lo['mean_focal'])} at 3 years or less",
            "arrears_6m", "funded == 1", "years_trading > 9.75", "rest", r_yrs),
    finding(f"A cash buffer above 50 days is associated with lower arrears ({pct(r_cash['mean_focal'])} vs "
            f"{pct(r_cash['mean_reference'])}); arrears reach {pct(r_cash_lo['mean_focal'])} at 15 days or less",
            "arrears_6m", "funded == 1", "cash_buffer_days > 50", "rest", r_cash),
    finding(f"A County Court Judgment in the last six years nearly triples arrears ({pct(r_ccj['mean_focal'])} vs "
            f"{pct(r_ccj['mean_reference'])})", "arrears_6m", "funded == 1", "prior_ccj == 1", "rest", r_ccj),
    finding(f"Hospitality businesses have about twice the arrears rate of other sectors ({pct(r_hosp['mean_focal'])} vs "
            f"{pct(r_hosp['mean_reference'])})", "arrears_6m", "funded == 1", "sector == 'hospitality'", "rest", r_hosp),
    finding(f"Turnover of £1m or more is associated with lower arrears ({pct(r_turn['mean_focal'])} vs "
            f"{pct(r_turn['mean_reference'])}), partly overlapping with years trading",
            "arrears_6m", "funded == 1", "turnover_band >= 4", "rest", r_turn),
]
with open("findings.json", "w") as fh:
    json.dump(findings, fh, indent=2, ensure_ascii=False)

# record the multiplicity status of each reported finding (printed for the analyst, not a deliverable)
for f in findings:
    idx = next(i for i, x in enumerate(LOG) if all(x["spec"][k] == f[k] for k in ("outcome", "focal", "reference", "population")))
    print(f"{f['p_value']:>10.3g} holm_all={HOLM_ALL[idx]:.3g} holm_primary={HOLM_PRIM.get(idx, float('nan')):.3g} | {f['statement'][:90]}")

report = f"""# Journey B experiment: executive summary

**Bottom line.** Journey B (open-banking pre-fill) delivered no measurable benefit and materially raised arrears on broker-originated loans. We recommend not rolling it out as built and investigating the broker pathway before any re-test.

**1. Did B work? No.** Randomisation is sound ({r_comp['n_focal']:,} B vs {r_comp['n_reference']:,} A; covariates balanced). B vs A: completion {pct(r_comp['mean_focal'])} vs {pct(r_comp['mean_reference'])} (95% CI {ci(r_comp)} pp); funding {pct(r_fund['mean_focal'])} vs {pct(r_fund['mean_reference'])} ({ci(r_fund)} pp); minutes {r_min['mean_focal']:.1f} vs {r_min['mean_reference']:.1f} ({ci(r_min, 1)} min), and no time saving among completers (p = {pfmt(r_min_c['p_two_sided'])}). We tested B in 51 subgroups across 12 characteristics for each outcome: none of the {len(q1_idx)} subgroup effects survives correction (smallest FDR q = {q1_min_q:.2f}); nominal hits such as {pp(r_young['estimate'])} pp completion for businesses under two years old (p = {pfmt(r_young['p_two_sided'])}) are what chance produces in a screen this size.

**2. Unintended consequences.** Arrears among funded loans were {pct(r_arr['mean_focal'])} under B vs {pct(r_arr['mean_reference'])} under A (p = {pfmt(r_arr['p_two_sided'])}). The rise is confined to brokers: {pct(r_arr_br['mean_focal'])} vs {pct(r_arr_br['mean_reference'])} (p = {pfmt(r_arr_br['p_two_sided'])}); direct and partner loans show none ({pct(r_arr_dp['mean_focal'])} vs {pct(r_arr_dp['mean_reference'])}). Broker funding rates and the risk mix of funded broker loans were unchanged, and the effect holds among applicants without a CCJ, so it is not a composition artefact. On the fully randomised per-application measure, {pct(per_app_B)} of broker applications under B ended in arrears versus {pct(per_app_A)} under A. Weaker verification of broker-submitted pre-filled data is the obvious hypothesis to check.

**3. Early-warning signals** (funded loans; each also holds within journey A alone): a CCJ ({pct(r_ccj['mean_focal'])} vs {pct(r_ccj['mean_reference'])}); hospitality ({pct(r_hosp['mean_focal'])} vs {pct(r_hosp['mean_reference'])}); short trading history ({pct(r_yrs_lo['mean_focal'])} at 3 years or less, {pct(r_yrs['mean_focal'])} beyond 9.75 years); thin cash buffer ({pct(r_cash_lo['mean_focal'])} at 15 days or less, {pct(r_cash['mean_focal'])} above 50); turnover under £1m (£1m+: {pct(r_turn['mean_focal'])} vs {pct(r_turn['mean_reference'])}; employees and loan size carry the same size signal). Broker origination is a warning sign only under journey B. Digital-footprint fields show nothing credible; a nominal company-name-length association (p = {pfmt(r_name['p_two_sided'])}) has no plausible mechanism, tracks no risk driver and fails family-wise correction, so we treat it as chance.

**Method.** All {N_TESTS} tests ran through the logged helper (test_log.jsonl); reported effects survive Holm correction (overall arrears within the primary tests, the rest across all {N_TESTS}). Signals are predictive, not causal, and rest on {N_EVENTS} arrears events.
"""
with open("report.md", "w") as fh:
    fh.write(report)
words = len(re.findall(r"\S+", re.sub(r"[#*]", "", report)))
print("report words:", words)
