"""Episode 1 claims for the Buachaille referee. Only substantive claims that the exploration
analysis supports strongly enough to have a realistic chance of reaching e = 200 within the three
sealed folds. Non-superiority claims are written in the 'increase' direction with a negative
margin, so that H1 is simply (focal - reference) > margin whichever way the margin is read."""
import json
import sys

import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"

CLAIMS = [
    # Q2: unintended consequence of journey B
    dict(statement="Journey B raises the 6-month arrears rate on funded broker-originated loans",
         outcome="arrears_6m", focal=B, reference=A, population="funded == 1 and channel == 'broker'",
         direction="increase", margin=0.0),
    dict(statement="Journey B raises the 6-month arrears rate among funded loans overall",
         outcome="arrears_6m", focal=B, reference=A, population="funded == 1",
         direction="increase", margin=0.0),
    # Q1: did journey B work? Bounded (non-superiority) claims
    dict(statement="Journey B does not raise completion by 3 percentage points or more "
                   "(completion under A minus completion under B exceeds -0.03)",
         outcome="completed", focal=A, reference=B, population="", direction="increase", margin=-0.03),
    dict(statement="Journey B does not raise funding by 3 percentage points or more "
                   "(funding under A minus funding under B exceeds -0.03)",
         outcome="funded", focal=A, reference=B, population="", direction="increase", margin=-0.03),
    dict(statement="Journey B does not shorten the application journey by one minute or more "
                   "(minutes under B minus minutes under A exceeds -1.0)",
         outcome="minutes_in_journey", focal=B, reference=A, population="", direction="increase", margin=-1.0),
    # Q3: early-warning signals of 6-month arrears among funded loans
    dict(statement="Funded businesses trading more than 9.75 years have a lower 6-month arrears rate than other funded businesses",
         outcome="arrears_6m", focal="years_trading > 9.75", reference="rest", population="funded == 1",
         direction="decrease", margin=0.0),
    dict(statement="Funded businesses with a cash buffer above 50 days have a lower 6-month arrears rate than other funded businesses",
         outcome="arrears_6m", focal="cash_buffer_days > 50", reference="rest", population="funded == 1",
         direction="decrease", margin=0.0),
    dict(statement="Funded businesses with a County Court Judgment in the last six years have a higher 6-month arrears rate",
         outcome="arrears_6m", focal="prior_ccj == 1", reference="rest", population="funded == 1",
         direction="increase", margin=0.0),
    dict(statement="Funded hospitality businesses have a higher 6-month arrears rate than other funded businesses",
         outcome="arrears_6m", focal="sector == 'hospitality'", reference="rest", population="funded == 1",
         direction="increase", margin=0.0),
    dict(statement="Funded businesses with turnover of £1m or more have a lower 6-month arrears rate than other funded businesses",
         outcome="arrears_6m", focal="turnover_band >= 4", reference="rest", population="funded == 1",
         direction="decrease", margin=0.0),
]

if __name__ == "__main__":
    which = [int(i) for i in sys.argv[1:]] if len(sys.argv) > 1 else range(len(CLAIMS))
    for i in which:
        c = CLAIMS[i]
        try:
            res = nt.commit_claim(c["statement"], c["outcome"], focal=c["focal"], reference=c["reference"],
                                  population=c["population"], direction=c["direction"], margin=c["margin"])
        except Exception as exc:  # report and carry on; a rejected claim should not consume a slot
            res = {"error": repr(exc)}
        print(i, json.dumps(res, default=str))
