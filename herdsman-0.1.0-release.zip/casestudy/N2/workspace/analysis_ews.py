"""Stage 3: pre-specified early-warning screen for 6-month arrears among funded loans.
Every level of every application characteristic is compared with the rest of the funded book.
Numeric characteristics are screened as bottom quartile vs rest and top quartile vs rest, with
quartiles computed once among funded loans. All tests go through the logged helper."""
import northfell_tools as nt
import nf_cache as C

POP = "funded == 1"

CATEGORICAL = {
    "channel": ['direct', 'broker', 'partner'],
    "device": ['desktop', 'mobile', 'tablet'],
    "region": ['London', 'South East', 'North West', 'West Midlands', 'East of England', 'Scotland', 'Yorkshire',
               'South West', 'East Midlands', 'Wales', 'North East', 'Northern Ireland'],
    "sector": ['professional services', 'retail', 'construction', 'other', 'hospitality', 'manufacturing',
               'transport', 'health'],
    "accounting_software": ['cloud', 'desktop', 'none'],
    "application_weekday": ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    "email_domain": ['company', 'gmail', 'outlook', 'other'],
    "browser": ['chrome', 'safari', 'edge', 'firefox'],
}
ORDINAL = {"turnover_band": [1, 2, 3, 4, 5], "director_count": [1, 2, 3, 4]}
BINARY = ["vat_registered", "prior_ccj", "logo_uploaded", "referral_code_used", "marketing_consent"]
NUMERIC = ["years_trading", "employees", "cash_buffer_days", "requested_amount_k", "started_hour",
           "company_name_length", "minutes_in_journey"]


def filters():
    df = nt.load_data()
    f = df[df.funded == 1]
    out = []
    for col, levels in CATEGORICAL.items():
        out += [(col, f"{col} == '{v}'") for v in levels]
    for col, levels in ORDINAL.items():
        out += [(col, f"{col} == {v}") for v in levels]
    out += [(col, f"{col} == 1") for col in BINARY]
    out += [("form_language", "form_language == 'cy'"), ("variant", "variant == 'B'")]
    for col in NUMERIC:
        q25, q75 = f[col].quantile([0.25, 0.75])
        out += [(col, f"{col} <= {q25:g}"), (col, f"{col} > {q75:g}")]
    return out


def run():
    rows = []
    for col, flt in filters():
        r = C.diff("arrears_6m", flt, "rest", population=POP, stage="ews_screen")
        rows.append(dict(variable=col, focal=flt, n_focal=r["n_focal"], n_ref=r["n_reference"],
                         m_focal=r["mean_focal"], m_ref=r["mean_reference"], est=r["estimate"], se=r["se"],
                         p=r["p_two_sided"]))
    return rows


if __name__ == "__main__":
    import pandas as pd
    pd.set_option("display.width", 250); pd.set_option("display.max_rows", 500)
    d = pd.DataFrame(run())
    print(d.to_string(index=False, float_format=lambda v: f"{v:.4g}"))
