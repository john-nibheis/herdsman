"""Episode 2 claims (bar e = 50, tested on folds 2 and 3 only). Fold 1 confirmed the broker
arrears harm (+3.5 pp), no harm outside brokers (+0.2 pp) and no material completion or funding
gain (+1.2 / +1.0 pp). The referee pairs focal and reference observations (n_obs = min of the
two groups), so power was judged on the paired sample. No exact re-commits of open claims.
Run once only: commits are irreversible."""
import json

import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"

CLAIMS = [
    dict(statement="Journey B raises the 6-month arrears rate on funded broker-originated loans by more than "
                   "1 percentage point",
         outcome="arrears_6m", focal=B, reference=A, population="funded == 1 and channel == 'broker'",
         direction="increase", margin=0.01),
    dict(statement="Outside the broker channel (direct and partner), journey B raises the 6-month arrears rate "
                   "on funded loans by less than 2 percentage points",
         outcome="arrears_6m", focal=B, reference=A, population="funded == 1 and channel in ['direct', 'partner']",
         direction="decrease", margin=-0.02),
    dict(statement="Journey B raises completion by less than 4 percentage points",
         outcome="completed", focal=B, reference=A, population="", direction="decrease", margin=-0.04),
    dict(statement="Journey B raises funding by less than 4 percentage points",
         outcome="funded", focal=B, reference=A, population="", direction="decrease", margin=-0.04),
]

if __name__ == "__main__":
    for c in CLAIMS:
        try:
            res = nt.commit_claim(c["statement"], c["outcome"], focal=c["focal"], reference=c["reference"],
                                  population=c["population"], direction=c["direction"], margin=c["margin"])
            print(res["id"], res["status"], round(res["threshold_e"], 1), res.get("warnings"), "|", res["statement"])
        except Exception as exc:
            print("ERROR", repr(exc), "|", c["statement"])
    print(json.dumps(nt.budget(), default=str))
