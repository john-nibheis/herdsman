# Run N1: replies from the analyst agent (verbatim)

## Phase 1 (unrefereed report)

I reported 15 findings. Both files are in the workspace: /home/claude/casestudy/runs/N1/workspace/findings.json and /home/claude/casestudy/runs/N1/workspace/report.md (381 words). They rest on 164 tests run through the helper, and all 15 findings stay significant after Bonferroni correction across all 164.

Journey B works. Completion rose from 62.3% to 67.7%, funding from 51.2% to 55.3%, and time in the journey fell from 27.0 to 24.4 minutes. Approval among completed applications did not change, so the extra funding comes from more completions. The gains are largest on mobile (+9.0pp) and for cloud-accounting users (+7.6pp, 6.4 minutes faster). There is no detectable gain on tablets or for businesses trading under two years.

The main unintended consequence is in the broker channel: B raises 6-month arrears on funded broker loans from 2.8% to 7.4%. Direct and partner loans are unchanged. B also adds 3.5 minutes for businesses with no accounting software.

The early-warning signals of arrears are a prior CCJ, hospitality, younger businesses and thin cash buffers. Broker loans are riskier only under journey B.

## Phase 2 (after the referee was introduced)

I committed 14 claims, C001 to C014, each with a bar of e = 200. Six slots remain. The records are in /home/claude/casestudy/runs/N1/workspace/work/claims_ep1.json.

- **Headline:** C001 to C004 cover journey B's effect on completion, funding, journey time and arrears on broker loans.
- **For whom:** C005 to C008, C013 and C014 cover the mobile, cloud-accounting and no-software subgroup effects.
- **Arrears signals:** C009 to C012 cover a prior CCJ, nine or more years trading, at least 48 days of cash buffer, and hospitality.

Strategy: I committed now only claims expected to reach z of about 3 or more on a single 9,600-application fold. They get evidence from all three folds, and their certifications lower the bar for later claims. I'm holding the weaker overall-arrears claim, and any minimum-effect or non-inferiority claims, for episode 2, when the bar should be lower and fold 1 adds data.

Decision for you: all claims use margin 0, because `margin` has no documented units or sign for "decrease" claims. Could you confirm both, so episode 2 can include minimum-effect claims?

## Phase 3 (after episode 1 was closed)

I committed five new claims, C015 to C019, each needing e = 18 on folds 2 and 3:
- **C015:** outside the broker channel, journey B raises the funded share.
- **C016:** outside the broker channel, any rise in 6-month arrears from B is under 2pp.
- **C017:** B raises broker-loan arrears by more than 1pp.
- **C018:** B raises completion by more than 2pp.
- **C019:** B raises arrears across all funded loans.

I'm holding the last slot for episode 3. Its fallback is a near-certain claim that cloud-accounting journeys are more than 5 minutes shorter.

Final position: roll B out for direct and partner applicants, where its completion, funding and speed gains are certified. Hold it for brokers until C003, the broker-arrears claim (at e = 150 of the 200 needed), certifies.

One correction: report.md's "no gain for businesses under two years" did not replicate in fold 1.
