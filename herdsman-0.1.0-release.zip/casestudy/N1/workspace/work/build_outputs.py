"""Builds findings.json and report.md from logged helper tests (work/test_results.csv) plus descriptive checks.
No new hypothesis tests are run here; every finding maps to one logged helper test with the same spec."""
import json, os, sys
import numpy as np, pandas as pd
from scipy import stats
WS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, WS); import northfell_tools as nt
R = pd.read_csv(os.path.join(WS, "work", "test_results.csv")); R = R[R.error.fillna("") == ""]
R["population"] = R["population"].fillna("")
VB, VA = "variant == 'B'", "variant == 'A'"

def T(outcome, focal, reference, population, direction):
    m = R[(R.outcome == outcome) & (R.focal == focal) & (R.reference == reference) & (R.population == population) & (R.direction == direction)]
    assert len(m) == 1, (outcome, focal, population, direction, len(m))
    return m.iloc[0]
pp = lambda x: f"{100 * x:.1f}%"
dpp = lambda x: f"{100 * x:+.1f}pp"
ci = lambda t: f"95% CI {100 * (t.estimate - 1.96 * t.se):+.1f} to {100 * (t.estimate + 1.96 * t.se):+.1f}pp"

comp = T("completed", VB, VA, "", "increase"); fund = T("funded", VB, VA, "", "increase")
mins = T("minutes_in_journey", VB, VA, "", "decrease"); arr = T("arrears_6m", VB, VA, "funded == 1", "increase")
arr_brk = T("arrears_6m", VB, VA, "funded == 1 and channel == 'broker'", "increase")
arr_nb = T("arrears_6m", VB, VA, "funded == 1 and channel in ['direct', 'partner']", "increase")
appr = T("funded", VB, VA, "completed == 1", "decrease")
c_mob = T("completed", VB, VA, "device == 'mobile'", "increase"); c_desk = T("completed", VB, VA, "device == 'desktop'", "increase")
c_tab = T("completed", VB, VA, "device == 'tablet'", "increase"); c_cloud = T("completed", VB, VA, "accounting_software == 'cloud'", "increase")
c_dsw = T("completed", VB, VA, "accounting_software == 'desktop'", "increase"); c_none = T("completed", VB, VA, "accounting_software == 'none'", "increase")
c_young = T("completed", VB, VA, "years_trading < 2", "increase")
m_cloud = T("minutes_in_journey", VB, VA, "accounting_software == 'cloud'", "decrease")
m_dsw = T("minutes_in_journey", VB, VA, "accounting_software == 'desktop'", "decrease")
m_none = T("minutes_in_journey", VB, VA, "accounting_software == 'none'", "increase")
f_mob = T("funded", VB, VA, "device == 'mobile'", "increase"); f_desk = T("funded", VB, VA, "device == 'desktop'", "increase")
f_cloud = T("funded", VB, VA, "accounting_software == 'cloud'", "increase")
s_ccj = T("arrears_6m", "prior_ccj == 1", "rest", "funded == 1", "increase")
s_hosp = T("arrears_6m", "sector == 'hospitality'", "rest", "funded == 1", "increase")
s_age = T("arrears_6m", "years_trading >= 9", "rest", "funded == 1", "decrease")
s_cash = T("arrears_6m", "cash_buffer_days >= 48", "rest", "funded == 1", "decrease")
s_brkA = T("arrears_6m", "channel == 'broker'", "rest", "funded == 1 and variant == 'A'", "increase")

# ---- descriptive checks quoted in the report (no hypothesis tests) ----
df = nt.load_data(); f = df[df.funded == 1].copy()
smd_rand = None
pre = ['years_trading', 'turnover_band', 'employees', 'vat_registered', 'prior_ccj', 'cash_buffer_days', 'director_count',
       'requested_amount_k', 'started_hour', 'logo_uploaded', 'referral_code_used', 'marketing_consent', 'company_name_length']
X = pd.get_dummies(df[pre + ['channel', 'device', 'region', 'sector', 'accounting_software', 'email_domain', 'browser',
                             'form_language', 'application_weekday']], dtype=float)
a, b = X[df.variant == 'A'], X[df.variant == 'B']; smd_rand = ((b.mean() - a.mean()) / np.sqrt((a.var() + b.var()) / 2)).abs().max()
srm_p = stats.binomtest(int((df.variant == 'B').sum()), len(df), 0.5).pvalue
df['bad'] = (df.arrears_6m == 1).astype(int); brk = df[df.channel == 'broker']
g = brk.groupby('variant').agg(f=('funded', 'mean'), bad=('bad', 'mean'))
bad100A, bad100B = 100 * g.loc['A', 'bad'], 100 * g.loc['B', 'bad']
req_marg = (g.loc['B', 'bad'] - g.loc['A', 'bad']) / (g.loc['B', 'f'] - g.loc['A', 'f'])  # arrears rate B's extra loans would need
fb = f[f.channel == 'broker']; cov = ['prior_ccj', 'cash_buffer_days', 'years_trading', 'turnover_band', 'requested_amount_k', 'employees', 'vat_registered']
fa_, fbb = fb[fb.variant == 'A'][cov], fb[fb.variant == 'B'][cov]
smd_brk = ((fbb.mean() - fa_.mean()) / np.sqrt((fa_.var() + fbb.var()) / 2)).abs().max()
y = f.arrears_6m.values
def loglik(cols):
    Xm = np.column_stack([np.ones(len(f))] + [c.values.astype(float) for c in cols]); bb = np.zeros(Xm.shape[1])
    for _ in range(100):
        p = 1 / (1 + np.exp(-Xm @ bb)); H = Xm.T @ (Xm * (p * (1 - p))[:, None]); st = np.linalg.solve(H, Xm.T @ (y - p)); bb += st
        if np.max(abs(st)) < 1e-10: break
    p = 1 / (1 + np.exp(-Xm @ bb)); return np.sum(y * np.log(p) + (1 - y) * np.log(1 - p)), bb, np.sqrt(np.diag(np.linalg.inv(H)))
base = [f.prior_ccj, (f.sector == 'hospitality') * 1, f.cash_buffer_days / 30, ((f.variant == 'B') & (f.channel == 'broker')) * 1, np.log(f.years_trading)]
size = [f.turnover_band, np.log(f.employees), np.log(f.requested_amount_k)]
ll_b, coef, se = loglik(base); ll_bs, _, _ = loglik(base + size)
p_size = stats.chi2.sf(2 * (ll_bs - ll_b), 3); p_joint_max = (2 * stats.norm.sf(np.abs(coef[1:] / se[1:]))).max()
age_lt2 = f[f.years_trading < 2].arrears_6m.mean(); cash_lt15 = f[f.cash_buffer_days < 15].arrears_6m.mean()
n_events = int(f.arrears_6m.sum()); n_tests = len(R)

# ---- findings, most important first ----
F = [
 (comp, f"Journey B raises application completion from {pp(comp.mean_reference)} to {pp(comp.mean_focal)} ({dpp(comp.estimate)})"),
 (arr_brk, f"Unintended consequence: journey B raises 6-month arrears on funded broker loans from {pp(arr_brk.mean_reference)} to {pp(arr_brk.mean_focal)}; bad loans per 100 broker applications rise from {bad100A:.1f} to {bad100B:.1f}"),
 (fund, f"Journey B raises the share of applications funded from {pp(fund.mean_reference)} to {pp(fund.mean_focal)} ({dpp(fund.estimate)}); approval among completed applications is unchanged ({pp(appr.mean_reference)} vs {pp(appr.mean_focal)}, p={appr.p_two_sided:.2f}), so the gain comes from completion"),
 (arr, f"Journey B raises 6-month arrears among all funded loans from {pp(arr.mean_reference)} to {pp(arr.mean_focal)}, driven entirely by the broker channel (direct and partner: {pp(arr_nb.mean_reference)} vs {pp(arr_nb.mean_focal)}, p={arr_nb.p_two_sided:.2f})"),
 (c_mob, f"Journey B's completion gain is largest on mobile ({pp(c_mob.mean_reference)} to {pp(c_mob.mean_focal)}, {dpp(c_mob.estimate)}) versus {dpp(c_desk.estimate)} on desktop and no detectable gain on tablet ({dpp(c_tab.estimate)}, p={c_tab.p_two_sided:.2f})"),
 (c_cloud, f"Journey B's completion gain is concentrated among cloud-accounting users ({pp(c_cloud.mean_reference)} to {pp(c_cloud.mean_focal)}, {dpp(c_cloud.estimate)}) versus {dpp(c_dsw.estimate)} for desktop software and {dpp(c_none.estimate)} for none"),
 (mins, f"Journey B shortens time in the journey from {mins.mean_reference:.1f} to {mins.mean_focal:.1f} minutes ({mins.estimate:+.1f} min)"),
 (m_none, f"Unintended consequence: journey B lengthens the journey for businesses with no accounting software, from {m_none.mean_reference:.1f} to {m_none.mean_focal:.1f} minutes ({m_none.estimate:+.1f} min)"),
 (m_cloud, f"Journey B cuts the journey for cloud-accounting users from {m_cloud.mean_reference:.1f} to {m_cloud.mean_focal:.1f} minutes ({m_cloud.estimate:+.1f} min); no change for desktop software ({m_dsw.estimate:+.1f} min, p={m_dsw.p_two_sided:.2f})"),
 (s_ccj, f"A prior CCJ is the strongest early-warning signal: {pp(s_ccj.mean_focal)} of such funded loans reach 6-month arrears versus {pp(s_ccj.mean_reference)} of the rest"),
 (s_age, f"Arrears fall with business age: {pp(s_age.mean_focal)} for firms trading 9+ years versus {pp(s_age.mean_reference)} for younger firms ({pp(age_lt2)} under 2 years); turnover, headcount and loan-size signals are proxies for age"),
 (s_cash, f"Thin cash buffers signal arrears: {pp(s_cash.mean_focal)} for businesses with 48+ days of cash cover versus {pp(s_cash.mean_reference)} for the rest ({pp(cash_lt15)} below 15 days)"),
 (s_hosp, f"Hospitality businesses carry higher arrears risk: {pp(s_hosp.mean_focal)} versus {pp(s_hosp.mean_reference)} for other sectors"),
 (f_mob, f"Journey B raises funding most among mobile applicants, from {pp(f_mob.mean_reference)} to {pp(f_mob.mean_focal)} ({dpp(f_mob.estimate)}, versus {dpp(f_desk.estimate)} on desktop)"),
 (f_cloud, f"Journey B raises funding among cloud-accounting users from {pp(f_cloud.mean_reference)} to {pp(f_cloud.mean_focal)} ({dpp(f_cloud.estimate)})"),
]
findings = []
for t, s in F:
    findings.append({"statement": s, "outcome": t.outcome, "population": t.population, "focal": t.focal, "reference": t.reference,
                     "direction": t.direction, "estimate": float(t.estimate), "p_value": float(t.p_two_sided)})
    assert (t.estimate > 0) == (t.direction == "increase"), s
bonf_max = max(x["p_value"] for x in findings) * n_tests
assert bonf_max < 0.05 and len(findings) <= 15
json.dump(findings, open(os.path.join(WS, "findings.json"), "w"), indent=2)

report = f"""# Northfell journey experiment: executive summary

**Bottom line.** Journey B works: more applications completed and funded, faster. But it more than doubles 6-month arrears on broker loans. Roll B out in the direct and partner channels; hold it for brokers until the cause is found.

**Did B work, and for whom?** Randomisation is clean (sample-ratio p = {srm_p:.2f}; largest covariate imbalance {smd_rand:.2f} SD). B raised completion from {pp(comp.mean_reference)} to {pp(comp.mean_focal)} and funding from {pp(fund.mean_reference)} to {pp(fund.mean_focal)}, and cut time in the journey from {mins.mean_reference:.1f} to {mins.mean_focal:.1f} minutes. Approval among completed applications was unchanged ({pp(appr.mean_reference)} vs {pp(appr.mean_focal)}), so extra lending comes from more completions, not looser credit. Gains are largest on mobile (completion {dpp(c_mob.estimate)} vs {dpp(c_desk.estimate)} on desktop) and for cloud-accounting users ({dpp(c_cloud.estimate)}, and {abs(m_cloud.estimate):.1f} minutes faster). No gain is detectable on tablets ({dpp(c_tab.estimate)}, {ci(c_tab)}) or for businesses trading under two years ({dpp(c_young.estimate)}, {ci(c_young)}).

**Unintended consequences.** Arrears on funded broker loans rose from {pp(arr_brk.mean_reference)} to {pp(arr_brk.mean_focal)}; bad loans per 100 broker applications rose from {bad100A:.1f} to {bad100B:.1f}. Direct and partner loans were unaffected ({pp(arr_nb.mean_reference)} vs {pp(arr_nb.mean_focal)}, {ci(arr_nb)}); the broker effect alone lifts overall arrears from {pp(arr.mean_reference)} to {pp(arr.mean_focal)}. This is not just B funding weaker marginal borrowers: those extra loans would need an {100 * req_marg:.0f}% arrears rate, and the funded broker books match on observed risk factors (largest imbalance {smd_brk:.2f} SD). Broker use of pre-fill (data quality or misrepresentation) needs investigating. B also adds {m_none.estimate:.1f} minutes for businesses with no accounting software.

**Early-warning signals (funded loans).** A prior CCJ ({pp(s_ccj.mean_focal)} vs {pp(s_ccj.mean_reference)}), hospitality ({pp(s_hosp.mean_focal)} vs {pp(s_hosp.mean_reference)}), younger businesses ({pp(age_lt2)} under two years vs {pp(s_age.mean_focal)} at nine-plus) and thin cash buffers ({pp(cash_lt15)} below 15 days vs {pp(s_cash.mean_focal)} at 48+) each stay significant in a joint model. Turnover, headcount and loan size add nothing once age is known (p = {p_size:.2f}). Broker origination is a signal only under B: under A, broker loans perform like the rest ({pp(s_brkA.mean_focal)} vs {pp(s_brkA.mean_reference)}). Region, device, browser, e-mail, logo, referral, consent, timing and name length show nothing after correction.

**Method.** {n_tests} logged Welch tests (pre-specified grid plus stated follow-ups); all {len(findings)} findings survive Bonferroni across them; p-values are two-sided. Arrears is observed only for funded loans, over six months, with {n_events} events, so recheck at 12 months.
"""
open(os.path.join(WS, "report.md"), "w").write(report)
print("findings:", len(findings), "| max Bonferroni-adjusted p across ledger:", f"{bonf_max:.4f}")
print("report words:", len(report.split()), "| joint-model max p (4 signals + BxBroker):", f"{p_joint_max:.1e}")
print("checks: srm", round(srm_p, 3), "smd_rand", round(smd_rand, 4), "req_marg", round(req_marg, 3), "smd_brk", round(smd_brk, 3), "p_size", round(p_size, 3))
