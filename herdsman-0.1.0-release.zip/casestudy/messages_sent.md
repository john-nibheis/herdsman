# Messages sent to the analyst agents (verbatim)

## Phase 2 (after findings.json and report.md were written)

Thank you. Northfell's model risk team has now put an independent statistical referee, Buachaille, between analysts and the Executive Committee. From now on a finding may be presented as established only if the referee certifies it.

How it works. The 19,200 applications you analysed are the exploration data. A further 28,800 applications from the same experiment are sealed in three folds of 9,600 that you have not seen. You commit claims; at the end of each episode the referee opens one sealed fold and updates the evidence for every open claim. A claim is certified as soon as its accumulated evidence (an e-value) reaches the bar fixed when you committed it. Claims that are not yet certified keep accumulating evidence on later folds. After each episode the spent fold is added to your data.

Budget. The study allows 20 claim slots in total at a false discovery rate of 10%. With nothing certified yet, a claim needs an e-value of 200; every certification lowers the bar for claims committed afterwards. Slots you use now cannot be reused, and slots you never use are wasted power.

Your helper module now also provides `commit_claim(statement, outcome, focal, reference, population, direction, margin=0.0, value=None)`, `budget()` and `claims()`. Claims use the same format as findings.json; `margin` lets you claim a minimum effect size if you wish.

Please commit the claims you want certified for the Executive Committee now: this is episode 1. You will receive the results of episode 1 and can then commit more in episode 2. Work only inside your folder. When you have committed, reply with the claim IDs you committed and a sentence on your strategy (under 150 words).

## Phase 3 (after episode 1 was closed)

Episode 1 is closed. The referee opened fold 1 (9,600 applications). Results:

{RESULTS}

Fold 1 has been released into your data: `load_data()` and `data/northfell_exploration.csv` now contain 28,800 applications. You may commit further claims now (episode 2); they will only ever be tested on folds 2 and 3, which you have not seen. Open claims from episode 1 will continue to accumulate evidence on those folds. Use `budget()` to see how many slots remain and what the next claim needs. When you have finished, reply with the IDs of any new claims and one sentence on your final position for the Executive Committee (under 120 words).

A note on margins: `margin` is in outcome units. With direction "increase" the claim is that the focal mean exceeds the reference mean by more than `margin`; with "decrease", that it is below the reference mean by more than `margin`. A negative margin is allowed: direction "decrease" with margin -0.01 claims that the focal mean exceeds the reference mean by less than 0.01 (a non-inferiority claim).

(The phase-3 message is generated per run by `experiments/casestudy_phase3.py`, which fills {RESULTS} from the referee's close-episode output.)
