"""Northfell journey experiment: pre-specified analysis plan.

The test grid below was fixed before any outcome was broken down by subgroup or characteristic
(only the overall completion test had been run). Every hypothesis test goes through
northfell_tools so that the ledger holds the full set of comparisons examined. Inference uses
two-sided p-values with Holm correction within each family; directions passed to the helper are
the a-priori expectations and do not affect the two-sided p-values used.
"""
import numpy as np
import pandas as pd
from scipy import stats
import northfell_tools as nt

B, A = "variant == 'B'", "variant == 'A'"

# ---------------------------------------------------------------- the plan
plan = []


def add(fam, outcome, focal, reference, population="", direction="increase"):
    plan.append(dict(fam=fam, outcome=outcome, focal=focal, reference=reference,
                     population=population, direction=direction))


# P: primary intention-to-treat effects of journey B (whole population; arrears needs funded == 1)
add("P_primary", "completed", B, A, "", "increase")
add("P_primary", "funded", B, A, "", "increase")
add("P_primary", "minutes_in_journey", B, A, "", "decrease")
add("P_primary", "arrears_6m", B, A, "funded == 1", "increase")

# M: mechanism (conditional on a post-randomisation stage, so descriptive of the funnel, not causal)
add("M_mechanism", "funded", B, A, "completed == 1", "decrease")
add("M_mechanism", "minutes_in_journey", B, A, "completed == 1", "decrease")

# C: composition of the funded book by variant (does B fund a riskier mix?)
add("C_composition", "prior_ccj", B, A, "funded == 1", "increase")
add("C_composition", "cash_buffer_days", B, A, "funded == 1", "decrease")
add("C_composition", "years_trading", B, A, "funded == 1", "decrease")

# H: heterogeneity of the B effect, pre-specified moderators with a mechanism rationale
moderators = {
    "device": ["device == 'desktop'", "device == 'mobile'", "device == 'tablet'"],
    "channel": ["channel == 'direct'", "channel == 'broker'", "channel == 'partner'"],
    "accounting_software": ["accounting_software == 'cloud'", "accounting_software == 'desktop'",
                            "accounting_software == 'none'"],
    "form_language": ["form_language == 'en'", "form_language == 'cy'"],
    "browser": ["browser == 'chrome'", "browser == 'safari'", "browser == 'edge'", "browser == 'firefox'"],
    "years_trading": ["years_trading < 2", "years_trading >= 2"],
    "turnover_band": ["turnover_band == 1", "turnover_band >= 2"],
    "prior_ccj": ["prior_ccj == 0", "prior_ccj == 1"],
    "cash_buffer": ["cash_buffer_days < 15", "cash_buffer_days >= 15"],
}
het_outcomes = {"completed": "increase", "funded": "increase",
                "minutes_in_journey": "decrease", "arrears_6m": "increase"}
for o, d in het_outcomes.items():
    for mod, subs in moderators.items():
        for s in subs:
            pop = f"funded == 1 and {s}" if o == "arrears_6m" else s
            add(f"H_{o}", o, B, A, pop, d)

# R: early-warning screen for 6-month arrears among funded loans, every application characteristic,
# a-priori cut-offs (quartiles of the covariate or standard credit-policy thresholds), level-vs-rest
F = "funded == 1"
risk = [
    ("prior_ccj == 1", "increase"), ("vat_registered == 0", "increase"),
    ("logo_uploaded == 1", "decrease"), ("referral_code_used == 1", "increase"),
    ("marketing_consent == 1", "increase"), ("form_language == 'cy'", "increase"),
    ("application_weekday in ['Sat', 'Sun']", "increase"),
    ("years_trading < 2", "increase"), ("turnover_band == 1", "increase"),
    ("employees <= 2", "increase"), ("cash_buffer_days < 15", "increase"),
    ("director_count == 1", "increase"), ("requested_amount_k >= 100", "increase"),
    ("started_hour in [0, 1, 2, 3, 4, 5, 6, 20, 21, 22, 23]", "increase"),
    ("company_name_length >= 31", "increase"),
]
levels = {
    "channel": ["direct", "broker", "partner"], "device": ["desktop", "mobile", "tablet"],
    "accounting_software": ["cloud", "desktop", "none"],
    "email_domain": ["company", "gmail", "outlook", "other"],
    "browser": ["chrome", "safari", "edge", "firefox"],
    "region": ["London", "South East", "North West", "West Midlands", "East of England", "Scotland",
               "Yorkshire", "South West", "East Midlands", "Wales", "North East", "Northern Ireland"],
    "sector": ["professional services", "retail", "construction", "other", "hospitality",
               "manufacturing", "transport", "health"],
}
for col, lv in levels.items():
    for v in lv:
        risk.append((f"{col} == '{v}'", "increase"))
for focal, d in risk:
    add("R_risk_screen", "arrears_6m", focal, "rest", F, d)


# ---------------------------------------------------------------- helpers
def holm(p):
    p = np.asarray(p, float)
    m, order = len(p), np.argsort(p)
    adj, run = np.empty(m), 0.0
    for rank, i in enumerate(order):
        run = max(run, min(1.0, (m - rank) * p[i]))
        adj[i] = run
    return adj


def bh(p):
    p = np.asarray(p, float)
    m, order = len(p), np.argsort(p)[::-1]
    adj, run = np.empty(m), 1.0
    for k, i in enumerate(order):
        run = min(run, p[i] * m / (m - k))
        adj[i] = run
    return adj


# ---------------------------------------------------------------- run
if __name__ == "__main__":
    rows = []
    for t in plan:
        r = dict(t)
        try:
            res = nt.test_difference(t["outcome"], t["focal"], t["reference"], t["population"], t["direction"])
            r.update(res)
        except Exception as e:  # keep going, record the problem
            r["error"] = repr(e)
        rows.append(r)
    res = pd.DataFrame(rows)
    if "error" in res and res["error"].notna().any():
        print(res.loc[res["error"].notna(), ["fam", "outcome", "focal", "population", "error"]])
    res["p_holm"] = np.nan
    res["p_bh"] = np.nan
    for fam, g in res.groupby("fam"):
        ok = g["p_two_sided"].notna()
        res.loc[g.index[ok], "p_holm"] = holm(g.loc[ok, "p_two_sided"])
        res.loc[g.index[ok], "p_bh"] = bh(g.loc[ok, "p_two_sided"])

    # Cochran's Q heterogeneity of the B effect across levels of each moderator (derived from helper output)
    qrows = []
    for o in het_outcomes:
        g = res[res.fam == f"H_{o}"]
        for mod, subs in moderators.items():
            pops = [f"funded == 1 and {s}" if o == "arrears_6m" else s for s in subs]
            gg = g[g.population.isin(pops)]
            e, se = gg["estimate"].values, gg["se"].values
            w = 1 / se ** 2
            ebar = (w * e).sum() / w.sum()
            Q = (w * (e - ebar) ** 2).sum()
            qrows.append(dict(outcome=o, moderator=mod, Q=Q, df=len(e) - 1,
                              p_het=stats.chi2.sf(Q, len(e) - 1),
                              effects="; ".join(f"{s.split(' ', 2)[-1]}:{x:+.4f}" for s, x in zip(subs, e))))
    qd = pd.DataFrame(qrows)
    qd["p_holm"] = np.nan
    for o, g in qd.groupby("outcome"):
        qd.loc[g.index, "p_holm"] = holm(g["p_het"])

    res.to_csv("analysis_results.csv", index=False)
    qd.to_csv("analysis_heterogeneity_Q.csv", index=False)
    print(f"tests run: {len(res)}")
