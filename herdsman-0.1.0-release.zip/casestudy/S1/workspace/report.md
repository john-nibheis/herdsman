# Journey B experiment: executive summary

Under the referee, 9 of 20 claims are certified on sealed data (C002–C010). The other 11 are still accumulating evidence on folds 2 and 3, so only the first section below is established.

Journey B (open-banking pre-fill) lifts conversion and shortens the journey, but the evidence so far, not yet certified, points to higher 6-month arrears on broker-introduced loans. I recommend adopting B for direct and partner applications, with arrears monitoring, and holding it for brokers until that claim is settled and the cause understood.

## Did B work, and for whom? (certified)

On 19,200 exploration applications, B raised completion from 62.3% to 67.7% and funding from 51.2% to 55.3%, and cut average journey time from 27.0 to 24.4 minutes. It raised completion and funding among mobile and cloud-accounting users (completion +9.0pp and +7.6pp) and cut cloud users' journey by 6.4 minutes, but businesses without accounting software took 3.5 minutes longer.

## Unintended consequences (not yet certified)

Among funded loans, 6-month arrears rose from 3.0% to 4.6%, concentrated in broker loans (2.8% to 7.4%; other channels 3.2% under A, 3.2% under B). Fold 1 repeated the broker rise (3.2% to 7.1%), but that claim's evidence is 147 against the 200 required. B changes who is funded, yet its 33 extra broker loans per 1,000 applicants cannot explain 29 extra arrears cases, and funded broker loans look alike across journeys on CCJs, cash buffers, trading history and size. Approval of completed applications did not change detectably (A 82.1%, B 81.7%).

## Early-warning signals (not yet certified)

Among funded loans, a County Court Judgment in the last six years (10.2% in arrears against 3.6%) and hospitality (6.8% against 3.5%) flag higher arrears in both journeys. Requests of £100k or more flag lower arrears (2.7% against 4.3%), though 99.1% come from businesses turning over £250k or more. Turnover under £100k and cash buffers under 15 days are weaker signals now under test. Broker origination is not a signal under journey A (2.8% against 3.2%), and fields such as browser and e-mail domain showed none.

## Method and limits

Arms were balanced (all standardised differences below 0.04). Exploration tests ran through the logged helper from a pre-fixed plan and survive Bonferroni correction; certification uses only sealed folds, at a 10% false discovery rate. Six-month arrears is an early indicator, not default. Tablet and Welsh-language groups are too small to judge.
