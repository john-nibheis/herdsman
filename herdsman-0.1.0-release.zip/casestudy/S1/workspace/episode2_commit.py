"""Episode 2: log each new claim's margin-0 test on all data now available (28,800 rows) through the helper,
then commit the claims. Selection rationale (fold-1 replication) is in episode2_check.py."""
import json
import pandas as pd
import northfell_tools as nt

B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"
NB = "channel in ['direct', 'partner']"
claims = [
    ("Journey B raises 6-month arrears among funded loans.",
     "arrears_6m", B, A, F, "increase", 0.0),
    ("Among funded direct and partner loans, journey B's 6-month arrears rate exceeds journey A's by less than 2 percentage points.",
     "arrears_6m", B, A, F + " and " + NB, "decrease", -0.02),
    ("Journey B raises the share of applications funded among direct and partner applicants.",
     "funded", B, A, NB, "increase", 0.0),
    ("Funded loans to businesses with a County Court Judgment in the last six years have higher 6-month arrears than other funded loans.",
     "arrears_6m", "prior_ccj == 1", "rest", F, "increase", 0.0),
    ("Funded loans with a requested amount of £100k or more have lower 6-month arrears than other funded loans.",
     "arrears_6m", "requested_amount_k >= 100", "rest", F, "decrease", 0.0),
    ("Funded hospitality loans have higher 6-month arrears than funded loans in other sectors.",
     "arrears_6m", "sector == 'hospitality'", "rest", F, "increase", 0.0),
    ("Funded loans to businesses with turnover under £100k have higher 6-month arrears than other funded loans.",
     "arrears_6m", "turnover_band == 1", "rest", F, "increase", 0.0),
    ("Funded loans to businesses with a cash buffer under 15 days have higher 6-month arrears than other funded loans.",
     "arrears_6m", "cash_buffer_days < 15", "rest", F, "increase", 0.0),
    ("Among completed applications, journey B's funding (approval) rate exceeds journey A's by less than 3 percentage points.",
     "funded", B, A, "completed == 1", "decrease", -0.03),
    ("Under journey A, funded broker-introduced loans have a 6-month arrears rate less than 2 percentage points above other funded loans.",
     "arrears_6m", "channel == 'broker'", "rest", F + " and " + A, "decrease", -0.02),
]
b = nt.budget()
assert b["slots_left"] == len(claims) and round(b["next_claim_threshold_e"]) == 20, b
log = []
for st, o, fo, rf, po, d, m in claims:
    t = nt.test_difference(o, fo, rf, po, d)
    z_claim = ((t["estimate"] - m) if d == "increase" else (-t["estimate"] - m)) / t["se"]
    r = nt.commit_claim(statement=st, outcome=o, focal=fo, reference=rf, population=po, direction=d, margin=m)
    log.append(dict(id=r["id"], threshold_e=round(r["threshold_e"], 1), warnings=r["warnings"], outcome=o, population=po,
                    focal=fo, reference=rf, direction=d, margin=m, n_focal=t["n_focal"], n_reference=t["n_reference"],
                    est_28800=round(t["estimate"], 5), se_28800=round(t["se"], 5), z_vs_margin_28800=round(z_claim, 2),
                    statement=st))
pd.DataFrame(log).to_csv("episode2_claims.csv", index=False)
print(pd.DataFrame(log).drop(columns=["statement", "population", "focal", "reference"]).to_string())
print(json.dumps(nt.budget(), default=str))
