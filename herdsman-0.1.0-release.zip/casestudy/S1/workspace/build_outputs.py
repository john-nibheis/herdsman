"""Builds findings.json and report.md from the logged test results (analysis.py) plus descriptive
checks. Every number in both deliverables is computed here."""
import json
import numpy as np
import pandas as pd
import northfell_tools as nt
from analysis import holm, B, A

res = pd.read_csv("analysis_results.csv")
res["population"] = res["population"].fillna("")
res = res[res["error"].isna()].copy()
qd = pd.read_csv("analysis_heterogeneity_Q.csv")
full = nt.load_data()
df, f1 = full.iloc[:19200].copy(), full.iloc[19200:].copy()
_p = res[(res.fam == "P_primary") & (res.outcome == "completed")].iloc[0]
assert len(df) == 19200 and abs(df.loc[df.variant == "B", "completed"].mean() - _p.mean_focal) < 1e-12
assert abs(df.loc[df.variant == "A", "completed"].mean() - _p.mean_reference) < 1e-12
assert not set(f1.application_id) & set(df.application_id)

# ---- direction-corrected re-runs: same two-sided test, logged with the direction actually reported
reruns = [("minutes_in_journey", B, A, "accounting_software == 'none'", "increase"),
          ("arrears_6m", "requested_amount_k >= 100", "rest", "funded == 1", "decrease")]
# (run once on the first build and logged by the helper; identical two-sided p-values were asserted then)

# ---- robustness: early-warning signals within each journey arm (run once, cached so the ledger is not inflated)
import os
ROB = "analysis_robustness.csv"
rob_specs = [("arrears_6m", f, "rest", f"funded == 1 and variant == '{v}'", d)
             for f, d in [("prior_ccj == 1", "increase"), ("sector == 'hospitality'", "increase"),
                          ("requested_amount_k >= 100", "decrease")] for v in ["A", "B"]]
rob_specs.append(("arrears_6m", "channel == 'broker'", "rest", "funded == 1 and variant == 'A'", "increase"))
if not os.path.exists(ROB):
    rr = []
    for o, f, r, p, d in rob_specs:
        out = nt.test_difference(o, f, r, p, d)
        rr.append(dict(outcome=o, focal=f, reference=r, population=p, direction=d, **out))
    pd.DataFrame(rr).to_csv(ROB, index=False)
rob = pd.read_csv(ROB)
def robp(f, v):
    return rob[(rob.focal == f) & (rob.population == f"funded == 1 and variant == '{v}'")].iloc[0]


def arms(f):
    a, b = robp(f, "A"), robp(f, "B")
    return (f"journey A {pc(a.mean_focal)} vs {pc(a.mean_reference)}, {pv(a.p_two_sided)}; "
            f"journey B {pc(b.mean_focal)} vs {pc(b.mean_reference)}, {pv(b.p_two_sided)}")

# ---- multiplicity: Holm within the plan's families and within the helper ledger's families
u = res.drop_duplicates(subset=["outcome", "focal", "reference", "population"]).copy()
u["p_holm_ledger"] = u.groupby("family")["p_two_sided"].transform(lambda s: holm(s.values))
n_tests = len(u) + len(rob)
n_screen = int((u.fam == "R_risk_screen").sum())


def get(o, f, r, p):
    row = u[(u.outcome == o) & (u.focal == f) & (u.reference == r) & (u.population == p)]
    assert len(row) == 1, (o, f, r, p)
    return row.iloc[0]


def qhet(o, mod):
    return float(qd[(qd.outcome == o) & (qd.moderator == mod)]["p_het"].iloc[0])


pc = lambda x: f"{100 * x:.1f}%"
pp = lambda x: f"{100 * x:+.1f}pp"
mn = lambda x: f"{x:.1f}"
pv = lambda x: "p<0.001" if x < 0.001 else (f"p={x:.3f}" if x < 0.01 else f"p={x:.2f}")
F = "funded == 1"

# ---- pull the tests that feed findings and the report
t = {
    "comp": get("completed", B, A, ""), "fund": get("funded", B, A, ""),
    "mins": get("minutes_in_journey", B, A, ""), "arr": get("arrears_6m", B, A, F),
    "appr": get("funded", B, A, "completed == 1"),
    "arr_broker": get("arrears_6m", B, A, F + " and channel == 'broker'"),
    "arr_direct": get("arrears_6m", B, A, F + " and channel == 'direct'"),
    "arr_partner": get("arrears_6m", B, A, F + " and channel == 'partner'"),
    "comp_mob": get("completed", B, A, "device == 'mobile'"),
    "comp_desk": get("completed", B, A, "device == 'desktop'"),
    "comp_tab": get("completed", B, A, "device == 'tablet'"),
    "comp_cloud": get("completed", B, A, "accounting_software == 'cloud'"),
    "comp_dsw": get("completed", B, A, "accounting_software == 'desktop'"),
    "comp_none": get("completed", B, A, "accounting_software == 'none'"),
    "fund_mob": get("funded", B, A, "device == 'mobile'"),
    "fund_cloud": get("funded", B, A, "accounting_software == 'cloud'"),
    "min_cloud": get("minutes_in_journey", B, A, "accounting_software == 'cloud'"),
    "min_none": get("minutes_in_journey", B, A, "accounting_software == 'none'"),
    "ccj": get("arrears_6m", "prior_ccj == 1", "rest", F),
    "hosp": get("arrears_6m", "sector == 'hospitality'", "rest", F),
    "big": get("arrears_6m", "requested_amount_k >= 100", "rest", F),
    "cash": get("arrears_6m", "cash_buffer_days < 15", "rest", F),
}

# ---- descriptive checks (no hypothesis tests)
def smd(x, g):
    a, b = x[g == "A"].astype(float), x[g == "B"].astype(float)
    s = np.sqrt((a.var() + b.var()) / 2)
    return 0.0 if s == 0 else (b.mean() - a.mean()) / s

covs = ["years_trading", "turnover_band", "employees", "vat_registered", "prior_ccj", "cash_buffer_days",
        "director_count", "requested_amount_k", "started_hour", "logo_uploaded", "referral_code_used",
        "marketing_consent", "company_name_length"]
cats = ["channel", "device", "region", "sector", "accounting_software", "application_weekday",
        "email_domain", "browser", "form_language"]
smds = {c: smd(df[c], df.variant) for c in covs}
for c in cats:
    for lv in df[c].unique():
        smds[f"{c}={lv}"] = smd((df[c] == lv).astype(int), df.variant)
max_smd = max(abs(s) for s in smds.values())

fb = df[(df.funded == 1) & (df.channel == "broker")].assign(hosp=lambda d: (d.sector == "hospitality").astype(int))
comp_cols = ["prior_ccj", "cash_buffer_days", "years_trading", "turnover_band", "requested_amount_k",
             "employees", "vat_registered", "hosp"]
broker_smds = {c: smd(fb[c], fb.variant) for c in comp_cols}
max_broker_smd = max(abs(s) for s in broker_smds.values())

def per_1000(d):
    out = {}
    for v in ["A", "B"]:
        s = d[d.variant == v]
        fr = s.funded.mean()
        ar = s.loc[s.funded == 1, "arrears_6m"].mean()
        out[v] = dict(funded=fr, arrears_rate=ar, arrears_per_1000=1000 * fr * ar,
                      performing_per_1000=1000 * fr * (1 - ar))
    out["implied_marginal_arrears"] = ((out["B"]["arrears_per_1000"] - out["A"]["arrears_per_1000"])
                                       / (out["B"]["funded"] - out["A"]["funded"]) / 1000)
    return out

eco = {"all": per_1000(df), "broker": per_1000(df[df.channel == "broker"]),
       "non_broker": per_1000(df[df.channel != "broker"])}
fa = df[(df.funded == 1) & (df.variant == "A")]
broker_A, nonbroker_A = (fa.loc[fa.channel == "broker", "arrears_6m"].mean(),
                         fa.loc[fa.channel != "broker", "arrears_6m"].mean())
cash_by_arm = (df[df.funded == 1].assign(low=lambda d: d.cash_buffer_days < 15)
               .groupby(["variant", "low"]).arrears_6m.mean().unstack())

# ---- findings, most important first
fd, keys = [], []

def add(key, outcome, focal, reference, population, statement):
    r = t[key]
    direction = "increase" if r["estimate"] > 0 else "decrease"
    assert r["p_holm_ledger"] < 0.05 and get(outcome, focal, reference, population)["p_holm"] < 0.05, key
    keys.append(key)
    fd.append({"statement": statement, "outcome": outcome, "population": population, "focal": focal,
               "reference": reference, "direction": direction,
               "estimate": round(float(r["estimate"]), 5), "p_value": float(f"{r['p_two_sided']:.3g}")})

r = t["arr_broker"]
add("arr_broker", "arrears_6m", B, A, F + " and channel == 'broker'",
    f"Journey B raises 6-month arrears on broker-introduced funded loans from {pc(r.mean_reference)} to "
    f"{pc(r.mean_focal)} ({pp(r.estimate)}); direct ({pp(t['arr_direct'].estimate)}, {pv(t['arr_direct'].p_two_sided)}) "
    f"and partner ({pp(t['arr_partner'].estimate)}, {pv(t['arr_partner'].p_two_sided)}) loans show no detectable change "
    f"(channel heterogeneity {pv(qhet('arrears_6m', 'channel'))}).")
r = t["arr"]
add("arr", "arrears_6m", B, A, F,
    f"Journey B raises 6-month arrears among funded loans from {pc(r.mean_reference)} to {pc(r.mean_focal)} "
    f"({pp(r.estimate)}); the comparison is among funded loans, whose mix B itself changes, and the rise is "
    f"concentrated in the broker channel (other channels: {pc(eco['non_broker']['A']['arrears_rate'])} under A, "
    f"{pc(eco['non_broker']['B']['arrears_rate'])} under B).")
r = t["comp"]
add("comp", "completed", B, A, "",
    f"Journey B raises application completion from {pc(r.mean_reference)} to {pc(r.mean_focal)} ({pp(r.estimate)}).")
r, ap = t["fund"], t["appr"]
add("fund", "funded", B, A, "",
    f"Journey B raises the share of applications funded from {pc(r.mean_reference)} to {pc(r.mean_focal)} "
    f"({pp(r.estimate)}), driven by extra completions rather than approvals: approval of completed applications shows no detectable change "
    f"(A {pc(ap.mean_reference)}, B {pc(ap.mean_focal)}, {pv(ap.p_two_sided)}).")
r = t["mins"]
add("mins", "minutes_in_journey", B, A, "",
    f"Journey B cuts average time in the journey from {mn(r.mean_reference)} to {mn(r.mean_focal)} minutes "
    f"({r.estimate:+.1f} minutes).")
r = t["comp_mob"]
add("comp_mob", "completed", B, A, "device == 'mobile'",
    f"Journey B's completion gain is largest on mobile: {pc(r.mean_reference)} to {pc(r.mean_focal)} "
    f"({pp(r.estimate)}), against {pp(t['comp_desk'].estimate)} on desktop and no detectable change on tablet "
    f"(device heterogeneity {pv(qhet('completed', 'device'))}).")
r = t["comp_cloud"]
add("comp_cloud", "completed", B, A, "accounting_software == 'cloud'",
    f"Among businesses using cloud accounting software, journey B raises completion from {pc(r.mean_reference)} "
    f"to {pc(r.mean_focal)} ({pp(r.estimate)}), against {pp(t['comp_dsw'].estimate)} (desktop software) and "
    f"{pp(t['comp_none'].estimate)} (no software), neither significant after adjustment "
    f"(heterogeneity {pv(qhet('completed', 'accounting_software'))}).")
r = t["min_none"]
add("min_none", "minutes_in_journey", B, A, "accounting_software == 'none'",
    f"For businesses with no accounting software, journey B lengthens the journey from {mn(r.mean_reference)} "
    f"to {mn(r.mean_focal)} minutes ({r.estimate:+.1f} minutes), the opposite of the overall time saving.")
r = t["ccj"]
ac = arms("prior_ccj == 1")
add("ccj", "arrears_6m", "prior_ccj == 1", "rest", F,
    f"Funded loans to businesses with a County Court Judgment in the last six years have 6-month arrears of "
    f"{pc(r.mean_focal)} against {pc(r.mean_reference)} for other funded loans, and higher in both journeys ({ac}).")
r = t["hosp"]
ah = arms("sector == 'hospitality'")
add("hosp", "arrears_6m", "sector == 'hospitality'", "rest", F,
    f"Funded hospitality loans have 6-month arrears of {pc(r.mean_focal)} against {pc(r.mean_reference)} for "
    f"other sectors, and higher in both journeys ({ah}).")
r = t["fund_mob"]
add("fund_mob", "funded", B, A, "device == 'mobile'",
    f"Among mobile applicants, journey B raises the share funded from {pc(r.mean_reference)} to "
    f"{pc(r.mean_focal)} ({pp(r.estimate)}).")
r = t["fund_cloud"]
add("fund_cloud", "funded", B, A, "accounting_software == 'cloud'",
    f"Among cloud-accounting businesses, journey B raises the share funded from {pc(r.mean_reference)} to "
    f"{pc(r.mean_focal)} ({pp(r.estimate)}).")
r = t["min_cloud"]
add("min_cloud", "minutes_in_journey", B, A, "accounting_software == 'cloud'",
    f"For cloud-accounting businesses, journey B cuts time in the journey from {mn(r.mean_reference)} to "
    f"{mn(r.mean_focal)} minutes ({r.estimate:+.1f} minutes).")
r = t["big"]
ab = arms("requested_amount_k >= 100")
fbig = df[(df.funded == 1) & (df.requested_amount_k >= 100)]
big_large = (fbig.turnover_band >= 3).mean()
add("big", "arrears_6m", "requested_amount_k >= 100", "rest", F,
    f"Funded loans with requests of £100k or more have lower 6-month arrears ({pc(r.mean_focal)} against "
    f"{pc(r.mean_reference)}), lower in both journeys ({ab}); {pc(big_large)} of these loans are to businesses "
    f"turning over £250k or more, so the signal overlaps heavily with business size.")

ORDER = ["arr_broker", "arr", "comp", "fund", "mins", "comp_mob", "comp_cloud", "ccj", "hosp", "min_none",
         "fund_mob", "fund_cloud", "min_cloud", "big"]
assert sorted(ORDER) == sorted(keys)
fd = [fd[keys.index(k)] for k in ORDER]
# every reported finding must survive Bonferroni across every distinct test run
assert all(x["p_value"] * n_tests < 0.05 for x in fd)
# the report's qualitative claim that funded broker loans look alike across journeys
assert max(abs(broker_smds[c]) for c in ["prior_ccj", "cash_buffer_days", "years_trading", "requested_amount_k", "turnover_band"]) < 0.05
with open("findings.json", "w") as fh:
    json.dump(fd, fh, indent=2, ensure_ascii=False)

# ---- report
n_chars = res.loc[res.fam == "R_risk_screen", "family"].nunique()
cosmetic = u[(u.fam == "R_risk_screen") & u.family.str.contains(
    "browser|email_domain|logo_uploaded|company_name_length|application_weekday|started_hour")]
assert len(cosmetic) == 12 and (cosmetic.p_holm > 0.05).all()
assert t["cash"].p_two_sided < 0.05 < t["cash"].p_holm
eb, en, rb = eco["broker"], eco["non_broker"], robp("channel == 'broker'", "A")
cl = nt.claims()
cert = [c["id"] for c in cl if c["status"] == "certified"]
c001 = next(c for c in cl if c["id"] == "C001")
assert cert == [f"C{i:03d}" for i in range(2, 11)] and c001["status"] == "open"
f1b = f1[(f1.funded == 1) & (f1.channel == "broker")].groupby("variant").arrears_6m.mean()
v = dict(
    n=len(df), smd=f"{np.ceil(max_smd * 100) / 100:.2f}", n_cert=len(cert), n_claims=len(cl),
    n_open=len(cl) - len(cert), cert_ids=f"{cert[0]}–{cert[-1]}",
    c1e=f"{10 ** c001['log10_e']:.0f}", c1t=f"{c001['threshold_e']:.0f}",
    f1A=pc(f1b["A"]), f1B=pc(f1b["B"]),
    cA=pc(t["comp"].mean_reference), cB=pc(t["comp"].mean_focal),
    fA=pc(t["fund"].mean_reference), fB=pc(t["fund"].mean_focal),
    mA=mn(t["mins"].mean_reference), mB=mn(t["mins"].mean_focal),
    apA=pc(t["appr"].mean_reference), apB=pc(t["appr"].mean_focal),
    mob=pp(t["comp_mob"].estimate), cloud=pp(t["comp_cloud"].estimate),
    cloud_min=f"{-t['min_cloud'].estimate:.1f}", none_min=f"{t['min_none'].estimate:.1f}",
    arA=pc(t["arr"].mean_reference), arB=pc(t["arr"].mean_focal),
    brA=pc(t["arr_broker"].mean_reference), brB=pc(t["arr_broker"].mean_focal),
    nbA=pc(en["A"]["arrears_rate"]), nbB=pc(en["B"]["arrears_rate"]),
    br_fund=f"{1000 * (eb['B']['funded'] - eb['A']['funded']):.0f}",
    br_arr=f"{eb['B']['arrears_per_1000'] - eb['A']['arrears_per_1000']:.0f}",
    ccj1=pc(t["ccj"].mean_focal), ccj0=pc(t["ccj"].mean_reference),
    h1=pc(t["hosp"].mean_focal), h0=pc(t["hosp"].mean_reference),
    big1=pc(t["big"].mean_focal), big0=pc(t["big"].mean_reference), bigl=pc(big_large),
    brAo=pc(rb.mean_focal), brAr=pc(rb.mean_reference),
)
report = """# Journey B experiment: executive summary

Under the referee, {n_cert} of {n_claims} claims are certified on sealed data ({cert_ids}). The other {n_open} are still accumulating evidence on folds 2 and 3, so only the first section below is established.

Journey B (open-banking pre-fill) lifts conversion and shortens the journey, but the evidence so far, not yet certified, points to higher 6-month arrears on broker-introduced loans. I recommend adopting B for direct and partner applications, with arrears monitoring, and holding it for brokers until that claim is settled and the cause understood.

## Did B work, and for whom? (certified)

On {n:,} exploration applications, B raised completion from {cA} to {cB} and funding from {fA} to {fB}, and cut average journey time from {mA} to {mB} minutes. It raised completion and funding among mobile and cloud-accounting users (completion {mob} and {cloud}) and cut cloud users' journey by {cloud_min} minutes, but businesses without accounting software took {none_min} minutes longer.

## Unintended consequences (not yet certified)

Among funded loans, 6-month arrears rose from {arA} to {arB}, concentrated in broker loans ({brA} to {brB}; other channels {nbA} under A, {nbB} under B). Fold 1 repeated the broker rise ({f1A} to {f1B}), but that claim's evidence is {c1e} against the {c1t} required. B changes who is funded, yet its {br_fund} extra broker loans per 1,000 applicants cannot explain {br_arr} extra arrears cases, and funded broker loans look alike across journeys on CCJs, cash buffers, trading history and size. Approval of completed applications did not change detectably (A {apA}, B {apB}).

## Early-warning signals (not yet certified)

Among funded loans, a County Court Judgment in the last six years ({ccj1} in arrears against {ccj0}) and hospitality ({h1} against {h0}) flag higher arrears in both journeys. Requests of £100k or more flag lower arrears ({big1} against {big0}), though {bigl} come from businesses turning over £250k or more. Turnover under £100k and cash buffers under 15 days are weaker signals now under test. Broker origination is not a signal under journey A ({brAo} against {brAr}), and fields such as browser and e-mail domain showed none.

## Method and limits

Arms were balanced (all standardised differences below {smd}). Exploration tests ran through the logged helper from a pre-fixed plan and survive Bonferroni correction; certification uses only sealed folds, at a 10% false discovery rate. Six-month arrears is an early indicator, not default. Tablet and Welsh-language groups are too small to judge.
""".format(**v)
with open("report.md", "w") as fh:
    fh.write(report)

nw = len(report.replace("#", " ").split()); print("words:", nw); assert nw < 400
print("findings:", len(fd), "| unique tests:", n_tests, "| screen size:", n_screen)
print("max SMD all:", round(max_smd, 3), sorted(smds.items(), key=lambda kv: -abs(kv[1]))[:3])
print("broker funded SMDs:", {k: round(x, 3) for k, x in broker_smds.items()})
print("economics:", json.dumps(eco, indent=1, default=float))
print(rob[["focal", "population", "n_focal", "mean_focal", "mean_reference", "estimate", "p_two_sided"]].to_string())
print("cash buffer arrears by arm:\n", cash_by_arm.round(4))
print(u[u.fam.isin(['P_primary'])][['outcome', 'p_two_sided', 'p_holm', 'p_holm_ledger']])
for k, r in t.items():
    print(f"{k:12s} est={r.estimate:+.4f} se={r.se:.4f} p={r.p_two_sided:.2e} holm={r.p_holm:.2e} "
          f"holm_ledger={r.p_holm_ledger:.2e} 95%CI=({r.estimate - 1.96 * r.se:+.4f},{r.estimate + 1.96 * r.se:+.4f})")
