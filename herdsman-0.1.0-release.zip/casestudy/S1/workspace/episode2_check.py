"""Episode 2 planning: identify fold 1, compare fold-1 z with referee evidence, replicate candidates on fold 1."""
import numpy as np, pandas as pd
import northfell_tools as nt
df = nt.load_data()
print(df.shape, [c for c in df.columns if c not in pd.read_csv("analysis_results.csv", nrows=0).columns][:0])
print("extra columns:", sorted(set(df.columns) - {
    'application_id','variant','channel','device','region','sector','accounting_software','years_trading','turnover_band',
    'turnover_label','employees','vat_registered','prior_ccj','cash_buffer_days','director_count','requested_amount_k',
    'application_weekday','started_hour','email_domain','browser','logo_uploaded','referral_code_used','marketing_consent',
    'form_language','company_name_length','completed','funded','arrears_6m','minutes_in_journey'}))
ex = df.iloc[:19200]
print("first ids:", list(df.application_id[:3]))
print("exploration block reproduces originals:",
      round(ex.completed.mean(), 6), round(ex.funded.mean(), 6), int(ex.arrears_6m.sum()), int(ex.arrears_6m.notna().sum()),
      round(ex.minutes_in_journey.mean(), 6))
f1 = df.iloc[19200:]
print("fold1 n:", len(f1), "| overlap ids with exploration block:", len(set(f1.application_id) & set(ex.application_id)))

def stat(d, outcome, focal, reference="rest", population="", margin=0.0, direction="increase"):
    p = d.eval(population) if population else pd.Series(True, index=d.index)
    fm = p & d.eval(focal)
    rm = p & (~d.eval(focal) if reference == "rest" else d.eval(reference))
    a, b = d.loc[fm, outcome].dropna(), d.loc[rm, outcome].dropna()
    est = a.mean() - b.mean(); se = np.sqrt(a.var(ddof=1) / len(a) + b.var(ddof=1) / len(b))
    z = (est - margin) / se if direction == "increase" else (-est - margin) / se
    return est, se, z, len(a), len(b)

B, A = "variant == 'B'", "variant == 'A'"
ref_e = {"C001": 147, "C002": 2.9e7, "C003": 38681, "C004": 2.3e8, "C005": 2.8e8, "C006": 2.2e10, "C007": 5359,
         "C008": 46570, "C009": 382807, "C010": 1.9e7}
rows = []
for c in nt.claims():
    m = c["members"][0]
    est, se, z, n1, n0 = stat(f1, m["outcome"], m["focal"], m["reference"], m["population"], m["margin"], m["direction"])
    ee, see, ze, _, _ = stat(ex, m["outcome"], m["focal"], m["reference"], m["population"], m["margin"], m["direction"])
    lam = ze * np.sqrt(len(f1) / len(ex))  # plug-in alternative from exploration, on fold scale
    rows.append(dict(id=c["id"], z_fold1=z, z_explore=ze, ln_e=np.log(ref_e[c["id"]]), half_z2=z * z / 2,
                     plugin=lam * z - lam * lam / 2, est_f1=est, est_ex=ee, status=c["status"], log10_e=c["log10_e"]))
cal = pd.DataFrame(rows)
print(cal.round(3).to_string())
print("ln_e - z^2/2 (mixture penalty if any):", (cal.ln_e - cal.half_z2).round(2).tolist())

F = "funded == 1"
cands = {
    "arrears overall B vs A": ("arrears_6m", B, A, F, 0.0, "increase"),
    "arrears broker B vs A": ("arrears_6m", B, A, F + " and channel == 'broker'", 0.0, "increase"),
    "arrears direct B vs A": ("arrears_6m", B, A, F + " and channel == 'direct'", 0.0, "increase"),
    "arrears partner B vs A": ("arrears_6m", B, A, F + " and channel == 'partner'", 0.0, "increase"),
    "arrears non-broker B vs A": ("arrears_6m", B, A, F + " and channel in ['direct', 'partner']", 0.0, "increase"),
    "funded non-broker B vs A": ("funded", B, A, "channel in ['direct', 'partner']", 0.0, "increase"),
    "approval among completed B vs A": ("funded", B, A, "completed == 1", 0.0, "increase"),
    "CCJ": ("arrears_6m", "prior_ccj == 1", "rest", F, 0.0, "increase"),
    "hospitality": ("arrears_6m", "sector == 'hospitality'", "rest", F, 0.0, "increase"),
    "request >= 100k": ("arrears_6m", "requested_amount_k >= 100", "rest", F, 0.0, "decrease"),
    "cash buffer < 15": ("arrears_6m", "cash_buffer_days < 15", "rest", F, 0.0, "increase"),
    "years trading < 2": ("arrears_6m", "years_trading < 2", "rest", F, 0.0, "increase"),
    "turnover band 1": ("arrears_6m", "turnover_band == 1", "rest", F, 0.0, "increase"),
    "employees <= 2": ("arrears_6m", "employees <= 2", "rest", F, 0.0, "increase"),
    "not VAT registered": ("arrears_6m", "vat_registered == 0", "rest", F, 0.0, "increase"),
    "construction": ("arrears_6m", "sector == 'construction'", "rest", F, 0.0, "increase"),
    "broker under A": ("arrears_6m", "channel == 'broker'", "rest", F + " and variant == 'A'", 0.0, "increase"),
}
out = []
for k, (o, fo, rf, po, mg, d) in cands.items():
    e1, s1, z1, n1, n0 = stat(f1, o, fo, rf, po, mg, d)
    e0, s0, z0, _, _ = stat(ex, o, fo, rf, po, mg, d)
    ep, sp, zp, _, _ = stat(df, o, fo, rf, po, mg, d)
    out.append(dict(candidate=k, est_ex=e0, z_ex=z0, est_f1=e1, se_f1=s1, z_f1=z1, n_focal_f1=n1, est_pooled=ep, se_pooled=sp,
                    z_pooled=zp, se_2folds=s1 / np.sqrt(2)))
print(pd.DataFrame(out).round(4).to_string())
