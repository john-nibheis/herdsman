"""Builds findings.json and report.md from the logged helper tests (test_results.csv); no numbers typed by hand."""
import json
import numpy as np
import pandas as pd
from scipy import stats
import northfell_tools as nt

d = pd.read_csv("test_results.csv")
d = d[d.p_two_sided.notna()].fillna({"population": ""})
N_TESTS = len(d)
B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"


def get(outcome, focal, reference, population):
    r = d[(d.outcome == outcome) & (d.focal == focal) & (d.reference == reference) & (d.population == population)]
    assert len(r) == 1, (outcome, focal, reference, population)
    return r.iloc[0]


pct = lambda x: f"{100 * x:.1f}%"
pts = lambda x: f"{100 * x:+.1f} points"
ci = lambda r, k=100, lab="95% CI ": f"{lab}{k * (r.estimate - 1.96 * r.se):+.1f} to {k * (r.estimate + 1.96 * r.se):+.1f}"
pv = lambda p: "p < 0.0001" if p < 1e-4 else f"p = {p:.1g}"

# Core results
comp, fund, mins = get("completed", B, A, ""), get("funded", B, A, ""), get("minutes_in_journey", B, A, "")
arr = get("arrears_6m", B, A, F)
arr_br = get("arrears_6m", B, A, F + " and channel == 'broker'")
arr_di = get("arrears_6m", B, A, F + " and channel == 'direct'")
arr_pa = get("arrears_6m", B, A, F + " and channel == 'partner'")
w = np.array([1 / arr_di.se ** 2, 1 / arr_pa.se ** 2])
nb_est = float((w * np.array([arr_di.estimate, arr_pa.estimate])).sum() / w.sum()); nb_se = float(1 / np.sqrt(w.sum()))
inter_z = (arr_br.estimate - nb_est) / np.sqrt(arr_br.se ** 2 + nb_se ** 2)
inter_p = 2 * stats.norm.sf(abs(inter_z))
extra_broker = arr_br.estimate * arr_br.n_focal
a_nonbroker = (arr_di.mean_reference * arr_di.n_reference + arr_pa.mean_reference * arr_pa.n_reference) / (arr_di.n_reference + arr_pa.n_reference)
sub = d[d.q == "Q1 subgroup"]; n_sub, n_sub_sig = len(sub), int((sub.p_two_sided < 0.05).sum())

# Descriptive: arrears predicted from observed risk factors (logistic model fitted on journey A funded loans only)
df = nt.load_data().iloc[:19200]  # exploration rows only: released folds are appended after row 19,200
assert len(df) == 19200
f = df[df.funded == 1].copy()
X = np.column_stack([np.ones(len(f)), f.prior_ccj, f.sector == "hospitality", f.requested_amount_k >= 100, f.cash_buffer_days < 15,
                     f.years_trading < 2, f.turnover_band == 1, f.vat_registered == 0, np.log(f.employees)]).astype(float)
y, tr = f.arrears_6m.values, (f.variant == "A").values
from scipy.optimize import minimize
beta = minimize(lambda b: np.sum(np.logaddexp(0, X[tr] @ b) - y[tr] * (X[tr] @ b)), np.zeros(X.shape[1]), method="BFGS").x
f["pred"] = 1 / (1 + np.exp(-X @ beta))
pred_bb = f[(f.channel == "broker") & (f.variant == "B")].pred.mean()
pred_ab = f[(f.channel == "broker") & (f.variant == "A")].pred.mean()

ccj = get("arrears_6m", "prior_ccj == 1", "rest", F)
hosp = get("arrears_6m", "sector == 'hospitality'", "rest", F)
big = get("arrears_6m", "requested_amount_k >= 100", "rest", F)
brk = get("arrears_6m", "channel == 'broker'", "rest", F)
cash = get("arrears_6m", "cash_buffer_days < 15", "rest", F)

# Pre-declared reporting rule: Benjamini-Hochberg q < 0.05 across every test run; non-redundant findings only.
specs = [
    (arr_br, f"Journey B raises 6-month arrears on broker-introduced funded loans from {pct(arr_br.mean_reference)} to {pct(arr_br.mean_focal)} "
             f"({pts(arr_br.estimate)}, about {extra_broker:.0f} extra loans in arrears), with broker completion and funding unchanged; "
             f"this is B's main unintended consequence"),
    (arr, f"Journey B raises 6-month arrears on funded loans overall from {pct(arr.mean_reference)} to {pct(arr.mean_focal)} ({pts(arr.estimate)}); "
          f"the whole excess comes from brokers, with no effect in other channels ({pts(nb_est)}, 95% CI {100 * (nb_est - 1.96 * nb_se):+.1f} to {100 * (nb_est + 1.96 * nb_se):+.1f})"),
    (ccj, f"A County Court Judgment in the last six years is the strongest early-warning signal of arrears: {pct(ccj.mean_focal)} vs {pct(ccj.mean_reference)} "
          f"({ccj.mean_focal / ccj.mean_reference:.1f} times the rate)"),
    (hosp, f"Hospitality businesses have {hosp.mean_focal / hosp.mean_reference:.1f} times the arrears rate of other sectors: "
           f"{pct(hosp.mean_focal)} vs {pct(hosp.mean_reference)}"),
    (big, f"Requests under £100k are an early-warning signal: loans requesting £100k or more have lower arrears than smaller requests, "
          f"{pct(big.mean_focal)} vs {pct(big.mean_reference)}"),
    (brk, f"Broker-introduced loans have higher arrears than other channels ({pct(brk.mean_focal)} vs {pct(brk.mean_reference)}), but only because of journey B: "
          f"under journey A broker loans run at {pct(arr_br.mean_reference)} against {pct(a_nonbroker)} elsewhere"),
]
findings = []
for r, statement in specs:
    assert r.q_bh_all < 0.05 and r.p_holm_all < 0.05, statement
    findings.append({"statement": statement, "outcome": r.outcome, "population": r.population, "focal": r.focal,
                     "reference": r.reference, "direction": "increase" if r.estimate > 0 else "decrease",
                     "estimate": round(float(r.estimate), 5), "p_value": float(f"{r.p_two_sided:.3g}")})
json.dump(findings, open("findings.json", "w"), indent=2, ensure_ascii=False)

report = f"""# Journey B experiment: findings

**Bottom line.** Journey B did not work. It produced no measurable gain in completion, funding or journey time for any group, and raised 6-month arrears on broker loans. The data support no wins, let alone five; nominal subgroup results would be noise, not wins.\n\n**Status.** Figures are exploration estimates. Referee-certified so far: prior CCJ raises arrears (C003); B saves under a minute (C006). All else is pending.

**1. Did B work, and for whom?** Across {len(df):,} applications, B changed completion by {pts(comp.estimate)} ({ci(comp)}), funding by {pts(fund.estimate)} ({ci(fund, lab="")}) and journey time by {mins.estimate:+.1f} minutes ({ci(mins, 1, "")}). None of {n_sub} subgroup tests on these outcomes survived correction; the {n_sub_sig} nominal hits match the {0.05 * n_sub:.1f} expected by chance. Open-banking uptake is not recorded; low uptake would explain a null and should be checked.

**2. Unintended consequences.** Arrears on funded loans rose from {pct(arr.mean_reference)} under A to {pct(arr.mean_focal)} under B ({pv(arr.p_two_sided)}). The rise is confined to brokers: {pct(arr_br.mean_reference)} to {pct(arr_br.mean_focal)} ({pv(arr_br.p_two_sided)}), about {extra_broker:.0f} extra loans in arrears, with no effect elsewhere ({pts(nb_est)}). Broker completion and funding were unchanged, and known risk factors predict only {pct(pred_bb)} for B broker loans ({pct(pred_ab)} for A). One hypothesis: pre-filled data bypassing checks on broker submissions.

**3. Early-warning signals.** Supported after correction: a prior CCJ ({pct(ccj.mean_focal)} vs {pct(ccj.mean_reference)}), hospitality ({pct(hosp.mean_focal)} vs {pct(hosp.mean_reference)}), requests under £100k ({pct(big.mean_reference)} vs {pct(big.mean_focal)}) and broker loans under B. Suggestive only: cash buffer under 15 days ({pct(cash.mean_focal)} vs {pct(cash.mean_reference)}). Logo upload, email domain, browser, company name length, weekday, start hour, region, marketing consent, referral code and form language show no reliable signal; do not use them.

**Recommendations.** Withdraw B from the broker channel now and review B broker loans in arrears. Do not extend B until uptake is understood and a revision shows benefit. Add the supported signals to arrears monitoring; validate the suggestive one on new data. The accurate board message: the experiment caught a credit problem before scale-up.

**Method.** Randomisation was balanced (allocation p = 0.50; covariate differences under 0.03 SD). All {N_TESTS} pre-specified tests ran through northfell_tools; every reported finding survives Benjamini-Hochberg and Holm correction across all of them; broker interaction z = {inter_z:.1f}. Arrears exist only for funded loans; with equal funding rates by arm, selection bias is unlikely.
"""
open("report.md", "w").write(report)
print(json.dumps(findings, indent=1, ensure_ascii=False))
print(report)
print("report words:", len(report.split()), "| findings:", len(findings), "| tests:", N_TESTS, "| interaction p:", f"{inter_p:.2g}")
