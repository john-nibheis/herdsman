# Journey B experiment: findings

**Bottom line.** Journey B did not work. It produced no measurable gain in completion, funding or journey time for any group, and raised 6-month arrears on broker loans. The data support no wins, let alone five; nominal subgroup results would be noise, not wins.

**Status.** Figures are exploration estimates. Referee-certified so far: prior CCJ raises arrears (C003); B saves under a minute (C006). All else is pending.

**1. Did B work, and for whom?** Across 19,200 applications, B changed completion by +0.1 points (95% CI -1.3 to +1.4), funding by -0.1 points (-1.5 to +1.3) and journey time by -0.1 minutes (-0.5 to +0.2). None of 51 subgroup tests on these outcomes survived correction; the 3 nominal hits match the 2.6 expected by chance. Open-banking uptake is not recorded; low uptake would explain a null and should be checked.

**2. Unintended consequences.** Arrears on funded loans rose from 3.0% under A to 4.4% under B (p = 0.0003). The rise is confined to brokers: 2.8% to 7.3% (p < 0.0001), about 72 extra loans in arrears, with no effect elsewhere (-0.1 points). Broker completion and funding were unchanged, and known risk factors predict only 3.2% for B broker loans (3.1% for A). One hypothesis: pre-filled data bypassing checks on broker submissions.

**3. Early-warning signals.** Supported after correction: a prior CCJ (10.0% vs 3.5%), hospitality (6.7% vs 3.4%), requests under £100k (4.2% vs 2.6%) and broker loans under B. Suggestive only: cash buffer under 15 days (4.8% vs 3.4%). Logo upload, email domain, browser, company name length, weekday, start hour, region, marketing consent, referral code and form language show no reliable signal; do not use them.

**Recommendations.** Withdraw B from the broker channel now and review B broker loans in arrears. Do not extend B until uptake is understood and a revision shows benefit. Add the supported signals to arrears monitoring; validate the suggestive one on new data. The accurate board message: the experiment caught a credit problem before scale-up.

**Method.** Randomisation was balanced (allocation p = 0.50; covariate differences under 0.03 SD). All 125 pre-specified tests ran through northfell_tools; every reported finding survives Benjamini-Hochberg and Holm correction across all of them; broker interaction z = 5.2. Arrears exist only for funded loans; with equal funding rates by arm, selection bias is unlikely.
