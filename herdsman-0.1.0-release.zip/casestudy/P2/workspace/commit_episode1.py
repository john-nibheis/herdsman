"""Episode 1 claim commits. Guarded: a claim whose statement is already committed is never re-committed.
Strategy: commit now only claims that are strongly supported on exploration data (survive Holm across all 125 tests,
large expected per-fold z) or, for the Q1 'did B work' question, a non-superiority claim with ample power.
Weaker candidates wait for episode 2, when fold 1 is added to the data and the evidence bar will be lower."""
import json
import northfell_tools as nt

B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"
CLAIMS = [
    dict(statement="Journey B raises 6-month arrears among broker-introduced funded loans",
         outcome="arrears_6m", focal=B, reference=A, population=F + " and channel == 'broker'", direction="increase", margin=0.0),
    dict(statement="Journey B raises 6-month arrears among funded loans overall",
         outcome="arrears_6m", focal=B, reference=A, population=F, direction="increase", margin=0.0),
    dict(statement="Funded loans to businesses with a County Court Judgment in the last six years have higher 6-month arrears than other funded loans",
         outcome="arrears_6m", focal="prior_ccj == 1", reference="rest", population=F, direction="increase", margin=0.0),
    dict(statement="Funded loans to hospitality businesses have higher 6-month arrears than funded loans in other sectors",
         outcome="arrears_6m", focal="sector == 'hospitality'", reference="rest", population=F, direction="increase", margin=0.0),
    dict(statement="Funded loans requesting £100k or more have lower 6-month arrears than smaller funded loans",
         outcome="arrears_6m", focal="requested_amount_k >= 100", reference="rest", population=F, direction="decrease", margin=0.0),
    # Non-superiority: claim mean(B) - mean(A) > -1 minute, i.e. B does not cut average journey time by a minute or more.
    dict(statement="Journey B does not cut average time in the application journey by one minute or more (B minus A is above -1 minute)",
         outcome="minutes_in_journey", focal=B, reference=A, population="", direction="increase", margin=-1.0),
]

done = {c.get("statement") for c in nt.claims()}
for c in CLAIMS:
    if c["statement"] in done:
        print("already committed:", c["statement"]); continue
    try:
        r = nt.commit_claim(c["statement"], c["outcome"], focal=c["focal"], reference=c["reference"],
                            population=c["population"], direction=c["direction"], margin=c["margin"])
        print("COMMITTED:", json.dumps(r, default=str))
    except Exception as e:
        print("REJECTED:", c["statement"], "->", repr(e))
print(json.dumps(nt.budget(), indent=1, default=str))
print(json.dumps(nt.claims(), indent=1, default=str))
