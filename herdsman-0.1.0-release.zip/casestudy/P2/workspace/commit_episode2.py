"""Episode 2: log supporting tests on the combined data (exploration + fold 1) through the helper, then commit.
Selection rule: pre-specified in the exploration plan, a-priori plausible, and replicated on fold 1 (independent of selection).
Completion/funding claims are equivalence halves (+/-3 points): margin chosen so two folds give a reasonable chance to certify.
Guarded against double commits and against committing a claim whose combined-data evidence points the wrong way."""
import json, os
import numpy as np
import northfell_tools as nt

CACHE = "test_results_ep2.json"
B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"
TESTS = {  # name: (outcome, focal, reference, population, direction)
    "completed": ("completed", B, A, "", "increase"),
    "funded": ("funded", B, A, "", "increase"),
    "cash": ("arrears_6m", "cash_buffer_days < 15", "rest", F, "increase"),
    "turnover": ("arrears_6m", "turnover_band == 1", "rest", F, "increase"),
    "employees": ("arrears_6m", "employees <= 3", "rest", F, "increase"),
    "young": ("arrears_6m", "years_trading < 2", "rest", F, "increase"),
}
cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
for k, (o, fo, re_, pop, d) in TESTS.items():
    if k not in cache:
        cache[k] = nt.test_difference(o, fo, re_, population=pop, direction=d)
        json.dump(cache, open(CACHE, "w"), indent=1)
    r = cache[k]
    print(f"{k:10s} est={r['estimate']:+.4f} se={r['se']:.4f} z={r['z']:+.2f} p2={r['p_two_sided']:.2g} n={r['n_focal']}/{r['n_reference']}")


def zmargin(k, direction, margin):  # combined-data z for the claim as specified (sanity guard only)
    r = cache[k]
    return (r["estimate"] - margin) / r["se"] if direction == "increase" else (-margin - r["estimate"]) / r["se"]


CLAIMS = [
    ("completed", dict(statement="Journey B does not raise the completion rate by 3 percentage points or more (B minus A is below +0.03)",
                       outcome="completed", focal=B, reference=A, population="", direction="decrease", margin=-0.03)),
    ("funded", dict(statement="Journey B does not raise the funding rate by 3 percentage points or more (B minus A is below +0.03)",
                    outcome="funded", focal=B, reference=A, population="", direction="decrease", margin=-0.03)),
    ("completed", dict(statement="Journey B does not lower the completion rate by 3 percentage points or more (B minus A is above -0.03)",
                       outcome="completed", focal=B, reference=A, population="", direction="increase", margin=-0.03)),
    ("funded", dict(statement="Journey B does not lower the funding rate by 3 percentage points or more (B minus A is above -0.03)",
                    outcome="funded", focal=B, reference=A, population="", direction="increase", margin=-0.03)),
    ("cash", dict(statement="Funded loans to businesses with a cash buffer of under 15 days have higher 6-month arrears than other funded loans",
                  outcome="arrears_6m", focal="cash_buffer_days < 15", reference="rest", population=F, direction="increase", margin=0.0)),
    ("turnover", dict(statement="Funded loans to businesses with turnover under £100k have higher 6-month arrears than other funded loans",
                      outcome="arrears_6m", focal="turnover_band == 1", reference="rest", population=F, direction="increase", margin=0.0)),
    ("employees", dict(statement="Funded loans to businesses with three or fewer employees have higher 6-month arrears than other funded loans",
                       outcome="arrears_6m", focal="employees <= 3", reference="rest", population=F, direction="increase", margin=0.0)),
    ("young", dict(statement="Funded loans to businesses trading for under two years have higher 6-month arrears than other funded loans",
                   outcome="arrears_6m", focal="years_trading < 2", reference="rest", population=F, direction="increase", margin=0.0)),
]
done = {c.get("statement") for c in nt.claims()}
for k, c in CLAIMS:
    z = zmargin(k, c["direction"], c["margin"])
    if c["statement"] in done:
        print("already committed:", c["statement"]); continue
    if z < 2:
        print(f"SKIPPED (combined z {z:.2f} < 2):", c["statement"]); continue
    try:
        r = nt.commit_claim(c["statement"], c["outcome"], focal=c["focal"], reference=c["reference"],
                            population=c["population"], direction=c["direction"], margin=c["margin"])
        print(f"COMMITTED {r['id']} (threshold {r['threshold_e']:.1f}, combined z {z:.2f}, warnings {r.get('warnings')}):", c["statement"])
    except Exception as e:
        print("REJECTED:", c["statement"], "->", repr(e))
b = nt.budget()
print({k: b[k] for k in ["claims_committed", "slots_left", "certified", "next_claim_threshold_e", "episode", "folds_remaining"]})
