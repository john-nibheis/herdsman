"""Episode 2 descriptive checks (no hypothesis tests logged here): fold 1 = rows 19,200+ of load_data().
1) Relate the referee's fold-1 log e-values to fold-1 Welch z for the six committed claims.
2) Replication of candidate claims: exploration vs fold 1 (fold 1 is independent of how candidates were chosen)."""
import numpy as np
import pandas as pd
import northfell_tools as nt

df = nt.load_data()
expl, fold1 = df.iloc[:19200], df.iloc[19200:]
B, A, F = "variant == 'B'", "variant == 'A'", "funded == 1"


def stat(data, outcome, focal, reference, population="", direction="increase", margin=0.0):
    d = data.query(population) if population else data
    d = d[d[outcome].notna()]
    f = d.query(focal)
    r = d.drop(f.index) if reference == "rest" else d.query(reference)
    diff = f[outcome].mean() - r[outcome].mean()
    se = np.sqrt(f[outcome].var() / len(f) + r[outcome].var() / len(r))
    z = (diff - margin) / se if direction == "increase" else (-margin - diff) / se
    return diff, se, z, len(f), len(r)


# 1) calibration against the referee's reported fold-1 evidence
log_e = {c["id"]: c["trajectory"][0]["log_e_fold"] for c in nt.claims()}
rows = []
for c in nt.claims():
    m = c["members"][0]
    de, see, ze, _, _ = stat(expl, m["outcome"], m["focal"], m["reference"], m["population"], m["direction"], m["margin"])
    d1, se1, z1, nf, nr = stat(fold1, m["outcome"], m["focal"], m["reference"], m["population"], m["direction"], m["margin"])
    lam = ze * se / se1 if False else (abs(de) * 0 + (ze * see) / se1)  # exploration effect (net of margin) in fold-1 z units
    rows.append(dict(id=c["id"], z_fold1=z1, logE=log_e[c["id"]], half_z2=z1 ** 2 / 2, lam_expl=lam,
                     plugin_expl=lam * z1 - lam ** 2 / 2, n_f=nf, n_r=nr))
print(pd.DataFrame(rows).round(3).to_string(index=False))

# 2) replication of candidates (pre-specified, a-priori plausible, nominally supported in exploration)
cands = [
    ("completed", B, A, "", "decrease", -0.02, "B does not raise completion by 2+ pts"),
    ("completed", B, A, "", "decrease", -0.025, "B does not raise completion by 2.5+ pts"),
    ("funded", B, A, "", "decrease", -0.02, "B does not raise funding by 2+ pts"),
    ("funded", B, A, "", "decrease", -0.025, "B does not raise funding by 2.5+ pts"),
    ("completed", B, A, "", "increase", -0.02, "B does not cut completion by 2+ pts"),
    ("funded", B, A, "", "increase", -0.02, "B does not cut funding by 2+ pts"),
    ("arrears_6m", B, A, F + " and channel in ['direct', 'partner']", "decrease", -0.01, "B does not raise non-broker arrears by 1+ pt"),
    ("arrears_6m", B, A, F + " and channel in ['direct', 'partner']", "increase", 0.0, "(check) B raises non-broker arrears"),
    ("arrears_6m", "cash_buffer_days < 15", "rest", F, "increase", 0.0, "cash buffer < 15 days"),
    ("arrears_6m", "years_trading < 2", "rest", F, "increase", 0.0, "years trading < 2"),
    ("arrears_6m", "turnover_band == 1", "rest", F, "increase", 0.0, "turnover < 100k"),
    ("arrears_6m", "employees <= 3", "rest", F, "increase", 0.0, "employees <= 3"),
    ("arrears_6m", "vat_registered == 0", "rest", F, "increase", 0.0, "not VAT registered"),
    ("completed", B, A, "years_trading < 2", "decrease", 0.0, "(check) B lowers completion, <2 yrs"),
    ("completed", B, A, "device == 'tablet'", "decrease", 0.0, "(check) B lowers completion, tablet"),
    ("minutes_in_journey", B, A, "accounting_software == 'cloud'", "decrease", 0.0, "(check) B cuts minutes, cloud"),
]
out = []
for o, fo, re_, pop, dirn, mg, lab in cands:
    de, see, ze, _, _ = stat(expl, o, fo, re_, pop, dirn, mg)
    d1, se1, z1, nf, nr = stat(fold1, o, fo, re_, pop, dirn, mg)
    dc, sec, zc, _, _ = stat(df, o, fo, re_, pop, dirn, mg)
    out.append(dict(claim=lab, est_expl=de, z_expl=ze, est_fold1=d1, z_fold1=z1, est_all=dc, z_all=zc, se_fold1=se1))
pd.set_option("display.width", 250)
print(pd.DataFrame(out).round(4).to_string(index=False))
