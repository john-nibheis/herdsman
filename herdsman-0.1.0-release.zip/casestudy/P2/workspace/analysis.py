"""Pre-specified test plan for the Northfell journey experiment (fixed before any outcome was examined,
apart from the overall completion test, which is reused from the cache rather than re-run).
Every hypothesis test runs exactly once through northfell_tools; results are cached in test_results.json.
Multiplicity: Benjamini-Hochberg and Holm across ALL tests run, on two-sided p-values."""
import json, os
import numpy as np
import pandas as pd
import northfell_tools as nt

CACHE = "test_results.json"
B, A = "variant == 'B'", "variant == 'A'"
F = "funded == 1"

# A-priori moderators for an open-banking pre-fill journey: device (typing burden, app-to-app bank redirect),
# channel (brokers cannot complete the owner's bank consent), accounting software (existing data connections),
# form language (bank consent screens may be English-only), business age and size (thin files).
SUBGROUPS = [
    "device == 'desktop'", "device == 'mobile'", "device == 'tablet'",
    "channel == 'direct'", "channel == 'broker'", "channel == 'partner'",
    "accounting_software == 'cloud'", "accounting_software == 'desktop'", "accounting_software == 'none'",
    "form_language == 'en'", "form_language == 'cy'",
    "years_trading < 2", "years_trading >= 2 and years_trading < 5", "years_trading >= 5",
    "turnover_band in [1, 2]", "turnover_band == 3", "turnover_band in [4, 5]",
]

# Early-warning candidates (focal vs rest, among funded loans). Thresholds fixed from domain policy or
# whole-sample quartiles, never from outcome data.
Q3_FOCALS = [
    "prior_ccj == 1", "cash_buffer_days < 15", "years_trading < 2", "vat_registered == 0", "turnover_band == 1",
    "employees <= 3", "requested_amount_k >= 100", "director_count == 1",
    "accounting_software == 'none'", "accounting_software == 'cloud'", "accounting_software == 'desktop'",
    "channel == 'direct'", "channel == 'broker'", "channel == 'partner'",
    "device == 'desktop'", "device == 'mobile'", "device == 'tablet'",
] + [f"sector == '{s}'" for s in ["professional services", "retail", "construction", "other", "hospitality",
                                   "manufacturing", "transport", "health"]] \
  + [f"region == '{r}'" for r in ["London", "South East", "North West", "West Midlands", "East of England", "Scotland",
                                  "Yorkshire", "South West", "East Midlands", "Wales", "North East", "Northern Ireland"]] \
  + [f"email_domain == '{e}'" for e in ["company", "gmail", "outlook", "other"]] \
  + [f"browser == '{b}'" for b in ["chrome", "safari", "edge", "firefox"]] \
  + ["logo_uploaded == 1", "referral_code_used == 1", "marketing_consent == 1", "form_language == 'cy'",
     "application_weekday in ['Sat', 'Sun']", "started_hour in [0, 1, 2, 3, 4, 5, 6, 20, 21, 22, 23]",
     "company_name_length >= 31"]


def plan():
    p = [dict(q="Q1 overall", outcome="completed", focal=B, reference=A, population="", direction="increase"),
         dict(q="Q1 overall", outcome="funded", focal=B, reference=A, population="", direction="increase"),
         dict(q="Q1 overall", outcome="minutes_in_journey", focal=B, reference=A, population="", direction="decrease"),
         dict(q="Q2 overall", outcome="funded", focal=B, reference=A, population="completed == 1", direction="increase"),
         dict(q="Q2 overall", outcome="arrears_6m", focal=B, reference=A, population=F, direction="increase")]
    # Q2 selection check: did B change the risk mix of who gets funded?
    for c, d in [("prior_ccj", "increase"), ("cash_buffer_days", "decrease"), ("years_trading", "decrease")]:
        p.append(dict(q="Q2 mix", outcome=c, focal=B, reference=A, population=F, direction=d))
    for s in SUBGROUPS:
        for o, d in [("completed", "increase"), ("funded", "increase"), ("minutes_in_journey", "decrease")]:
            p.append(dict(q="Q1 subgroup", outcome=o, focal=B, reference=A, population=s, direction=d))
        p.append(dict(q="Q2 subgroup", outcome="arrears_6m", focal=B, reference=A, population=f"{F} and {s}", direction="increase"))
    for f in Q3_FOCALS:
        p.append(dict(q="Q3", outcome="arrears_6m", focal=f, reference="rest", population=F, direction="increase"))
    return p


def key(t):
    return "|".join([t["outcome"], t["focal"], t["reference"], t["population"]])


def run():
    cache = json.load(open(CACHE)) if os.path.exists(CACHE) else {}
    rows = []
    for t in plan():
        k = key(t)
        if k not in cache:
            try:
                cache[k] = nt.test_difference(t["outcome"], t["focal"], t["reference"], population=t["population"], direction=t["direction"])
            except Exception as e:  # record, do not retry
                cache[k] = {"error": repr(e)}
            json.dump(cache, open(CACHE, "w"), indent=1)
        rows.append({**t, **cache[k]})
    df = pd.DataFrame(rows)
    ok = df["p_two_sided"].notna()
    p = df.loc[ok, "p_two_sided"].values
    m = len(p); order = np.argsort(p)
    q = np.empty(m); q[order] = np.minimum.accumulate((p[order] * m / np.arange(1, m + 1))[::-1])[::-1]
    h = np.empty(m); h[order] = np.minimum(np.maximum.accumulate((m - np.arange(m)) * p[order]), 1)
    df.loc[ok, "q_bh_all"] = np.minimum(q, 1)
    df.loc[ok, "p_holm_all"] = h
    df.to_csv("test_results.csv", index=False)
    return df


if __name__ == "__main__":
    d = run()
    print(len(d), "tests;", int(d.get("error", pd.Series(dtype=object)).notna().sum()), "errors;",
          int((d.q_bh_all < 0.05).sum()), "with BH q<0.05;", int((d.p_holm_all < 0.05).sum()), "with Holm p<0.05")
